(async () => {
const cs = {}
const ex = {}
const gl = {}
const os = {}
const pm = {}
const sw = {}
const vw = {}
const exOs = {}
const exSw = {}
const osVw = {}
const swVw = {}
const exOsVw = {}


//#region \0rolldown/runtime.js
var __defProp$1 = Object.defineProperty;
var __name$1 = (target, value) => __defProp$1(target, "name", {
	value,
	configurable: true
});

//#endregion
//#region dist/ORIGINALS/assets/utils-generate-id-86LkPRmU.js
var __create = Object.create;
var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", {
	value,
	configurable: true
});
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esmMin = (fn, res) => () => (fn && (res = fn(fn = 0)), res);
var __commonJSMin = (cb, mod) => () => (mod || cb((mod = { exports: {} }).exports, mod), mod.exports);
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var __copyProps = (to, from, except, desc) => {
	if (from && typeof from === "object" || typeof from === "function") for (var keys = __getOwnPropNames(from), i = 0, n = keys.length, key; i < n; i++) {
		key = keys[i];
		if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
			get: ((k) => from[k]).bind(null, key),
			enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
		});
	}
	return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", {
	value: mod,
	enumerable: true
}) : target, mod));
var init_core_reloader = __esmMin((() => {}));
function colorHash(str) {
	let hash = 5381;
	for (let i = 0; i < str.length; i++) hash = hash * 33 ^ str.charCodeAt(i);
	hash >>>= 0;
	const hue = Math.floor(hash * .618033988749895 % 1 * 360);
	const sat = 70;
	let light = 50;
	for (let i = 0; i < 20; i++) {
		const l = lum(hsl2rgb(hue, sat, light));
		const cW = contrast(1, l);
		const cB = contrast(0, l);
		if (cW >= 4.5 && cB >= 4.5) break;
		light += cW < cB ? -5 : 5;
	}
	return `#${hsl2rgb(hue, sat, light).map((v) => v.toString(16).padStart(2, "0")).join("")}`;
}
function hsl2rgb(hh, ss, ll) {
	ss /= 100;
	ll /= 100;
	const k = (n) => (n + hh / 30) % 12;
	const a = ss * Math.min(ll, 1 - ll);
	const f = (n) => ll - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
	return [
		f(0),
		f(8),
		f(4)
	].map((v) => Math.round(v * 255));
}
function lum([r, g, b]) {
	const c = (x) => {
		x /= 255;
		return x <= .03928 ? x / 12.92 : ((x + .055) / 1.055) ** 2.4;
	};
	return .2126 * c(r) + .7152 * c(g) + .0722 * c(b);
}
function contrast(l1, l2) {
	return (Math.max(l1, l2) + .05) / (Math.min(l1, l2) + .05);
}
var init_utils_color_hash = __esmMin((() => {}));
function createLog(name) {
	const color = colorHash(name);
	const log = print$1.bind(null, "log", name, color);
	log.warn = print$1.bind(null, "warn", name, color);
	log.error = print$1.bind(null, "error", name, color);
	return log;
}
function print$1(type, name, color, ...args) {
	console[type](`%c[${name}]`, `color: ${color}`, ...args);
}
__name$1(print$1, "print");
var init_utils_create_log = __esmMin((() => {
	init_utils_color_hash();
}));
var is;
var init_utils_is = __esmMin((() => {
	is = {
		null: (v) => v === null,
		undefined: (v) => v === void 0,
		boolean: (v) => typeof v === "boolean",
		number: (v) => typeof v === "number",
		string: (v) => typeof v === "string",
		symbol: (v) => typeof v === "symbol",
		function: (v) => typeof v === "function",
		object: (v) => Object.prototype.toString.call(v) === "[object Object]",
		array: (v) => Array.isArray(v),
		set: (v) => v instanceof Set,
		map: (v) => v instanceof Map,
		blob: (v) => v instanceof Blob,
		date: (v) => v instanceof Date,
		error: (v) => v instanceof Error,
		regex: (v) => v instanceof RegExp,
		promise: (v) => v instanceof Promise,
		uint8Array: (v) => v instanceof Uint8Array,
		uint16Array: (v) => v instanceof Uint16Array,
		uint32Array: (v) => v instanceof Uint32Array,
		nan: (v) => Number.isNaN(v),
		numeric: (v) => !is.nan(Number(v)),
		integer: (v) => Number.isInteger(v),
		absent: (v) => v === null || v === void 0,
		present: (v) => !is.absent(v),
		primitive: (v) => v !== Object(v),
		collection: (v) => is.array(v) || is.object(v),
		compound: (v) => v !== null && typeof v === "object"
	};
}));
async function safe(effect) {
	try {
		return [is.function(effect) ? await effect() : await effect, void 0];
	} catch (e) {
		return [void 0, e instanceof Error ? e : new Error(String(e))];
	}
}
var init_utils_safe = __esmMin((() => {
	init_utils_is();
}));
var Queue;
var init_utils_queue = __esmMin((() => {
	init_utils_safe();
	Queue = class {
		name;
		tasks = [];
		running = false;
		constructor(name = null) {
			this.name = name;
		}
		async add(fn) {
			const task = {
				fn,
				result$: Promise.withResolvers()
			};
			this.tasks.push(task);
			this.start();
			return await task.result$.promise;
		}
		wrap(fn, thisArg = null) {
			return (async (...args) => {
				return await this.add(() => fn.call(thisArg, ...args));
			});
		}
		async wait() {
			const lastTask = this.tasks.at(-1);
			if (lastTask) await safe(lastTask.result$.promise);
		}
		isEmpty() {
			return this.tasks.length === 0;
		}
		async start() {
			if (this.running) return;
			if (this.isEmpty()) return;
			this.running = true;
			while (this.tasks.length > 0) {
				const task = this.tasks[0];
				if (!task) break;
				const [result, error] = await safe(task.fn);
				this.tasks.shift();
				if (error) task.result$.reject(error);
				else task.result$.resolve(result);
			}
			this.running = false;
		}
	};
}));
function enqueue(fn, thisValue = null) {
	return new Queue().wrap(fn, thisValue);
}
var init_utils_enqueue = __esmMin((() => {
	init_utils_queue();
}));
var init_utils_ensure_array = __esmMin((() => {}));
/**
* Get the whole prototype chain of an object up to `Object.prototype`.
*/
function getPrototypes(object) {
	const prototype = Reflect.getPrototypeOf(object);
	if (!prototype || prototype === Object.prototype) return [];
	return [prototype, ...getPrototypes(prototype)];
}
var init_utils_get_prototypes = __esmMin((() => {}));
function get$1(target, path) {
	const [key, ...rest] = path;
	if (key === void 0) return target;
	if (is.object(target)) if (rest.length === 0) return target[key];
	else return get$1(target[key], rest);
	if (is.array(target)) {
		const index = Number(key);
		if (rest.length === 0) return target[index];
		else return get$1(target[index], rest);
	}
	return target;
}
__name$1(get$1, "get");
var init_utils_get = __esmMin((() => {
	init_utils_is();
}));
function link(target, method) {
	if (!is.function(target[method])) throw new Error(`Property '${String(method)}' is not a function`);
	return target[method].bind(target);
}
var init_utils_link = __esmMin((() => {
	init_utils_is();
}));
var init_utils_unique = __esmMin((() => {}));
var Unit$1;
var init_utils_unit = __esmMin((() => {
	init_utils_create_log();
	init_utils_is();
	Unit$1 = class {
		static {
			__name(this, "Unit");
		}
		$;
		log = createLog(this.constructor.name);
		#parent = null;
		constructor(parent) {
			this.$ = parent?.$ ?? this;
			this.#parent = parent ?? null;
		}
		closest(lookup) {
			const isTarget = is.string(lookup) ? (unit) => unit.constructor.name === lookup : (unit) => unit instanceof lookup;
			let cursor = this.#parent;
			while (cursor) {
				if (isTarget(cursor)) return cursor;
				cursor = cursor.#parent;
			}
			return null;
		}
		never(message) {
			const details = message ? `: ${message}` : "";
			const error = /* @__PURE__ */ new Error(`[${this.constructor.name}] CRITICAL${details}`);
			Error.captureStackTrace(error, this.never);
			return error;
		}
	};
}));
var init_utils$1 = __esmMin((() => {
	init_utils_color_hash();
	init_utils_enqueue();
	init_utils_ensure_array();
	init_utils_get_prototypes();
	init_utils_get();
	init_utils_is();
	init_utils_link();
	init_utils_queue();
	init_utils_safe();
	init_utils_unique();
	init_utils_unit();
}));
var Unit;
var UnitGl;
var UnitCs;
var UnitEx;
var UnitOs;
var UnitPm;
var UnitSw;
var UnitVw;
var UnitExOs;
var UnitExSw;
var UnitOsVw;
var UnitSwVw;
var UnitExOsVw;
var init_core_units = __esmMin((() => {
	init_utils$1();
	Unit = class extends Unit$1 {
		use(bundle, id) {
			const idPart = id ? `[${id}]` : "";
			return this.$.bus.use(`${this.constructor.name}${idPart}[${bundle}]`);
		}
		expose(id) {
			const idPart = id ? `[${id}]` : "";
			this.$.bus.register(`${this.constructor.name}${idPart}[ex]`, this);
		}
		unexpose(id) {
			const idPart = id ? `[${id}]` : "";
			this.$.bus.unregister(`${this.constructor.name}${idPart}[ex]`);
		}
	};
	UnitGl = class extends Unit {};
	UnitCs = class extends Unit {};
	UnitEx = class extends Unit {};
	UnitOs = class extends Unit {};
	UnitPm = class extends Unit {};
	UnitSw = class extends Unit {};
	UnitVw = class extends Unit {};
	UnitExOs = class extends Unit {};
	UnitExSw = class extends Unit {};
	UnitOsVw = class extends Unit {};
	UnitSwVw = class extends Unit {};
	UnitExOsVw = class extends Unit {};
	cs.Unit = UnitCs;
	ex.Unit = UnitEx;
	gl.Unit = UnitGl;
	os.Unit = UnitOs;
	pm.Unit = UnitPm;
	sw.Unit = UnitSw;
	vw.Unit = UnitVw;
	exOs.Unit = UnitExOs;
	exSw.Unit = UnitExSw;
	osVw.Unit = UnitOsVw;
	swVw.Unit = UnitSwVw;
	exOsVw.Unit = UnitExOsVw;
}));
var init_core = __esmMin((() => {
	init_core_reloader();
	init_core_units();
}));
var BusAction;
var init_bus_action_gl = __esmMin((() => {
	BusAction = class extends gl.Unit {
		name;
		fn;
		target;
		this;
		/** If target specified, the action becomes a 'proxy action' and serves to forward messages to the target. */
		constructor(parent, name, fn, thisArg, target) {
			super(parent);
			this.name = name;
			this.fn = fn;
			if (thisArg) this.this = thisArg;
			if (target) this.target = target;
		}
		async execute(...args) {
			return await this.fn.call(this.this, ...args);
		}
	};
}));
var EXT_REQUEST;
var BusExtBridge;
var init_bus_ext_bridge_gl = __esmMin((() => {
	EXT_REQUEST = ":EPOS_BUS_EXT_REQUEST";
	BusExtBridge = class extends gl.Unit {
		$bus = this.closest(gl.Bus);
		static EXT_REQUEST = EXT_REQUEST;
		constructor(parent) {
			super(parent);
			if (this.$.env.is.sw) this.setupSw();
			else if (this.$.env.is.csTop || this.$.env.is.os || this.$.env.is.pm || this.$.env.is.vw) this.setupCsTopOsPmVw();
		}
		async send(name, ...args) {
			const req = this.createRequest(name, args);
			const [result, error] = await this.$.utils.safe(() => this.$.browser.runtime.sendMessage(req));
			if (error && this.isIgnoredError(error)) return void 0;
			if (error) throw error;
			if (this.$.utils.is.undefined(result)) return void 0;
			if (!this.$.utils.is.string(result)) throw this.never();
			return await this.$bus.serializer.deserialize(result);
		}
		async sendToTab(tabId, name, ...args) {
			const req = this.createRequest(name, args);
			const [result, error] = await this.$.utils.safe(() => this.$.browser.tabs.sendMessage(tabId, req));
			if (error && this.isIgnoredError(error)) return void 0;
			if (error) throw error;
			if (this.$.utils.is.undefined(result)) return void 0;
			if (!this.$.utils.is.string(result)) throw this.never();
			return await this.$bus.serializer.deserialize(result);
		}
		setupSw() {
			this.$.browser.tabs.onRemoved.addListener((tabId) => {
				this.$bus.actions = this.$bus.actions.filter((action) => action.target !== tabId);
			});
			this.$.browser.runtime.onMessage.addListener((req, sender, respond) => {
				if (!this.isRequest(req)) return;
				const tabId = sender.tab?.id ?? null;
				if (req.name === "Bus.getTabInfo") {
					if (!tabId) throw this.never();
					const windowId = sender.tab?.windowId;
					if (!windowId) throw this.never();
					const tabInfo = {
						tabId,
						windowId
					};
					respond(this.$bus.serializer.serialize(tabInfo));
					return true;
				}
				if (req.name === "Bus.registerTabProxyAction") {
					(async () => {
						if (!tabId) throw this.never();
						const args = await this.$bus.serializer.deserialize(req.argsJson);
						if (!this.$.utils.is.array(args)) throw this.never();
						const [name] = args;
						if (!this.$.utils.is.string(name)) throw this.never();
						const fn = (...args) => this.sendToTab(tabId, name, ...args);
						this.$bus.on(name, fn, null, tabId);
					})();
					return;
				}
				if (req.name === "Bus.removeTabProxyAction") {
					(async () => {
						if (!tabId) return;
						const args = await this.$bus.serializer.deserialize(req.argsJson);
						if (!this.$.utils.is.array(args)) throw this.never();
						const [name] = args;
						if (!this.$.utils.is.string(name)) throw this.never();
						this.$bus.off(name, null, tabId);
					})();
					return;
				}
				if (req.name === "Bus.removeAllTabProxyActions") {
					if (!tabId) return;
					this.$bus.actions = this.$bus.actions.filter((action) => action.target !== tabId);
					return;
				}
				if (req.name === "Bus.getPageToken") {
					(async () => {
						if (tabId) {
							const pageToken = await this.sendToTab(tabId, "Bus.getPageToken");
							respond(this.$bus.serializer.serialize(pageToken));
						} else respond(this.$bus.serializer.serialize(null));
					})();
					return true;
				}
				if (req.name === "Bus.blobIdToObjectUrl") {
					(async () => {
						const args = await this.$bus.serializer.deserialize(req.argsJson);
						if (!this.$.utils.is.array(args)) throw this.never();
						const [blobId] = args;
						if (!this.$.utils.is.string(blobId)) throw this.never();
						const url = await this.$bus.serializer.blobIdToObjectUrl(blobId);
						respond(this.$bus.serializer.serialize(url));
					})();
					return true;
				}
				const actions = this.$bus.actions.filter((action) => action.name === req.name && (!tabId || action.target !== tabId));
				if (actions.length === 0) return;
				(async () => {
					const args = await this.$bus.serializer.deserialize(req.argsJson);
					if (!this.$.utils.is.array(args)) throw this.never();
					const result = await this.$bus.utils.pick(actions.map((action) => action.execute(...args)));
					respond(this.$bus.serializer.serialize(result));
				})();
				return true;
			});
		}
		setupCsTopOsPmVw() {
			if (this.$.env.is.csTop) this.send("Bus.removeAllTabProxyActions");
			this.$.browser.runtime.onMessage.addListener((req, _, respond) => {
				if (!this.isRequest(req)) return;
				if (this.$.env.is.csTop && req.name === "Bus.getPageToken") {
					respond(this.$bus.serializer.serialize(this.$bus.pageToken));
					return true;
				}
				const actions = this.$bus.actions.filter((action) => action.name === req.name);
				if (actions.length === 0) return;
				(async () => {
					const args = await this.$bus.serializer.deserialize(req.argsJson);
					if (!this.$.utils.is.array(args)) throw this.never();
					const result = await this.$bus.utils.pick(actions.map((action) => action.execute(...args)));
					respond(this.$bus.serializer.serialize(result));
				})();
				return true;
			});
		}
		createRequest(name, args) {
			return {
				type: EXT_REQUEST,
				name,
				argsJson: this.$bus.serializer.serialize(args)
			};
		}
		isRequest(message) {
			if (!this.$.utils.is.object(message)) return false;
			return message.type === EXT_REQUEST;
		}
		isIgnoredError(e) {
			if (!(e instanceof Error)) return false;
			return e.message.includes("Receiving end does not exist.") || e.message.includes("Extension context invalidated.");
		}
	};
}));
var PAGE_REQUEST;
var PAGE_RESPONSE;
var BusPageBridge;
var init_bus_page_bridge_gl = __esmMin((() => {
	PAGE_REQUEST = ":EPOS_BUS_PAGE_REQUEST";
	PAGE_RESPONSE = ":EPOS_BUS_PAGE_RESPONSE";
	BusPageBridge = class extends gl.Unit {
		$bus = this.closest(gl.Bus);
		removedContextListeners = /* @__PURE__ */ new Set();
		static PAGE_REQUEST = PAGE_REQUEST;
		static PAGE_RESPONSE = PAGE_RESPONSE;
		constructor(parent) {
			super(parent);
			if (this.$.env.is.csTop || this.$.env.is.os || this.$.env.is.vw) this.setupCsTopOsVw();
			else if (this.$.env.is.csFrame || this.$.env.is.ex) this.setupCsFrameEx();
			if (this.$.env.is.csTop || this.$.env.is.csFrame || this.$.env.is.vw || this.$.env.is.os) this.watchForRemovedIframes();
		}
		async sendToTop(name, ...args) {
			if (!self.top) throw this.never();
			return await this.sendToContext(self.top, name, ...args);
		}
		async sendToContext(context, name, ...args) {
			const req = this.createRequest(name, args);
			context.postMessage(req, "*");
			return await this.waitForResponse(req.id, context);
		}
		setupCsTopOsVw() {
			self.addEventListener("message", async (e) => {
				const req = e.data;
				if (!this.isRequest(req)) return;
				if (req.peerId === this.$bus.peerId) return;
				if (req.pageToken !== this.$bus.pageToken) return;
				const source = e.source;
				if (!source) return;
				if (req.name === "Bus.registerContextProxyAction") {
					const [name] = req.args;
					if (!this.$.utils.is.string(name)) throw this.never();
					const fn = (...args) => this.sendToContext(source, name, ...args);
					this.$bus.on(name, fn, null, source);
					return;
				}
				if (req.name === "Bus.removeContextProxyAction") {
					const [name] = req.args;
					if (!this.$.utils.is.string(name)) throw this.never();
					this.$bus.off(name, null, source);
					return;
				}
				if (req.name === "Bus.removeAllContextProxyActions") {
					this.removedContextListeners.forEach((fn) => fn(source));
					this.$bus.actions = this.$bus.actions.filter((action) => action.target !== source);
					return;
				}
				if (req.name === "Bus.invalidateProxyActions") {
					this.invalidateProxyActions();
					return;
				}
				const actions = this.$bus.actions.filter((action) => action.name === req.name && action.target !== source);
				const result = await this.$bus.utils.pick([...actions.map((action) => action.execute(...req.args)), this.$bus.extBridge.send(req.name, ...req.args)]);
				const res = this.createResponse(req.id, result);
				source.postMessage(res, "*");
			});
		}
		setupCsFrameEx() {
			this.sendToTop("Bus.removeAllContextProxyActions");
			self.addEventListener("message", async (e) => {
				const req = e.data;
				if (!this.isRequest(req)) return;
				const actions = this.$bus.actions.filter((action) => action.name === req.name);
				if (actions.length === 0) return;
				const result = await this.$bus.utils.pick(actions.map((action) => action.execute(...req.args)));
				const res = this.createResponse(req.id, result);
				if (!self.top) throw this.never();
				self.top.postMessage(res, "*");
			});
		}
		async waitForResponse(reqId, context) {
			const result$ = Promise.withResolvers();
			const onMessage = (e) => {
				const res = e.data;
				if (!this.isResponse(res)) return;
				if (res.reqId !== reqId) return;
				result$.resolve(res.result);
			};
			self.addEventListener("message", onMessage);
			const onRemovedContext = (removedContext) => {
				if (removedContext !== context) return;
				result$.resolve(void 0);
			};
			this.removedContextListeners.add(onRemovedContext);
			const timeout = setTimeout(() => result$.resolve(void 0), 1e4);
			const result = await result$.promise;
			clearTimeout(timeout);
			self.removeEventListener("message", onMessage);
			this.removedContextListeners.delete(onRemovedContext);
			return result;
		}
		watchForRemovedIframes() {
			const isElementNode = (node) => node.nodeType === Node.ELEMENT_NODE;
			new MutationObserver((mutations) => {
				for (const mutation of mutations) for (const node of mutation.removedNodes) {
					if (!isElementNode(node)) continue;
					if (!(node instanceof HTMLIFrameElement || !!node.querySelector("iframe"))) continue;
					if (this.$.env.is.csFrame) this.sendToTop("Bus.invalidateProxyActions");
					else this.invalidateProxyActions();
				}
			}).observe(document.documentElement, {
				childList: true,
				subtree: true
			});
		}
		/** Remove all proxy actions whose targets no longer exist. */
		invalidateProxyActions() {
			const availableContexts = new Set([self, ...this.getAllFrames()]);
			this.$bus.actions = this.$bus.actions.filter((action) => {
				if (!action.target) return true;
				const target = action.target;
				if (availableContexts.has(target)) return true;
				this.removedContextListeners.forEach((fn) => fn(target));
				return false;
			});
		}
		/** Recursively get all frames within the specified root (default: `self`). */
		getAllFrames(root = self) {
			const frames = [];
			for (let i = 0; i < root.frames.length; i++) {
				const frame = root.frames[i];
				if (!frame) throw this.never();
				const subframes = this.getAllFrames(frame);
				frames.push(frame, ...subframes);
			}
			return frames;
		}
		createRequest(name, args) {
			return {
				type: PAGE_REQUEST,
				id: this.$.utils.generateId(),
				name,
				args: this.$bus.serializer.sanitize(args),
				peerId: this.$bus.peerId,
				pageToken: this.$bus.pageToken
			};
		}
		createResponse(reqId, result) {
			return {
				type: PAGE_RESPONSE,
				reqId,
				result: this.$bus.serializer.sanitize(result)
			};
		}
		isRequest(message) {
			if (!this.$.utils.is.object(message)) return false;
			return message.type === PAGE_REQUEST;
		}
		isResponse(message) {
			if (!this.$.utils.is.object(message)) return false;
			return message.type === PAGE_RESPONSE;
		}
	};
}));
var REF;
var STORAGE_KEY;
var BusSerializer;
var init_bus_serializer_gl = __esmMin((() => {
	REF = ":EPOS_BUS_REF";
	STORAGE_KEY = ":EPOS_BUS_STORAGE_KEY";
	BusSerializer = class extends gl.Unit {
		$bus = this.closest(gl.Bus);
		blobs = /* @__PURE__ */ new Map();
		channel = null;
		static REF = REF;
		static STORAGE_KEY = STORAGE_KEY;
		constructor(parent) {
			super(parent);
			if (this.$.env.is.sw) this.channel = new BroadcastChannel("bus");
			if (this.$.env.is.os) {
				this.channel = new BroadcastChannel("bus");
				this.setupChannelListener();
			}
		}
		sanitize(data) {
			const { $ } = this;
			const storage = /* @__PURE__ */ new Map();
			const json = JSON.stringify(data, function(key) {
				const value = this[key];
				if ($.utils.is.blob(value) || $.utils.is.date(value) || $.utils.is.error(value) || $.utils.is.undefined(value)) {
					const key = $.utils.generateId();
					storage.set(key, value);
					return { [STORAGE_KEY]: key };
				}
				return value;
			});
			return this.populate(JSON.parse(json), storage);
		}
		serialize(data) {
			const { $, $bus, blobs } = this;
			return JSON.stringify(data, function(key) {
				const value = this[key];
				if ($.utils.is.blob(value)) if ($.env.is.sw) {
					const blobId = $.utils.generateId();
					blobs.set(blobId, value);
					setTimeout(() => blobs.delete(blobId), 6e4);
					return {
						[REF]: "blobId",
						id: blobId
					};
				} else {
					const url = $bus.utils.createTempObjectUrl(value);
					return {
						[REF]: "blobUrl",
						url
					};
				}
				if ($.utils.is.date(value)) return {
					[REF]: "date",
					iso: value.toISOString()
				};
				if ($.utils.is.error(value)) return {
					[REF]: "error",
					message: value.message,
					stack: value.stack
				};
				if ($.utils.is.undefined(value)) return { [REF]: "undefined" };
				return value;
			});
		}
		async deserialize(json) {
			const storage = /* @__PURE__ */ new Map();
			const promises = [];
			const data = JSON.parse(json, (_, value) => {
				if (!this.isRef(value)) return value;
				if (value[":EPOS_BUS_REF"] === "date") return new Date(value.iso);
				if (value[":EPOS_BUS_REF"] === "blobId") {
					const key = this.$.utils.generateId();
					const promise = (async () => {
						const url = await this.$bus.extBridge.send("Bus.blobIdToObjectUrl", value.id);
						if (!this.$.utils.is.string(url)) throw this.never();
						const blob = await fetch(url).then((r) => r.blob());
						storage.set(key, blob);
					})();
					promises.push(promise);
					return { [STORAGE_KEY]: key };
				}
				if (value[":EPOS_BUS_REF"] === "blobUrl") {
					const key = this.$.utils.generateId();
					const promise = (async () => {
						const blob = await fetch(value.url).then((r) => r.blob());
						storage.set(key, blob);
					})();
					promises.push(promise);
					return { [STORAGE_KEY]: key };
				}
				if (value[":EPOS_BUS_REF"] === "error") {
					const error = new Error(value.message);
					if (value.stack) error.stack = value.stack;
					return error;
				}
				if (value[":EPOS_BUS_REF"] === "undefined") {
					const key = this.$.utils.generateId();
					storage.set(key, void 0);
					return { [STORAGE_KEY]: key };
				}
				throw this.never();
			});
			await Promise.all(promises);
			return this.populate(data, storage);
		}
		async blobIdToObjectUrl(blobId) {
			const channel = this.channel;
			if (!channel) throw this.never();
			const blob = this.blobs.get(blobId);
			this.blobs.delete(blobId);
			const reqId = this.$.utils.generateId();
			const url$ = Promise.withResolvers();
			const onMessage = (e) => {
				const [resId, url] = e.data;
				if (reqId !== resId) return;
				channel.removeEventListener("message", onMessage);
				url$.resolve(url);
			};
			channel.addEventListener("message", onMessage);
			channel.postMessage([reqId, blob]);
			return await url$.promise;
		}
		isRef(value) {
			return this.$.utils.is.object(value) && ":EPOS_BUS_REF" in value;
		}
		isStorageLink(value) {
			return this.$.utils.is.object(value) && ":EPOS_BUS_STORAGE_KEY" in value;
		}
		populate(data, storage) {
			if (storage.size === 0) return data;
			if (this.isStorageLink(data)) {
				const key = data[STORAGE_KEY];
				const value = storage.get(key);
				storage.delete(key);
				return value;
			}
			if (this.$.utils.is.object(data)) {
				const object = {};
				for (const key in data) object[key] = this.populate(data[key], storage);
				return object;
			}
			if (this.$.utils.is.array(data)) return data.map((item) => this.populate(item, storage));
			return data;
		}
		setupChannelListener() {
			const channel = this.channel;
			if (!channel) throw this.never();
			channel.addEventListener("message", async (e) => {
				if (!this.$.utils.is.array(e.data)) throw this.never();
				const [reqId, blob] = e.data;
				if (!this.$.utils.is.string(reqId)) throw this.never();
				if (!this.$.utils.is.blob(blob)) throw this.never();
				const url = this.$bus.utils.createTempObjectUrl(blob);
				channel.postMessage([reqId, url]);
			});
		}
	};
}));
var THROW;
var BusUtils;
var init_bus_utils_gl = __esmMin((() => {
	THROW = ":EPOS_BUS_THROW";
	BusUtils = class extends gl.Unit {
		static THROW = THROW;
		createTempObjectUrl(blob) {
			const objectUrl = URL.createObjectURL(blob);
			setTimeout(() => URL.revokeObjectURL(objectUrl), 6e4);
			return objectUrl;
		}
		isThrowObject(value) {
			return this.$.utils.is.object(value) && ":EPOS_BUS_THROW" in value;
		}
		/** Resolves to the first non-undefined result, catches errors as `Throw` objects. */
		async pick(promises) {
			if (promises.length === 0) return void 0;
			const result$ = Promise.withResolvers();
			let processed = 0;
			for (const promise of promises) {
				if (!promise) continue;
				(async () => {
					const [result, error] = await this.$.utils.safe(promise);
					processed += 1;
					if (error) {
						const message = error?.message ?? "Unexpected error";
						const throwObject = {
							[THROW]: true,
							message
						};
						result$.resolve(throwObject);
						throw error;
					} else if (!this.$.utils.is.undefined(result)) result$.resolve(result);
					else if (processed === promises.length) result$.resolve(void 0);
				})();
			}
			return await result$.promise;
		}
	};
}));
var Bus;
var init_bus_gl = __esmMin((() => {
	Bus = class extends gl.Unit {
		peerId = this.$.utils.generateId();
		pageToken = null;
		actions = [];
		utils = new gl.BusUtils(this);
		registeredNames = /* @__PURE__ */ new Set();
		serializer = new gl.BusSerializer(this);
		extBridge = new gl.BusExtBridge(this);
		pageBridge = new gl.BusPageBridge(this);
		async initPageToken() {
			if (!(this.$.env.is.cs || this.$.env.is.ex)) throw this.never();
			if (this.$.env.is.csTop) this.pageToken = this.$.utils.generateId();
			else if (this.$.env.is.csFrame) {
				const pageToken = await this.extBridge.send("Bus.getPageToken");
				if (this.$.utils.is.undefined(pageToken)) throw this.never();
				this.pageToken = pageToken;
			} else if (this.$.env.is.ex && !this.$.env.is.exExtension) {
				const pageToken = self.__eposBusPageToken;
				delete self.__eposBusPageToken;
				if (this.$.utils.is.undefined(pageToken)) throw new Error("Page token is not passed to `ex`");
				this.pageToken = pageToken;
			}
		}
		on(name, fn, thisArg, target) {
			if (!fn) return;
			if (this.$.env.is.cs || this.$.env.is.ex) {
				if (this.actions.filter((action) => action.name === name).length === 0) if (this.$.env.is.csTop) this.extBridge.send("Bus.registerTabProxyAction", name);
				else this.pageBridge.sendToTop("Bus.registerContextProxyAction", name);
			}
			const action = new gl.BusAction(this, name, fn, thisArg, target);
			this.actions.push(action);
		}
		off(name, fn, target) {
			this.actions = this.actions.filter((action) => {
				const nameMatches = action.name === name;
				const fnMatches = !fn || action.fn === fn;
				const targetMatches = target ? action.target === target : !action.target;
				if (nameMatches && fnMatches && targetMatches) return false;
				return true;
			});
			if (this.$.env.is.cs || this.$.env.is.ex) {
				if (this.actions.filter((action) => action.name === name).length === 0) if (this.$.env.is.csTop) this.extBridge.send("Bus.removeTabProxyAction", name);
				else this.pageBridge.sendToTop("Bus.removeContextProxyAction", name);
			}
		}
		async send(name, ...args) {
			let result;
			if (this.$.env.is.csTop || this.$.env.is.os || this.$.env.is.pm || this.$.env.is.sw || this.$.env.is.vw) result = await this.utils.pick([this.extBridge.send(name, ...args), this.executeProxyActions(name, ...args)]);
			else if (this.$.env.is.csFrame || this.$.env.is.ex) result = await this.pageBridge.sendToTop(name, ...args);
			if (this.utils.isThrowObject(result)) {
				const error = new Error(result.message);
				Error.captureStackTrace(error, this.send);
				throw error;
			}
			return result;
		}
		async emit(name, ...args) {
			const actions = this.actions.filter((action) => action.name === name && !action.target);
			return await this.utils.pick(actions.map((action) => action.execute(...args)));
		}
		once(name, fn, thisArg) {
			const handler = async (...args) => {
				this.off(name, handler);
				return await fn(...args);
			};
			this.on(name, handler, thisArg);
		}
		setSignal(name, value = true) {
			name = `Bus.signal[${name}]`;
			this.on(name, () => value);
			this.send(name, value);
		}
		async waitSignal(name, timeout) {
			name = `Bus.signal[${name}]`;
			const listener$ = Promise.withResolvers();
			const listener = (value) => listener$.resolve(value);
			this.on(name, listener);
			const timer$ = Promise.withResolvers();
			let timer = null;
			if (timeout) timer = setTimeout(() => timer$.resolve(void 0), timeout);
			const result = await this.utils.pick([
				this.send(name),
				listener$.promise,
				timer$.promise
			]);
			this.off(name, listener);
			if (timer) clearTimeout(timer);
			return result;
		}
		register(name, api) {
			if (this.registeredNames.has(name)) return;
			this.registeredNames.add(name);
			this.on(`Bus.remote[${name}]`, (key, ...args) => {
				const fn = api[key];
				if (!this.$.utils.is.function(fn)) throw new Error(`Method not found: '${key}'`);
				return fn.call(api, ...args);
			});
		}
		unregister(name) {
			if (!this.registeredNames.has(name)) return;
			this.registeredNames.delete(name);
			this.off(`Bus.remote[${name}]`);
		}
		use(name) {
			return new Proxy({}, { get: (_, key) => {
				return (...args) => this.send(`Bus.remote[${name}]`, key, ...args);
			} });
		}
		for(namespace) {
			const prefix = `@${namespace}_`;
			const prefixed = (name) => `${prefix}${name}`;
			let disposed = false;
			return {
				on: (name, fn, thisArg) => {
					if (disposed) return;
					this.on(prefixed(name), fn, thisArg);
				},
				off: (name, fn) => {
					if (disposed) return;
					this.off(prefixed(name), fn);
				},
				send: async (name, ...args) => {
					if (disposed) return void 0;
					return await this.send(prefixed(name), ...args);
				},
				emit: async (name, ...args) => {
					if (disposed) return void 0;
					return await this.emit(prefixed(name), ...args);
				},
				once: (name, fn, thisArg) => {
					if (disposed) return;
					this.once(prefixed(name), fn, thisArg);
				},
				setSignal: (name, ...args) => {
					if (disposed) return;
					this.setSignal(prefixed(name), ...args);
				},
				waitSignal: async (name, timeout) => {
					if (disposed) return void 0;
					return await this.waitSignal(prefixed(name), timeout);
				},
				register: (id, api) => {
					if (disposed) return;
					this.register(prefixed(id), api);
				},
				unregister: (id) => {
					if (disposed) return;
					this.unregister(prefixed(id));
				},
				use: (id) => {
					if (disposed) throw new Error("Cannot call `use` on disposed Bus");
					return this.use(prefixed(id));
				},
				dispose: () => {
					if (disposed) return;
					disposed = true;
					this.actions.filter((action) => action.name.startsWith(prefix)).forEach((action) => this.off(action.name, action.fn, action.target));
				}
			};
		}
		async getTabInfo() {
			if (this.$.env.is.csTop || this.$.env.is.vw) {
				const result = await this.extBridge.send("Bus.getTabInfo");
				if (!result) throw this.never();
				return {
					tabId: result.tabId,
					windowId: result.windowId
				};
			}
			return {
				tabId: -1,
				windowId: -1
			};
		}
		async executeProxyActions(name, ...args) {
			const actions = this.actions.filter((action) => action.name === name && action.target);
			return await this.utils.pick(actions.map((action) => action.execute(...args)));
		}
	};
}));
var EnvIs;
var init_env_is_gl = __esmMin((() => {
	EnvIs = class extends gl.Unit {
		dev = true;
		prod = false;
		cs = false;
		ex = true;
		os = false;
		pm = false;
		sw = false;
		vw = false;
		csTop = this.cs && self === top;
		csFrame = this.cs && self !== top;
		exTop = this.ex && self === top;
		exFrame = this.ex && self !== top;
		exExtension = this.ex && location.protocol === "chrome-extension:";
		vwPage = this.vw && new URLSearchParams(location.search).get("locus") === "page";
		vwPopup = this.vw && new URLSearchParams(location.search).get("locus") === "popup";
		vwSidePanel = this.vw && new URLSearchParams(location.search).get("locus") === "sidePanel";
	};
}));
var EnvUrl;
var init_env_url_gl = __esmMin((() => {
	EnvUrl = class extends gl.Unit {
		offscreen() {
			return "/offscreen.html";
		}
		permission() {
			return "/permission.html";
		}
		view(params) {
			if (params.locus === "page" && (params.tabId || params.windowId)) throw this.never();
			if (params.locus !== "page" && (!params.tabId || !params.windowId)) throw this.never();
			return `/view.html?${this.toSearchParams(params)}`;
		}
		project(params) {
			if (params.locus === "background" && (params.tabId || params.windowId)) throw this.never();
			if (params.locus !== "background" && (!params.tabId || !params.windowId)) throw this.never();
			return `/project.html?${this.toSearchParams(params)}`;
		}
		toSearchParams(params) {
			const entries = Object.entries(params).filter(([, value]) => this.$.utils.is.present(value) && value !== false).map(([key, value]) => [key, String(value)]);
			return new URLSearchParams(entries).toString();
		}
	};
}));
var Env;
var init_env_gl = __esmMin((() => {
	Env = class extends gl.Unit {
		is = new gl.EnvIs(this);
		url = new gl.EnvUrl(this);
		extParams = this.getExtParams();
		getExtParams() {
			const { protocol, searchParams } = new URL(location.href);
			if (protocol !== "chrome-extension:") return {};
			return Object.fromEntries(searchParams.entries());
		}
	};
}));
var init_layer_gl = __esmMin((() => {
	init_bus_action_gl();
	init_bus_ext_bridge_gl();
	init_bus_page_bridge_gl();
	init_bus_serializer_gl();
	init_bus_utils_gl();
	init_bus_gl();
	init_env_is_gl();
	init_env_url_gl();
	init_env_gl();
	Object.assign(gl, {
		BusAction,
		BusExtBridge,
		BusPageBridge,
		BusSerializer,
		BusUtils,
		Bus,
		EnvIs,
		EnvUrl,
		Env
	});
}));
var random$1;
var customRandom;
var customAlphabet;
var init_index_browser = __esmMin((() => {
	random$1 = /* @__PURE__ */ __name$1((bytes) => crypto.getRandomValues(new Uint8Array(bytes)), "random");
	customRandom = (alphabet, defaultSize, getRandom) => {
		let mask = (2 << Math.log2(alphabet.length - 1)) - 1;
		let step = -~(1.6 * mask * defaultSize / alphabet.length);
		return (size = defaultSize) => {
			let id = "";
			while (true) {
				let bytes = getRandom(step);
				let j = step | 0;
				while (j--) {
					id += alphabet[bytes[j] & mask] || "";
					if (id.length >= size) return id;
				}
			}
		};
	};
	customAlphabet = (alphabet, size = 21) => customRandom(alphabet, size | 0, random$1);
}));
function generateId() {
	return nanoid();
}
var nanoid;
var init_utils_generate_id = __esmMin((() => {
	init_index_browser();
	nanoid = customAlphabet("abcdefghijklmnopqrstuvwxyz0123456789", 10);
}));

//#endregion
//#region dist/ORIGINALS/assets/layer.ex.os.vw-WwfUYKPW.js
var ProjectsWatcher;
var init_projects_watcher_ex_os_vw = __esmMin((() => {
	ProjectsWatcher = class extends exOsVw.Unit {
		onData;
		entries = {};
		$projects = this.closest("Projects");
		constructor(parent, onData) {
			super(parent);
			this.onData = onData;
		}
		async init() {
			this.$projects.bus.on("changes", () => this.refresh());
			await this.refresh();
		}
		async refresh() {
			const entries = await this.$projects.sw.getEntries(location.href);
			if (!entries) throw this.never();
			const e1 = this.entries;
			const e2 = entries;
			this.entries = entries;
			const ids1 = Object.keys(e1);
			const addedProjectIds = Object.keys(e2).filter((id) => !e1[id]);
			const removedProjectIds = ids1.filter((id) => !e2[id]);
			const retainedProjectIds = ids1.filter((id) => e2[id]);
			const reloadedProjectIds = ids1.filter((id) => e1[id] && e2[id] && e1[id].hash !== e2[id].hash);
			this.onData({
				entries,
				addedProjectIds,
				removedProjectIds,
				retainedProjectIds,
				reloadedProjectIds
			});
		}
	};
}));
var init_layer_ex_os_vw = __esmMin((() => {
	init_projects_watcher_ex_os_vw();
	Object.assign(exOsVw, { ProjectsWatcher });
}));

//#endregion
//#region dist/ORIGINALS/assets/layer.ex.os-BLo5yd02.js
var Peer;
var init_peer_ex_os = __esmMin((() => {
	Peer = class extends exOs.Unit {
		id = this.$.utils.generateId();
		constructor(parent) {
			super(parent);
			this.$.bus.on(`Peer.ping[${this.id}]`, () => true);
		}
		async mutex(name, fn) {
			await this.$.bus.send("Peer.start", name, this.id);
			const [, error] = await this.$.utils.safe(fn);
			await this.$.bus.send(`Peer.end[${name}][${this.id}]`);
			if (error) throw error;
		}
	};
}));
var init_layer_ex_os = __esmMin((() => {
	init_peer_ex_os();
	Object.assign(exOs, { Peer });
}));

//#endregion
//#region dist/ORIGINALS/assets/utils-time-qVkPSmYX.js
/**
* time('12h 30m 15s 2ms') -> 45015002
*/
function time(timeStr) {
	const parts = timeStr.split(/\s+/);
	let ms = 0;
	for (const part of parts) {
		const value = parseInt(part, 10);
		if (isNaN(value)) throw new Error("Invalid time string");
		if (part.endsWith("ms")) ms += value;
		else if (part.endsWith("s")) ms += value * SECOND;
		else if (part.endsWith("m")) ms += value * MINUTE;
		else if (part.endsWith("h")) ms += value * HOUR;
		else if (part.endsWith("d")) ms += value * DAY;
		else if (part.endsWith("w")) ms += value * WEEK;
		else throw new Error("Invalid time string");
	}
	return ms;
}
var SECOND;
var MINUTE;
var HOUR;
var DAY;
var WEEK;
var init_utils_time = __esmMin((() => {
	SECOND = 1e3;
	MINUTE = 1e3 * 60;
	HOUR = 1e3 * 60 * 60;
	DAY = 1e3 * 60 * 60 * 24;
	WEEK = 1e3 * 60 * 60 * 24 * 7;
}));

//#endregion
//#region dist/ORIGINALS/assets/yjs-Ce_RUhJI.js
var _meta_;
var _parent_;
var _attach_;
var _detach_;
var ProjectState;
var init_project_state_ex_sw = __esmMin((() => {
	_meta_ = Symbol("meta");
	_parent_ = Symbol("parent");
	_attach_ = Symbol("attach");
	_detach_ = Symbol("detach");
	ProjectState = class extends exSw.Unit {
		static _meta_ = _meta_;
		static _parent_ = _parent_;
		static _attach_ = _attach_;
		static _detach_ = _detach_;
		name;
		root = {};
		$states = this.closest(exSw.ProjectStates);
		$project = this.closest("Project");
		doc = new this.$.libs.yjs.Doc();
		local;
		initial = null;
		versioner;
		connected = false;
		bus;
		applyingYjsToMobx = false;
		attachQueue = [];
		saveTimeout = -1;
		SAVE_DELAY = 300;
		get location() {
			return [
				this.$project.id,
				":state",
				this.name
			];
		}
		constructor(parent, name, initial, versioner) {
			super(parent);
			this.name = name ?? `local:${this.$.utils.generateId()}`;
			this.initial = initial ?? {};
			this.versioner = versioner ?? {};
			this.local = name === null;
			this.bus = this.$.bus.for(`ProjectState[${this.$project.id}][${this.name}]`);
			this.save = this.$.utils.enqueue(this.save, this);
			if (this.local) this.initLocal();
		}
		async init() {
			if (this.local) throw this.never();
			await this.$.peer.mutex(`ProjectState.setup[${this.$project.id}][${this.name}]`, () => this.setup());
			this.bus.on("connected", () => true);
		}
		initLocal() {
			const initial = this.getInitialState();
			this.root = this.attach(initial, null);
			this.flushAttachQueue();
			this.connected = true;
		}
		async disconnect() {
			if (this.local) return;
			if (!this.connected) return;
			this.connected = false;
			this.bus.dispose();
			this.doc.destroy();
			await this.save(true);
		}
		transaction(fn) {
			this.$.libs.mobx.runInAction(() => {
				if (this.local) fn();
				else this.doc.transact(() => fn());
			});
		}
		async hasPeers() {
			return !!await this.bus.send("connected");
		}
		async setup() {
			const missedUpdates = [];
			this.bus.on("update", async (update) => {
				if (this.connected) await this.applyUpdate(update);
				else missedUpdates.push(update);
			});
			if (this.$.env.is.sw) {
				const root = await this.$.idb.get(...this.location);
				this.root = this.attach(root ?? {}, null);
				this.bus.on("swGetDocAsUpdate", () => new Blob([this.$.libs.yjs.encodeStateAsUpdate(this.doc)]));
			} else if (this.$.env.is.ex) {
				const docAsUpdate = await this.bus.send("swGetDocAsUpdate");
				if (!docAsUpdate) throw this.never();
				await this.applyUpdate(docAsUpdate);
				const yRoot = this.doc.getMap("root");
				this.root = this.attach(yRoot, null);
			}
			for (const update of missedUpdates) await this.applyUpdate(update);
			this.doc.on("update", async (update, origin) => {
				if (origin !== null) return;
				await this.bus.send("update", new Blob([update]));
			});
			this.transaction(() => {
				if (!this.$.utils.is.object(this.root)) throw this.never();
				const asc = (v1, v2) => v1 - v2;
				const versions = Object.keys(this.versioner).filter(this.$.utils.is.numeric).map(Number).sort(asc);
				if (Object.keys(this.root).length === 0) {
					const initial = this.getInitialState();
					this.detach(this.root);
					this.root = this.attach(initial, null);
					if (!this.$.utils.is.object(this.root)) throw this.never();
					if (versions.length > 0) this.root[":version"] = versions.at(-1);
				} else for (const version of versions) {
					if (this.$.utils.is.number(this.root[":version"]) && this.root[":version"] >= version) continue;
					const versionFn = this.versioner[version];
					if (!versionFn) throw this.never();
					versionFn.call(this.root, this.root);
					this.root[":version"] = version;
				}
				this.connected = true;
				this.flushAttachQueue();
				this.initial = null;
			});
			this.saveWithDelay();
		}
		attach(value, parent) {
			if (value instanceof this.$.libs.yjs.Map) return this.attachYMap(value, parent);
			if (value instanceof this.$.libs.yjs.Array) return this.attachYArray(value, parent);
			if (this.$.utils.is.object(value)) return this.attachObject(value, parent);
			if (this.$.utils.is.array(value)) return this.attachArray(value, parent);
			if (this.local || this.isSupportedValue(value)) return value;
			console.error("Unsupported value:", value);
			const message = `State does not support ${value?.constructor.name ?? typeof value} values`;
			throw new Error(`${message}. Supported types: object, array, string, number, boolean, null, undefined.`);
		}
		attachYMap(yMap, parent) {
			const tag = this.$.utils.is.string(yMap.get("@")) ? String(yMap.get("@")) : null;
			const Model = tag ? this.getModelByName(tag) : null;
			const mObject = this.$.libs.mobx.observable.object({}, {}, { deep: false });
			this.wire(mObject, yMap, parent);
			if (Model) Reflect.setPrototypeOf(mObject, Model.prototype);
			const prevApplyingYjsToMobx = this.applyingYjsToMobx;
			this.applyingYjsToMobx = true;
			yMap.forEach((value, key) => mObject[key] = value);
			this.applyingYjsToMobx = prevApplyingYjsToMobx;
			this.processAttach(mObject);
			return mObject;
		}
		attachYArray(yArray, parent) {
			const mArray = this.$.libs.mobx.observable.array([], { deep: false });
			this.wire(mArray, yArray, parent);
			const prevApplyingYjsToMobx = this.applyingYjsToMobx;
			this.applyingYjsToMobx = true;
			yArray.forEach((item) => mArray.push(item));
			this.applyingYjsToMobx = prevApplyingYjsToMobx;
			return mArray;
		}
		attachObject(object, parent) {
			const tag = this.$.utils.is.string(object["@"]) ? object["@"] : null;
			const ModelByTag = tag ? this.getModelByName(tag) : null;
			const ModelByInstance = this.getModelByInstance(object);
			const Model = ModelByTag ?? ModelByInstance;
			if (this.local) {
				const isClassInstance = object.constructor !== Object;
				if (!Model && isClassInstance) return this.$.libs.mobx.makeAutoObservable(object);
			}
			const mObject = this.$.libs.mobx.observable.object({}, {}, { deep: false });
			const yMap = !parent ? this.doc.getMap("root") : new this.$.libs.yjs.Map();
			this.wire(mObject, yMap, parent);
			if (Model) Reflect.setPrototypeOf(mObject, Model.prototype);
			if (ModelByInstance) mObject["@"] = this.getModelName(ModelByInstance);
			Object.keys(object).forEach((key) => mObject[key] = object[key]);
			this.processAttach(mObject);
			return mObject;
		}
		attachArray(array, parent) {
			const mArray = this.$.libs.mobx.observable.array([], { deep: false });
			const yArray = new this.$.libs.yjs.Array();
			this.wire(mArray, yArray, parent);
			array.forEach((item) => mArray.push(item));
			return mArray;
		}
		detach(target) {
			const meta = this.getMeta(target);
			if (!meta) return;
			meta.unwire();
			if (this.$.utils.is.object(target)) {
				Object.keys(target).forEach((key) => this.detach(target[key]));
				if (this.$.utils.is.function(target[_detach_])) target[_detach_]();
			} else if (this.$.utils.is.array(target)) target.forEach((item) => this.detach(item));
		}
		wire(mNode, yNode, parent) {
			const unwire = () => {
				unobserveMNode();
				yNode.unobserve(this.onYNodeChange);
				delete mNode[_meta_];
				delete yNode[_meta_];
				delete mNode[_parent_];
				delete mNode._;
				delete yNode._;
			};
			const unobserveMNode = this.$.libs.mobx.intercept(mNode, this.onMNodeChange);
			yNode.observe(this.onYNodeChange);
			const meta = {
				mNode,
				yNode,
				unwire
			};
			Reflect.defineProperty(mNode, _meta_, {
				configurable: true,
				get: () => meta
			});
			Reflect.defineProperty(yNode, _meta_, {
				configurable: true,
				get: () => meta
			});
			Reflect.defineProperty(mNode, _parent_, {
				configurable: true,
				get: () => parent
			});
			Reflect.defineProperty(mNode, "_", {
				configurable: true,
				get: () => this.$.libs.mobx.toJS(mNode)
			});
			Reflect.defineProperty(yNode, "_", {
				configurable: true,
				get: () => yNode.toJSON()
			});
		}
		processAttach(mObject) {
			const attach = mObject[_attach_];
			if (!this.$.utils.is.function(attach)) return;
			if (this.connected) attach.call(mObject);
			else this.attachQueue.push(() => attach.call(mObject));
		}
		flushAttachQueue() {
			this.attachQueue.forEach((attach) => attach());
			this.attachQueue = [];
		}
		onMNodeChange = (change) => {
			if (this.isMObjectChange(change)) {
				if (change.type === "add" || change.type === "update") {
					if (this.processMObjectSet(change)) return;
				} else if (change.type === "remove") this.processMObjectRemove(change);
			} else if (change.type === "update") this.processMArrayUpdate(change);
			else if (change.type === "splice") this.processMArraySplice(change);
			this.saveWithDelay();
			return change;
		};
		processMObjectSet(change) {
			if (this.$.utils.is.symbol(change.name)) return;
			const hasOwnProperty = Object.hasOwn(change.object, change.name);
			if (change.newValue === void 0 && !hasOwnProperty) return;
			if (change.name in change.object && !hasOwnProperty) {
				const owner = this.$.utils.getPrototypes(change.object).find((prototype) => Object.hasOwn(prototype, change.name));
				const descriptor = owner ? Reflect.getOwnPropertyDescriptor(owner, change.name) : null;
				if (descriptor && (descriptor.get || descriptor.set)) {
					if (descriptor.set) descriptor.set.call(change.object, change.newValue);
					return true;
				}
			}
			if (change.newValue === change.object[change.name]) return;
			change.newValue = this.attach(change.newValue, change.object);
			this.detach(change.object[change.name]);
			if (!this.local && !this.applyingYjsToMobx) this.doc.transact(() => {
				const yMap = this.getYNode(change.object);
				if (!yMap) throw this.never();
				yMap.set(String(change.name), this.getYNode(change.newValue) ?? change.newValue);
			});
		}
		processMObjectRemove(change) {
			if (this.$.utils.is.symbol(change.name)) return;
			this.detach(change.object[change.name]);
			if (!this.local && !this.applyingYjsToMobx) this.doc.transact(() => {
				const yMap = this.getYNode(change.object);
				if (!yMap) throw this.never();
				yMap.delete(String(change.name));
			});
		}
		processMArrayUpdate(change) {
			change.newValue = this.attach(change.newValue, change.object);
			this.detach(change.object[change.index]);
			if (!this.local && !this.applyingYjsToMobx) this.doc.transact(() => {
				const yArray = this.getYNode(change.object);
				if (!yArray) throw this.never();
				yArray.delete(change.index);
				yArray.insert(change.index, [this.getYNode(change.newValue) ?? change.newValue]);
			});
		}
		processMArraySplice(change) {
			change.added = change.added.map((item) => this.attach(item, change.object));
			for (let i = change.index; i < change.index + change.removedCount; i++) this.detach(change.object[i]);
			if (!this.local && !this.applyingYjsToMobx) this.doc.transact(() => {
				const yArray = this.getYNode(change.object);
				if (!yArray) throw this.never();
				const yAdded = change.added.map((value, index) => this.getYNode(change.added[index]) ?? value);
				yArray.delete(change.index, change.removedCount);
				yArray.insert(change.index, yAdded);
			});
		}
		isMObjectChange(change) {
			return this.$.utils.is.object(change.object);
		}
		onYNodeChange = async (e) => {
			if (e.transaction.origin !== "remote") return;
			if (e instanceof this.$.libs.yjs.YMapEvent) this.processYMapChange(e);
			else this.processYArrayChange(e);
		};
		processYMapChange(e) {
			const yMap = e.target;
			const mObject = this.getMNode(yMap);
			if (!mObject) throw this.never();
			this.$.libs.mobx.runInAction(() => {
				this.applyingYjsToMobx = true;
				for (const key of e.keysChanged) {
					this.detach(mObject[key]);
					if (yMap.has(key)) mObject[key] = yMap.get(key);
					else delete mObject[key];
				}
				this.applyingYjsToMobx = false;
			});
		}
		processYArrayChange(e) {
			const yArray = e.target;
			const mArray = this.getMNode(yArray);
			if (!mArray) throw this.never();
			this.$.libs.mobx.runInAction(() => {
				this.applyingYjsToMobx = true;
				let offset = 0;
				for (const operation of e.delta) if (operation.retain) offset += operation.retain;
				else if (operation.delete) {
					for (let i = offset; i < offset + operation.delete; i++) this.detach(mArray[i]);
					mArray.splice(offset, operation.delete);
				} else if (operation.insert) {
					if (!this.$.utils.is.array(operation.insert)) throw this.never();
					mArray.splice(offset, 0, ...operation.insert);
					offset += operation.insert.length;
				}
				this.applyingYjsToMobx = false;
			});
		}
		async save(force = false) {
			if (this.local) return;
			if (!this.$.env.is.sw) return;
			if (!this.connected && !force) return;
			if (!this.root) throw this.never();
			clearTimeout(this.saveTimeout);
			const root = this.$.libs.mobx.toJS(this.root);
			const [_, error] = await this.$.utils.safe(this.$.idb.set(...this.location, root));
			if (error) this.log.error("Failed to save state to IndexedDB", error);
		}
		saveWithDelay() {
			if (this.local) return;
			if (!this.$.env.is.sw) return;
			if (!this.connected) return;
			clearTimeout(this.saveTimeout);
			this.saveTimeout = setTimeout(() => this.save(), this.SAVE_DELAY);
		}
		async applyUpdate(update) {
			const buffer = await update.arrayBuffer();
			this.$.libs.yjs.applyUpdate(this.doc, new Uint8Array(buffer), "remote");
		}
		getMeta(target) {
			return target?.[_meta_] ?? null;
		}
		getMNode(yNode) {
			const meta = this.getMeta(yNode);
			if (!meta) return null;
			return meta.mNode;
		}
		getYNode(mNode) {
			const meta = this.getMeta(mNode);
			if (!meta) return null;
			return meta.yNode;
		}
		getModelByName(name) {
			const Model = this.$states.models[name];
			if (Model) return Model;
			if (this.$.env.is.sw || this.$states.config.allowMissingModels) return null;
			const message = `Model '${name}' is not registered`;
			throw new Error(`${message}. Make sure you registered it via epos.state.register() before calling epos.state.connect(). To allow missing models, set config.allowMissingModels to true in epos.json.`);
		}
		getModelByInstance(instance) {
			if (instance.constructor === Object) return null;
			const Model = Object.values(this.$states.models).find((Model) => instance.constructor === Model) ?? null;
			if (Model) return Model;
			if (this.$.env.is.sw || this.$states.config.allowMissingModels) return null;
			const message = `Class '${instance.constructor.name}' is not registered as a model`;
			throw new Error(`${message}. Make sure you registered it via epos.state.register(). To allow missing models, set config.allowMissingModels to true in epos.json.`);
		}
		getInitialState() {
			if (!this.$.utils.is.object(this.initial)) throw new Error("Initial state must be an object");
			return this.initial;
		}
		getModelName(Model) {
			return Object.keys(this.$states.models).find((name) => this.$states.models[name] === Model) ?? null;
		}
		isSupportedValue(value) {
			return this.$.utils.is.object(value) || this.$.utils.is.array(value) || this.$.utils.is.string(value) || this.$.utils.is.number(value) || this.$.utils.is.boolean(value) || this.$.utils.is.null(value);
		}
	};
}));
var ProjectStates;
var init_project_states_ex_sw = __esmMin((() => {
	ProjectStates = class ProjectStates extends exSw.Unit {
		id;
		dict = {};
		config;
		models = {};
		$project = this.closest("Project");
		bus;
		queue = new this.$.utils.Queue();
		autoDisconnectInterval = -1;
		static instanceIds = /* @__PURE__ */ new Set();
		get list() {
			return Object.values(this.dict);
		}
		constructor(parent, config) {
			super(parent);
			this.id = `ProjectStates[${this.$project.id}]`;
			this.config = config ?? { allowMissingModels: false };
			this.bus = this.$.bus.for(`ProjectStates[${this.$project.id}]`);
			this.connect = this.queue.wrap(this.connect, this);
			this.disconnect = this.queue.wrap(this.disconnect, this);
			if (ProjectStates.instanceIds.has(this.id)) throw this.never();
			ProjectStates.instanceIds.add(this.id);
			if (this.$.env.is.ex) this.bus.on("exDisconnect", this.disconnect, this);
			else if (this.$.env.is.sw) {
				this.bus.on("swConnect", this.voidify(this.connect), this);
				this.bus.on("swRemove", this.remove, this);
				this.setupAutoDisconnect();
			}
		}
		async connect(name, initial, versioner) {
			if (this.dict[name]) return this.dict[name].root;
			if (this.$.env.is.ex) await this.bus.send("swConnect", name);
			const state = new exSw.ProjectState(this, name, initial, versioner);
			await state.init();
			this.dict[name] = state;
			return state.root;
		}
		async disconnect(name) {
			const state = this.dict[name];
			if (!state) return;
			await state.disconnect();
			delete this.dict[name];
		}
		async remove(name) {
			if (this.$.env.is.ex) {
				await this.disconnect(name);
				await this.bus.send("swRemove", name);
			} else if (this.$.env.is.sw) {
				await this.disconnect(name);
				await this.bus.send("exDisconnect", name);
				await this.$.idb.delete(this.$project.id, ":state", name);
			}
		}
		local(initial) {
			return new exSw.ProjectState(this, null, initial).root;
		}
		transaction(fn) {
			let transaction = () => fn();
			for (const state of this.list) {
				const previousTransaction = transaction;
				transaction = () => state.transaction(() => previousTransaction());
			}
			this.$.libs.mobx.runInAction(() => transaction());
		}
		register(models) {
			Object.assign(this.models, models);
		}
		isConnected(name) {
			return name in this.dict;
		}
		async dispose() {
			this.bus.dispose();
			clearInterval(this.autoDisconnectInterval);
			for (const name in this.dict) await this.disconnect(name);
			await this.$.idb.deleteStore(this.$project.id, ":state");
			ProjectStates.instanceIds.delete(this.id);
		}
		/** Automatically disconnect `sw` state if there are no `ex` connections to it. */
		setupAutoDisconnect() {
			if (!this.$.env.is.sw) return;
			this.autoDisconnectInterval = setInterval(async () => {
				for (const state of this.list) if (!await state.hasPeers()) await this.disconnect(state.name);
			}, this.$.utils.time("15s"));
		}
		voidify(fn) {
			return async (...args) => {
				await fn.call(this, ...args);
			};
		}
	};
}));
var init_layer_ex_sw = __esmMin((() => {
	init_project_state_ex_sw();
	init_project_states_ex_sw();
	Object.assign(exSw, {
		ProjectState,
		ProjectStates
	});
}));
var mobx_esm_exports = /* @__PURE__ */ __exportAll({
	$mobx: () => $mobx,
	FlowCancellationError: () => FlowCancellationError,
	ObservableMap: () => ObservableMap,
	ObservableSet: () => ObservableSet,
	Reaction: () => Reaction,
	_allowStateChanges: () => allowStateChanges,
	_allowStateChangesInsideComputed: () => runInAction,
	_allowStateReadsEnd: () => allowStateReadsEnd,
	_allowStateReadsStart: () => allowStateReadsStart,
	_autoAction: () => autoAction,
	_endAction: () => _endAction,
	_getAdministration: () => getAdministration,
	_getGlobalState: () => getGlobalState,
	_interceptReads: () => interceptReads,
	_isComputingDerivation: () => isComputingDerivation,
	_resetGlobalState: () => resetGlobalState,
	_startAction: () => _startAction,
	action: () => action,
	autorun: () => autorun,
	comparer: () => comparer,
	computed: () => computed,
	configure: () => configure,
	createAtom: () => createAtom,
	defineProperty: () => apiDefineProperty,
	entries: () => entries,
	extendObservable: () => extendObservable,
	flow: () => flow,
	flowResult: () => flowResult,
	get: () => get,
	getAtom: () => getAtom,
	getDebugName: () => getDebugName,
	getDependencyTree: () => getDependencyTree,
	getObserverTree: () => getObserverTree,
	has: () => has,
	intercept: () => intercept,
	isAction: () => isAction,
	isBoxedObservable: () => isObservableValue,
	isComputed: () => isComputed,
	isComputedProp: () => isComputedProp,
	isFlow: () => isFlow,
	isFlowCancellationError: () => isFlowCancellationError,
	isObservable: () => isObservable,
	isObservableArray: () => isObservableArray,
	isObservableMap: () => isObservableMap,
	isObservableObject: () => isObservableObject,
	isObservableProp: () => isObservableProp,
	isObservableSet: () => isObservableSet,
	keys: () => keys$1,
	makeAutoObservable: () => makeAutoObservable,
	makeObservable: () => makeObservable,
	observable: () => observable,
	observe: () => observe,
	onBecomeObserved: () => onBecomeObserved,
	onBecomeUnobserved: () => onBecomeUnobserved,
	onReactionError: () => onReactionError,
	override: () => override,
	ownKeys: () => apiOwnKeys,
	reaction: () => reaction,
	remove: () => remove,
	runInAction: () => runInAction,
	set: () => set,
	spy: () => spy,
	toJS: () => toJS,
	trace: () => trace,
	transaction: () => transaction,
	untracked: () => untracked,
	values: () => values,
	when: () => when
});
function die(error) {
	for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) args[_key - 1] = arguments[_key];
	var e = typeof error === "string" ? error : errors[error];
	if (typeof e === "function") e = e.apply(null, args);
	throw new Error("[MobX] " + e);
}
function getGlobal() {
	if (typeof globalThis !== "undefined") return globalThis;
	if (typeof window !== "undefined") return window;
	if (typeof global !== "undefined") return global;
	if (typeof self !== "undefined") return self;
	return mockGlobal;
}
function assertProxies() {
	if (!hasProxy) die("`Proxy` objects are not available in the current environment. Please configure MobX to enable a fallback implementation.`");
}
function warnAboutProxyRequirement(msg) {
	if (globalState.verifyProxies) die("MobX is currently configured to be able to run in ES5 mode, but in ES5 MobX won't be able to " + msg);
}
function getNextId() {
	return ++globalState.mobxGuid;
}
/**
* Makes sure that the provided function is invoked at most once.
*/
function once(func) {
	var invoked = false;
	return function() {
		if (invoked) return;
		invoked = true;
		return func.apply(this, arguments);
	};
}
function isFunction(fn) {
	return typeof fn === "function";
}
function isStringish(value) {
	switch (typeof value) {
		case "string":
		case "symbol":
		case "number": return true;
	}
	return false;
}
function isObject$1(value) {
	return value !== null && typeof value === "object";
}
function isPlainObject(value) {
	if (!isObject$1(value)) return false;
	var proto = Object.getPrototypeOf(value);
	if (proto == null) return true;
	var protoConstructor = Object.hasOwnProperty.call(proto, "constructor") && proto.constructor;
	return typeof protoConstructor === "function" && protoConstructor.toString() === plainObjectString;
}
function isGenerator(obj) {
	var constructor = obj == null ? void 0 : obj.constructor;
	if (!constructor) return false;
	if ("GeneratorFunction" === constructor.name || "GeneratorFunction" === constructor.displayName) return true;
	return false;
}
function addHiddenProp(object, propName, value) {
	defineProperty(object, propName, {
		enumerable: false,
		writable: true,
		configurable: true,
		value
	});
}
function addHiddenFinalProp(object, propName, value) {
	defineProperty(object, propName, {
		enumerable: false,
		writable: false,
		configurable: true,
		value
	});
}
function createInstanceofPredicate(name, theClass) {
	var propName = "isMobX" + name;
	theClass.prototype[propName] = true;
	return function(x) {
		return isObject$1(x) && x[propName] === true;
	};
}
/**
* Yields true for both native and observable Map, even across different windows.
*/
function isES6Map(thing) {
	return thing != null && Object.prototype.toString.call(thing) === "[object Map]";
}
/**
* Makes sure a Map is an instance of non-inherited native or observable Map.
*/
function isPlainES6Map(thing) {
	return Object.getPrototypeOf(Object.getPrototypeOf(Object.getPrototypeOf(thing))) === null;
}
/**
* Yields true for both native and observable Set, even across different windows.
*/
function isES6Set(thing) {
	return thing != null && Object.prototype.toString.call(thing) === "[object Set]";
}
/**
* Returns the following: own enumerable keys and symbols.
*/
function getPlainObjectKeys(object) {
	var keys = Object.keys(object);
	if (!hasGetOwnPropertySymbols) return keys;
	var symbols = Object.getOwnPropertySymbols(object);
	if (!symbols.length) return keys;
	return [].concat(keys, symbols.filter(function(s) {
		return objectPrototype.propertyIsEnumerable.call(object, s);
	}));
}
function stringifyKey(key) {
	if (typeof key === "string") return key;
	if (typeof key === "symbol") return key.toString();
	return new String(key).toString();
}
function toPrimitive(value) {
	return value === null ? null : typeof value === "object" ? "" + value : value;
}
function hasProp(target, prop) {
	return objectPrototype.hasOwnProperty.call(target, prop);
}
function getFlag(flags, mask) {
	return !!(flags & mask);
}
function setFlag(flags, mask, newValue) {
	if (newValue) flags |= mask;
	else flags &= ~mask;
	return flags;
}
function _arrayLikeToArray(r, a) {
	(null == a || a > r.length) && (a = r.length);
	for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
	return n;
}
function _defineProperties(e, r) {
	for (var t = 0; t < r.length; t++) {
		var o = r[t];
		o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, _toPropertyKey(o.key), o);
	}
}
function _createClass(e, r, t) {
	return r && _defineProperties(e.prototype, r), t && _defineProperties(e, t), Object.defineProperty(e, "prototype", { writable: !1 }), e;
}
function _createForOfIteratorHelperLoose(r, e) {
	var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
	if (t) return (t = t.call(r)).next.bind(t);
	if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) {
		t && (r = t);
		var o = 0;
		return function() {
			return o >= r.length ? { done: !0 } : {
				done: !1,
				value: r[o++]
			};
		};
	}
	throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _extends() {
	return _extends = Object.assign ? Object.assign.bind() : function(n) {
		for (var e = 1; e < arguments.length; e++) {
			var t = arguments[e];
			for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
		}
		return n;
	}, _extends.apply(null, arguments);
}
function _inheritsLoose(t, o) {
	t.prototype = Object.create(o.prototype), t.prototype.constructor = t, _setPrototypeOf(t, o);
}
function _setPrototypeOf(t, e) {
	return _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t, e) {
		return t.__proto__ = e, t;
	}, _setPrototypeOf(t, e);
}
function _toPrimitive(t, r) {
	if ("object" != typeof t || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != typeof i) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
function _toPropertyKey(t) {
	var i = _toPrimitive(t, "string");
	return "symbol" == typeof i ? i : i + "";
}
function _unsupportedIterableToArray(r, a) {
	if (r) {
		if ("string" == typeof r) return _arrayLikeToArray(r, a);
		var t = {}.toString.call(r).slice(8, -1);
		return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
	}
}
/**
* Creates a function that acts as
* - decorator
* - annotation object
*/
function createDecoratorAnnotation(annotation) {
	function decorator(target, property) {
		if (is20223Decorator(property)) return annotation.decorate_20223_(target, property);
		else storeAnnotation(target, property, annotation);
	}
	return Object.assign(decorator, annotation);
}
/**
* Stores annotation to prototype,
* so it can be inspected later by `makeObservable` called from constructor
*/
function storeAnnotation(prototype, key, annotation) {
	if (!hasProp(prototype, storedAnnotationsSymbol)) addHiddenProp(prototype, storedAnnotationsSymbol, _extends({}, prototype[storedAnnotationsSymbol]));
	if (isOverride(annotation) && !hasProp(prototype[storedAnnotationsSymbol], key)) die("'" + (prototype.constructor.name + ".prototype." + key.toString()) + "' is decorated with 'override', but no such decorated member was found on prototype.");
	assertNotDecorated(prototype, annotation, key);
	if (!isOverride(annotation)) prototype[storedAnnotationsSymbol][key] = annotation;
}
function assertNotDecorated(prototype, annotation, key) {
	if (!isOverride(annotation) && hasProp(prototype[storedAnnotationsSymbol], key)) {
		var fieldName = prototype.constructor.name + ".prototype." + key.toString();
		var currentAnnotationType = prototype[storedAnnotationsSymbol][key].annotationType_;
		var requestedAnnotationType = annotation.annotationType_;
		die("Cannot apply '@" + requestedAnnotationType + "' to '" + fieldName + "':" + ("\nThe field is already decorated with '@" + currentAnnotationType + "'.") + "\nRe-decorating fields is not allowed.\nUse '@override' decorator for methods overridden by subclass.");
	}
}
/**
* Collects annotations from prototypes and stores them on target (instance)
*/
function collectStoredAnnotations(target) {
	if (!hasProp(target, storedAnnotationsSymbol)) addHiddenProp(target, storedAnnotationsSymbol, _extends({}, target[storedAnnotationsSymbol]));
	return target[storedAnnotationsSymbol];
}
function is20223Decorator(context) {
	return typeof context == "object" && typeof context["kind"] == "string";
}
function assert20223DecoratorType(context, types) {
	if (!types.includes(context.kind)) die("The decorator applied to '" + String(context.name) + "' cannot be used on a " + context.kind + " element");
}
function createAtom(name, onBecomeObservedHandler, onBecomeUnobservedHandler) {
	if (onBecomeObservedHandler === void 0) onBecomeObservedHandler = noop;
	if (onBecomeUnobservedHandler === void 0) onBecomeUnobservedHandler = noop;
	var atom = new Atom(name);
	if (onBecomeObservedHandler !== noop) onBecomeObserved(atom, onBecomeObservedHandler);
	if (onBecomeUnobservedHandler !== noop) onBecomeUnobserved(atom, onBecomeUnobservedHandler);
	return atom;
}
function identityComparer(a, b) {
	return a === b;
}
function structuralComparer(a, b) {
	return deepEqual(a, b);
}
function shallowComparer(a, b) {
	return deepEqual(a, b, 1);
}
function defaultComparer(a, b) {
	if (Object.is) return Object.is(a, b);
	return a === b ? a !== 0 || 1 / a === 1 / b : a !== a && b !== b;
}
function deepEnhancer(v, _, name) {
	if (isObservable(v)) return v;
	if (Array.isArray(v)) return observable.array(v, { name });
	if (isPlainObject(v)) return observable.object(v, void 0, { name });
	if (isES6Map(v)) return observable.map(v, { name });
	if (isES6Set(v)) return observable.set(v, { name });
	if (typeof v === "function" && !isAction(v) && !isFlow(v)) if (isGenerator(v)) return flow(v);
	else return autoAction(name, v);
	return v;
}
function shallowEnhancer(v, _, name) {
	if (v === void 0 || v === null) return v;
	if (isObservableObject(v) || isObservableArray(v) || isObservableMap(v) || isObservableSet(v)) return v;
	if (Array.isArray(v)) return observable.array(v, {
		name,
		deep: false
	});
	if (isPlainObject(v)) return observable.object(v, void 0, {
		name,
		deep: false
	});
	if (isES6Map(v)) return observable.map(v, {
		name,
		deep: false
	});
	if (isES6Set(v)) return observable.set(v, {
		name,
		deep: false
	});
	die("The shallow modifier / decorator can only used in combination with arrays, objects, maps and sets");
}
function referenceEnhancer(newValue) {
	return newValue;
}
function refStructEnhancer(v, oldValue) {
	if (isObservable(v)) die("observable.struct should not be used with observable values");
	if (deepEqual(v, oldValue)) return oldValue;
	return v;
}
function isOverride(annotation) {
	return annotation.annotationType_ === OVERRIDE;
}
function make_(adm, key) {
	if (adm.isPlainObject_) die("Cannot apply '" + this.annotationType_ + "' to '" + adm.name_ + "." + key.toString() + "':" + ("\n'" + this.annotationType_ + "' cannot be used on plain objects."));
	if (!hasProp(adm.appliedAnnotations_, key)) die("'" + adm.name_ + "." + key.toString() + "' is annotated with '" + this.annotationType_ + "', but no such annotated member was found on prototype.");
	return 0;
}
function extend_(adm, key, descriptor, proxyTrap) {
	die("'" + this.annotationType_ + "' can only be used with 'makeObservable'");
}
function decorate_20223_(desc, context) {
	console.warn("'" + this.annotationType_ + "' cannot be used with decorators - this is a no-op");
}
function createActionAnnotation(name, options) {
	return {
		annotationType_: name,
		options_: options,
		make_: make_$1,
		extend_: extend_$1,
		decorate_20223_: decorate_20223_$1
	};
}
function make_$1(adm, key, descriptor, source) {
	var _this$options_;
	if ((_this$options_ = this.options_) != null && _this$options_.bound) return this.extend_(adm, key, descriptor, false) === null ? 0 : 1;
	if (source === adm.target_) return this.extend_(adm, key, descriptor, false) === null ? 0 : 2;
	if (isAction(descriptor.value)) return 1;
	defineProperty(source, key, createActionDescriptor(adm, this, key, descriptor, false));
	return 2;
}
function extend_$1(adm, key, descriptor, proxyTrap) {
	var actionDescriptor = createActionDescriptor(adm, this, key, descriptor);
	return adm.defineProperty_(key, actionDescriptor, proxyTrap);
}
function decorate_20223_$1(mthd, context) {
	assert20223DecoratorType(context, ["method", "field"]);
	var kind = context.kind;
	var name = context.name;
	var addInitializer = context.addInitializer;
	var ann = this;
	var _createAction = function _createAction(m) {
		var _ann$options_$name;
		var _ann$options_;
		var _ann$options_$autoAct;
		var _ann$options_2;
		return createAction((_ann$options_$name = (_ann$options_ = ann.options_) == null ? void 0 : _ann$options_.name) != null ? _ann$options_$name : name.toString(), m, (_ann$options_$autoAct = (_ann$options_2 = ann.options_) == null ? void 0 : _ann$options_2.autoAction) != null ? _ann$options_$autoAct : false);
	};
	if (kind == "field") return function(initMthd) {
		var _ann$options_3;
		var mthd = initMthd;
		if (!isAction(mthd)) mthd = _createAction(mthd);
		if ((_ann$options_3 = ann.options_) != null && _ann$options_3.bound) {
			mthd = mthd.bind(this);
			mthd.isMobxAction = true;
		}
		return mthd;
	};
	if (kind == "method") {
		var _this$options_2;
		if (!isAction(mthd)) mthd = _createAction(mthd);
		if ((_this$options_2 = this.options_) != null && _this$options_2.bound) addInitializer(function() {
			var self = this;
			var bound = self[name].bind(self);
			bound.isMobxAction = true;
			self[name] = bound;
		});
		return mthd;
	}
	die("Cannot apply '" + ann.annotationType_ + "' to '" + String(name) + "' (kind: " + kind + "):" + ("\n'" + ann.annotationType_ + "' can only be used on properties with a function value."));
}
function assertActionDescriptor(adm, _ref, key, _ref2) {
	var annotationType_ = _ref.annotationType_;
	var value = _ref2.value;
	if (!isFunction(value)) die("Cannot apply '" + annotationType_ + "' to '" + adm.name_ + "." + key.toString() + "':" + ("\n'" + annotationType_ + "' can only be used on properties with a function value."));
}
function createActionDescriptor(adm, annotation, key, descriptor, safeDescriptors) {
	var _annotation$options_;
	var _annotation$options_$;
	var _annotation$options_2;
	var _annotation$options_$2;
	var _annotation$options_3;
	var _annotation$options_4;
	var _adm$proxy_2;
	if (safeDescriptors === void 0) safeDescriptors = globalState.safeDescriptors;
	assertActionDescriptor(adm, annotation, key, descriptor);
	var value = descriptor.value;
	if ((_annotation$options_ = annotation.options_) != null && _annotation$options_.bound) {
		var _adm$proxy_;
		value = value.bind((_adm$proxy_ = adm.proxy_) != null ? _adm$proxy_ : adm.target_);
	}
	return {
		value: createAction((_annotation$options_$ = (_annotation$options_2 = annotation.options_) == null ? void 0 : _annotation$options_2.name) != null ? _annotation$options_$ : key.toString(), value, (_annotation$options_$2 = (_annotation$options_3 = annotation.options_) == null ? void 0 : _annotation$options_3.autoAction) != null ? _annotation$options_$2 : false, (_annotation$options_4 = annotation.options_) != null && _annotation$options_4.bound ? (_adm$proxy_2 = adm.proxy_) != null ? _adm$proxy_2 : adm.target_ : void 0),
		configurable: safeDescriptors ? adm.isPlainObject_ : true,
		enumerable: false,
		writable: safeDescriptors ? false : true
	};
}
function createFlowAnnotation(name, options) {
	return {
		annotationType_: name,
		options_: options,
		make_: make_$2,
		extend_: extend_$2,
		decorate_20223_: decorate_20223_$2
	};
}
function make_$2(adm, key, descriptor, source) {
	var _this$options_;
	if (source === adm.target_) return this.extend_(adm, key, descriptor, false) === null ? 0 : 2;
	if ((_this$options_ = this.options_) != null && _this$options_.bound && (!hasProp(adm.target_, key) || !isFlow(adm.target_[key]))) {
		if (this.extend_(adm, key, descriptor, false) === null) return 0;
	}
	if (isFlow(descriptor.value)) return 1;
	defineProperty(source, key, createFlowDescriptor(adm, this, key, descriptor, false, false));
	return 2;
}
function extend_$2(adm, key, descriptor, proxyTrap) {
	var _this$options_2;
	var flowDescriptor = createFlowDescriptor(adm, this, key, descriptor, (_this$options_2 = this.options_) == null ? void 0 : _this$options_2.bound);
	return adm.defineProperty_(key, flowDescriptor, proxyTrap);
}
function decorate_20223_$2(mthd, context) {
	var _this$options_3;
	assert20223DecoratorType(context, ["method"]);
	var name = context.name;
	var addInitializer = context.addInitializer;
	if (!isFlow(mthd)) mthd = flow(mthd);
	if ((_this$options_3 = this.options_) != null && _this$options_3.bound) addInitializer(function() {
		var self = this;
		var bound = self[name].bind(self);
		bound.isMobXFlow = true;
		self[name] = bound;
	});
	return mthd;
}
function assertFlowDescriptor(adm, _ref, key, _ref2) {
	var annotationType_ = _ref.annotationType_;
	var value = _ref2.value;
	if (!isFunction(value)) die("Cannot apply '" + annotationType_ + "' to '" + adm.name_ + "." + key.toString() + "':" + ("\n'" + annotationType_ + "' can only be used on properties with a generator function value."));
}
function createFlowDescriptor(adm, annotation, key, descriptor, bound, safeDescriptors) {
	if (safeDescriptors === void 0) safeDescriptors = globalState.safeDescriptors;
	assertFlowDescriptor(adm, annotation, key, descriptor);
	var value = descriptor.value;
	if (!isFlow(value)) value = flow(value);
	if (bound) {
		var _adm$proxy_;
		value = value.bind((_adm$proxy_ = adm.proxy_) != null ? _adm$proxy_ : adm.target_);
		value.isMobXFlow = true;
	}
	return {
		value,
		configurable: safeDescriptors ? adm.isPlainObject_ : true,
		enumerable: false,
		writable: safeDescriptors ? false : true
	};
}
function createComputedAnnotation(name, options) {
	return {
		annotationType_: name,
		options_: options,
		make_: make_$3,
		extend_: extend_$3,
		decorate_20223_: decorate_20223_$3
	};
}
function make_$3(adm, key, descriptor) {
	return this.extend_(adm, key, descriptor, false) === null ? 0 : 1;
}
function extend_$3(adm, key, descriptor, proxyTrap) {
	assertComputedDescriptor(adm, this, key, descriptor);
	return adm.defineComputedProperty_(key, _extends({}, this.options_, {
		get: descriptor.get,
		set: descriptor.set
	}), proxyTrap);
}
function decorate_20223_$3(get, context) {
	assert20223DecoratorType(context, ["getter"]);
	var ann = this;
	var key = context.name;
	var addInitializer = context.addInitializer;
	addInitializer(function() {
		var adm = asObservableObject(this)[$mobx];
		var options = _extends({}, ann.options_, {
			get,
			context: this
		});
		options.name || (options.name = adm.name_ + "." + key.toString());
		adm.values_.set(key, new ComputedValue(options));
	});
	return function() {
		return this[$mobx].getObservablePropValue_(key);
	};
}
function assertComputedDescriptor(adm, _ref, key, _ref2) {
	var annotationType_ = _ref.annotationType_;
	if (!_ref2.get) die("Cannot apply '" + annotationType_ + "' to '" + adm.name_ + "." + key.toString() + "':" + ("\n'" + annotationType_ + "' can only be used on getter(+setter) properties."));
}
function createObservableAnnotation(name, options) {
	return {
		annotationType_: name,
		options_: options,
		make_: make_$4,
		extend_: extend_$4,
		decorate_20223_: decorate_20223_$4
	};
}
function make_$4(adm, key, descriptor) {
	return this.extend_(adm, key, descriptor, false) === null ? 0 : 1;
}
function extend_$4(adm, key, descriptor, proxyTrap) {
	var _this$options_$enhanc;
	var _this$options_;
	assertObservableDescriptor(adm, this, key, descriptor);
	return adm.defineObservableProperty_(key, descriptor.value, (_this$options_$enhanc = (_this$options_ = this.options_) == null ? void 0 : _this$options_.enhancer) != null ? _this$options_$enhanc : deepEnhancer, proxyTrap);
}
function decorate_20223_$4(desc, context) {
	if (context.kind === "field") throw die("Please use `@observable accessor " + String(context.name) + "` instead of `@observable " + String(context.name) + "`");
	assert20223DecoratorType(context, ["accessor"]);
	var ann = this;
	var kind = context.kind;
	var name = context.name;
	var initializedObjects = /* @__PURE__ */ new WeakSet();
	function initializeObservable(target, value) {
		var _ann$options_$enhance;
		var _ann$options_;
		var adm = asObservableObject(target)[$mobx];
		var observable = new ObservableValue(value, (_ann$options_$enhance = (_ann$options_ = ann.options_) == null ? void 0 : _ann$options_.enhancer) != null ? _ann$options_$enhance : deepEnhancer, adm.name_ + "." + name.toString(), false);
		adm.values_.set(name, observable);
		initializedObjects.add(target);
	}
	if (kind == "accessor") return {
		get: function get() {
			if (!initializedObjects.has(this)) initializeObservable(this, desc.get.call(this));
			return this[$mobx].getObservablePropValue_(name);
		},
		set: function set(value) {
			if (!initializedObjects.has(this)) initializeObservable(this, value);
			return this[$mobx].setObservablePropValue_(name, value);
		},
		init: function init(value) {
			if (!initializedObjects.has(this)) initializeObservable(this, value);
			return value;
		}
	};
}
function assertObservableDescriptor(adm, _ref, key, descriptor) {
	var annotationType_ = _ref.annotationType_;
	if (!("value" in descriptor)) die("Cannot apply '" + annotationType_ + "' to '" + adm.name_ + "." + key.toString() + "':" + ("\n'" + annotationType_ + "' cannot be used on getter/setter properties"));
}
function createAutoAnnotation(options) {
	return {
		annotationType_: AUTO,
		options_: options,
		make_: make_$5,
		extend_: extend_$5,
		decorate_20223_: decorate_20223_$5
	};
}
function make_$5(adm, key, descriptor, source) {
	var _this$options_3;
	var _this$options_4;
	if (descriptor.get) return computed.make_(adm, key, descriptor, source);
	if (descriptor.set) {
		var set = isAction(descriptor.set) ? descriptor.set : createAction(key.toString(), descriptor.set);
		if (source === adm.target_) return adm.defineProperty_(key, {
			configurable: globalState.safeDescriptors ? adm.isPlainObject_ : true,
			set
		}) === null ? 0 : 2;
		defineProperty(source, key, {
			configurable: true,
			set
		});
		return 2;
	}
	if (source !== adm.target_ && typeof descriptor.value === "function") {
		var _this$options_2;
		if (isGenerator(descriptor.value)) {
			var _this$options_;
			return ((_this$options_ = this.options_) != null && _this$options_.autoBind ? flow.bound : flow).make_(adm, key, descriptor, source);
		}
		return ((_this$options_2 = this.options_) != null && _this$options_2.autoBind ? autoAction.bound : autoAction).make_(adm, key, descriptor, source);
	}
	var observableAnnotation = ((_this$options_3 = this.options_) == null ? void 0 : _this$options_3.deep) === false ? observable.ref : observable;
	if (typeof descriptor.value === "function" && (_this$options_4 = this.options_) != null && _this$options_4.autoBind) {
		var _adm$proxy_;
		descriptor.value = descriptor.value.bind((_adm$proxy_ = adm.proxy_) != null ? _adm$proxy_ : adm.target_);
	}
	return observableAnnotation.make_(adm, key, descriptor, source);
}
function extend_$5(adm, key, descriptor, proxyTrap) {
	var _this$options_5;
	var _this$options_6;
	if (descriptor.get) return computed.extend_(adm, key, descriptor, proxyTrap);
	if (descriptor.set) return adm.defineProperty_(key, {
		configurable: globalState.safeDescriptors ? adm.isPlainObject_ : true,
		set: createAction(key.toString(), descriptor.set)
	}, proxyTrap);
	if (typeof descriptor.value === "function" && (_this$options_5 = this.options_) != null && _this$options_5.autoBind) {
		var _adm$proxy_2;
		descriptor.value = descriptor.value.bind((_adm$proxy_2 = adm.proxy_) != null ? _adm$proxy_2 : adm.target_);
	}
	return (((_this$options_6 = this.options_) == null ? void 0 : _this$options_6.deep) === false ? observable.ref : observable).extend_(adm, key, descriptor, proxyTrap);
}
function decorate_20223_$5(desc, context) {
	die("'" + this.annotationType_ + "' cannot be used as a decorator");
}
function asCreateObservableOptions(thing) {
	return thing || defaultCreateObservableOptions;
}
function getEnhancerFromOptions(options) {
	return options.deep === true ? deepEnhancer : options.deep === false ? referenceEnhancer : getEnhancerFromAnnotation(options.defaultDecorator);
}
function getAnnotationFromOptions(options) {
	var _options$defaultDecor;
	return options ? (_options$defaultDecor = options.defaultDecorator) != null ? _options$defaultDecor : createAutoAnnotation(options) : void 0;
}
function getEnhancerFromAnnotation(annotation) {
	var _annotation$options_$;
	var _annotation$options_;
	return !annotation ? deepEnhancer : (_annotation$options_$ = (_annotation$options_ = annotation.options_) == null ? void 0 : _annotation$options_.enhancer) != null ? _annotation$options_$ : deepEnhancer;
}
/**
* Turns an object, array or function into a reactive structure.
* @param v the value which should become observable.
*/
function createObservable(v, arg2, arg3) {
	if (is20223Decorator(arg2)) return observableAnnotation.decorate_20223_(v, arg2);
	if (isStringish(arg2)) {
		storeAnnotation(v, arg2, observableAnnotation);
		return;
	}
	if (isObservable(v)) return v;
	if (isPlainObject(v)) return observable.object(v, arg2, arg3);
	if (Array.isArray(v)) return observable.array(v, arg2);
	if (isES6Map(v)) return observable.map(v, arg2);
	if (isES6Set(v)) return observable.set(v, arg2);
	if (typeof v === "object" && v !== null) return v;
	return observable.box(v, arg2);
}
function createAction(actionName, fn, autoAction, ref) {
	if (autoAction === void 0) autoAction = false;
	if (!isFunction(fn)) die("`action` can only be invoked on functions");
	if (typeof actionName !== "string" || !actionName) die("actions should have valid names, got: '" + actionName + "'");
	function res() {
		return executeAction(actionName, autoAction, fn, ref || this, arguments);
	}
	res.isMobxAction = true;
	res.toString = function() {
		return fn.toString();
	};
	if (isFunctionNameConfigurable) {
		tmpNameDescriptor.value = actionName;
		defineProperty(res, "name", tmpNameDescriptor);
	}
	return res;
}
function executeAction(actionName, canRunAsDerivation, fn, scope, args) {
	var runInfo = _startAction(actionName, canRunAsDerivation, scope, args);
	try {
		return fn.apply(scope, args);
	} catch (err) {
		runInfo.error_ = err;
		throw err;
	} finally {
		_endAction(runInfo);
	}
}
function _startAction(actionName, canRunAsDerivation, scope, args) {
	var notifySpy_ = isSpyEnabled() && !!actionName;
	var startTime_ = 0;
	if (notifySpy_) {
		startTime_ = Date.now();
		spyReportStart({
			type: ACTION,
			name: actionName,
			object: scope,
			arguments: args ? Array.from(args) : EMPTY_ARRAY
		});
	}
	var prevDerivation_ = globalState.trackingDerivation;
	var runAsAction = !canRunAsDerivation || !prevDerivation_;
	startBatch();
	var prevAllowStateChanges_ = globalState.allowStateChanges;
	if (runAsAction) {
		untrackedStart();
		prevAllowStateChanges_ = allowStateChangesStart(true);
	}
	var prevAllowStateReads_ = allowStateReadsStart(true);
	var runInfo = {
		runAsAction_: runAsAction,
		prevDerivation_,
		prevAllowStateChanges_,
		prevAllowStateReads_,
		notifySpy_,
		startTime_,
		actionId_: nextActionId++,
		parentActionId_: currentActionId
	};
	currentActionId = runInfo.actionId_;
	return runInfo;
}
function _endAction(runInfo) {
	if (currentActionId !== runInfo.actionId_) die(30);
	currentActionId = runInfo.parentActionId_;
	if (runInfo.error_ !== void 0) globalState.suppressReactionErrors = true;
	allowStateChangesEnd(runInfo.prevAllowStateChanges_);
	allowStateReadsEnd(runInfo.prevAllowStateReads_);
	endBatch();
	if (runInfo.runAsAction_) untrackedEnd(runInfo.prevDerivation_);
	if (runInfo.notifySpy_) spyReportEnd({ time: Date.now() - runInfo.startTime_ });
	globalState.suppressReactionErrors = false;
}
function allowStateChanges(allowStateChanges, func) {
	var prev = allowStateChangesStart(allowStateChanges);
	try {
		return func();
	} finally {
		allowStateChangesEnd(prev);
	}
}
function allowStateChangesStart(allowStateChanges) {
	var prev = globalState.allowStateChanges;
	globalState.allowStateChanges = allowStateChanges;
	return prev;
}
function allowStateChangesEnd(prev) {
	globalState.allowStateChanges = prev;
}
function isCaughtException(e) {
	return e instanceof CaughtException;
}
/**
* Finds out whether any dependency of the derivation has actually changed.
* If dependenciesState is 1 then it will recalculate dependencies,
* if any dependency changed it will propagate it by changing dependenciesState to 2.
*
* By iterating over the dependencies in the same order that they were reported and
* stopping on the first change, all the recalculations are only called for ComputedValues
* that will be tracked by derivation. That is because we assume that if the first x
* dependencies of the derivation doesn't change then the derivation should run the same way
* up until accessing x-th dependency.
*/
function shouldCompute(derivation) {
	switch (derivation.dependenciesState_) {
		case IDerivationState_.UP_TO_DATE_: return false;
		case IDerivationState_.NOT_TRACKING_:
		case IDerivationState_.STALE_: return true;
		case IDerivationState_.POSSIBLY_STALE_:
			var prevAllowStateReads = allowStateReadsStart(true);
			var prevUntracked = untrackedStart();
			var obs = derivation.observing_;
			var l = obs.length;
			for (var i = 0; i < l; i++) {
				var obj = obs[i];
				if (isComputedValue(obj)) {
					if (globalState.disableErrorBoundaries) obj.get();
					else try {
						obj.get();
					} catch (e) {
						untrackedEnd(prevUntracked);
						allowStateReadsEnd(prevAllowStateReads);
						return true;
					}
					if (derivation.dependenciesState_ === IDerivationState_.STALE_) {
						untrackedEnd(prevUntracked);
						allowStateReadsEnd(prevAllowStateReads);
						return true;
					}
				}
			}
			changeDependenciesStateTo0(derivation);
			untrackedEnd(prevUntracked);
			allowStateReadsEnd(prevAllowStateReads);
			return false;
	}
}
function isComputingDerivation() {
	return globalState.trackingDerivation !== null;
}
function checkIfStateModificationsAreAllowed(atom) {
	var hasObservers = atom.observers_.size > 0;
	if (!globalState.allowStateChanges && (hasObservers || globalState.enforceActions === "always")) console.warn("[MobX] " + (globalState.enforceActions ? "Since strict-mode is enabled, changing (observed) observable values without using an action is not allowed. Tried to modify: " : "Side effects like changing state are not allowed at this point. Are you trying to modify state from, for example, a computed value or the render function of a React component? You can wrap side effects in 'runInAction' (or decorate functions with 'action') if needed. Tried to modify: ") + atom.name_);
}
function checkIfStateReadsAreAllowed(observable) {
	if (!globalState.allowStateReads && globalState.observableRequiresReaction) console.warn("[mobx] Observable '" + observable.name_ + "' being read outside a reactive context.");
}
/**
* Executes the provided function `f` and tracks which observables are being accessed.
* The tracking information is stored on the `derivation` object and the derivation is registered
* as observer of any of the accessed observables.
*/
function trackDerivedFunction(derivation, f, context) {
	var prevAllowStateReads = allowStateReadsStart(true);
	changeDependenciesStateTo0(derivation);
	derivation.newObserving_ = new Array(derivation.runId_ === 0 ? 100 : derivation.observing_.length);
	derivation.unboundDepsCount_ = 0;
	derivation.runId_ = ++globalState.runId;
	var prevTracking = globalState.trackingDerivation;
	globalState.trackingDerivation = derivation;
	globalState.inBatch++;
	var result;
	if (globalState.disableErrorBoundaries === true) result = f.call(context);
	else try {
		result = f.call(context);
	} catch (e) {
		result = new CaughtException(e);
	}
	globalState.inBatch--;
	globalState.trackingDerivation = prevTracking;
	bindDependencies(derivation);
	warnAboutDerivationWithoutDependencies(derivation);
	allowStateReadsEnd(prevAllowStateReads);
	return result;
}
function warnAboutDerivationWithoutDependencies(derivation) {
	if (derivation.observing_.length !== 0) return;
	if (typeof derivation.requiresObservable_ === "boolean" ? derivation.requiresObservable_ : globalState.reactionRequiresObservable) console.warn("[mobx] Derivation '" + derivation.name_ + "' is created/updated without reading any observable value.");
}
/**
* diffs newObserving with observing.
* update observing to be newObserving with unique observables
* notify observers that become observed/unobserved
*/
function bindDependencies(derivation) {
	var prevObserving = derivation.observing_;
	var observing = derivation.observing_ = derivation.newObserving_;
	var lowestNewObservingDerivationState = IDerivationState_.UP_TO_DATE_;
	var i0 = 0;
	var l = derivation.unboundDepsCount_;
	for (var i = 0; i < l; i++) {
		var dep = observing[i];
		if (dep.diffValue === 0) {
			dep.diffValue = 1;
			if (i0 !== i) observing[i0] = dep;
			i0++;
		}
		if (dep.dependenciesState_ > lowestNewObservingDerivationState) lowestNewObservingDerivationState = dep.dependenciesState_;
	}
	observing.length = i0;
	derivation.newObserving_ = null;
	l = prevObserving.length;
	while (l--) {
		var _dep = prevObserving[l];
		if (_dep.diffValue === 0) removeObserver(_dep, derivation);
		_dep.diffValue = 0;
	}
	while (i0--) {
		var _dep2 = observing[i0];
		if (_dep2.diffValue === 1) {
			_dep2.diffValue = 0;
			addObserver(_dep2, derivation);
		}
	}
	if (lowestNewObservingDerivationState !== IDerivationState_.UP_TO_DATE_) {
		derivation.dependenciesState_ = lowestNewObservingDerivationState;
		derivation.onBecomeStale_();
	}
}
function clearObserving(derivation) {
	var obs = derivation.observing_;
	derivation.observing_ = [];
	var i = obs.length;
	while (i--) removeObserver(obs[i], derivation);
	derivation.dependenciesState_ = IDerivationState_.NOT_TRACKING_;
}
function untracked(action) {
	var prev = untrackedStart();
	try {
		return action();
	} finally {
		untrackedEnd(prev);
	}
}
function untrackedStart() {
	var prev = globalState.trackingDerivation;
	globalState.trackingDerivation = null;
	return prev;
}
function untrackedEnd(prev) {
	globalState.trackingDerivation = prev;
}
function allowStateReadsStart(allowStateReads) {
	var prev = globalState.allowStateReads;
	globalState.allowStateReads = allowStateReads;
	return prev;
}
function allowStateReadsEnd(prev) {
	globalState.allowStateReads = prev;
}
/**
* needed to keep `lowestObserverState` correct. when changing from (2 or 1) to 0
*
*/
function changeDependenciesStateTo0(derivation) {
	if (derivation.dependenciesState_ === IDerivationState_.UP_TO_DATE_) return;
	derivation.dependenciesState_ = IDerivationState_.UP_TO_DATE_;
	var obs = derivation.observing_;
	var i = obs.length;
	while (i--) obs[i].lowestObserverState_ = IDerivationState_.UP_TO_DATE_;
}
function isolateGlobalState() {
	if (globalState.pendingReactions.length || globalState.inBatch || globalState.isRunningReactions) die(36);
	isolateCalled = true;
	if (canMergeGlobalState) {
		var global = getGlobal();
		if (--global.__mobxInstanceCount === 0) global.__mobxGlobals = void 0;
		globalState = new MobXGlobals();
	}
}
function getGlobalState() {
	return globalState;
}
/**
* For testing purposes only; this will break the internal state of existing observables,
* but can be used to get back at a stable state after throwing errors
*/
function resetGlobalState() {
	var defaultGlobals = new MobXGlobals();
	for (var key in defaultGlobals) if (persistentKeys.indexOf(key) === -1) globalState[key] = defaultGlobals[key];
	globalState.allowStateChanges = !globalState.enforceActions;
}
function hasObservers(observable) {
	return observable.observers_ && observable.observers_.size > 0;
}
function getObservers(observable) {
	return observable.observers_;
}
function addObserver(observable, node) {
	observable.observers_.add(node);
	if (observable.lowestObserverState_ > node.dependenciesState_) observable.lowestObserverState_ = node.dependenciesState_;
}
function removeObserver(observable, node) {
	observable.observers_["delete"](node);
	if (observable.observers_.size === 0) queueForUnobservation(observable);
}
function queueForUnobservation(observable) {
	if (observable.isPendingUnobservation === false) {
		observable.isPendingUnobservation = true;
		globalState.pendingUnobservations.push(observable);
	}
}
/**
* Batch starts a transaction, at least for purposes of memoizing ComputedValues when nothing else does.
* During a batch `onBecomeUnobserved` will be called at most once per observable.
* Avoids unnecessary recalculations.
*/
function startBatch() {
	globalState.inBatch++;
}
function endBatch() {
	if (--globalState.inBatch === 0) {
		runReactions();
		var list = globalState.pendingUnobservations;
		for (var i = 0; i < list.length; i++) {
			var observable = list[i];
			observable.isPendingUnobservation = false;
			if (observable.observers_.size === 0) {
				if (observable.isBeingObserved) {
					observable.isBeingObserved = false;
					observable.onBUO();
				}
				if (observable instanceof ComputedValue) observable.suspend_();
			}
		}
		globalState.pendingUnobservations = [];
	}
}
function reportObserved(observable) {
	checkIfStateReadsAreAllowed(observable);
	var derivation = globalState.trackingDerivation;
	if (derivation !== null) {
		/**
		* Simple optimization, give each derivation run an unique id (runId)
		* Check if last time this observable was accessed the same runId is used
		* if this is the case, the relation is already known
		*/
		if (derivation.runId_ !== observable.lastAccessedBy_) {
			observable.lastAccessedBy_ = derivation.runId_;
			derivation.newObserving_[derivation.unboundDepsCount_++] = observable;
			if (!observable.isBeingObserved && globalState.trackingContext) {
				observable.isBeingObserved = true;
				observable.onBO();
			}
		}
		return observable.isBeingObserved;
	} else if (observable.observers_.size === 0 && globalState.inBatch > 0) queueForUnobservation(observable);
	return false;
}
/**
* NOTE: current propagation mechanism will in case of self reruning autoruns behave unexpectedly
* It will propagate changes to observers from previous run
* It's hard or maybe impossible (with reasonable perf) to get it right with current approach
* Hopefully self reruning autoruns aren't a feature people should depend on
* Also most basic use cases should be ok
*/
function propagateChanged(observable) {
	if (observable.lowestObserverState_ === IDerivationState_.STALE_) return;
	observable.lowestObserverState_ = IDerivationState_.STALE_;
	observable.observers_.forEach(function(d) {
		if (d.dependenciesState_ === IDerivationState_.UP_TO_DATE_) {
			if (d.isTracing_ !== TraceMode.NONE) logTraceInfo(d, observable);
			d.onBecomeStale_();
		}
		d.dependenciesState_ = IDerivationState_.STALE_;
	});
}
function propagateChangeConfirmed(observable) {
	if (observable.lowestObserverState_ === IDerivationState_.STALE_) return;
	observable.lowestObserverState_ = IDerivationState_.STALE_;
	observable.observers_.forEach(function(d) {
		if (d.dependenciesState_ === IDerivationState_.POSSIBLY_STALE_) {
			d.dependenciesState_ = IDerivationState_.STALE_;
			if (d.isTracing_ !== TraceMode.NONE) logTraceInfo(d, observable);
		} else if (d.dependenciesState_ === IDerivationState_.UP_TO_DATE_) observable.lowestObserverState_ = IDerivationState_.UP_TO_DATE_;
	});
}
function propagateMaybeChanged(observable) {
	if (observable.lowestObserverState_ !== IDerivationState_.UP_TO_DATE_) return;
	observable.lowestObserverState_ = IDerivationState_.POSSIBLY_STALE_;
	observable.observers_.forEach(function(d) {
		if (d.dependenciesState_ === IDerivationState_.UP_TO_DATE_) {
			d.dependenciesState_ = IDerivationState_.POSSIBLY_STALE_;
			d.onBecomeStale_();
		}
	});
}
function logTraceInfo(derivation, observable) {
	console.log("[mobx.trace] '" + derivation.name_ + "' is invalidated due to a change in: '" + observable.name_ + "'");
	if (derivation.isTracing_ === TraceMode.BREAK) {
		var lines = [];
		printDepTree(getDependencyTree(derivation), lines, 1);
		new Function("debugger;\n/*\nTracing '" + derivation.name_ + "'\n\nYou are entering this break point because derivation '" + derivation.name_ + "' is being traced and '" + observable.name_ + "' is now forcing it to update.\nJust follow the stacktrace you should now see in the devtools to see precisely what piece of your code is causing this update\nThe stackframe you are looking for is at least ~6-8 stack-frames up.\n\n" + (derivation instanceof ComputedValue ? derivation.derivation.toString().replace(/[*]\//g, "/") : "") + "\n\nThe dependencies for this derivation are:\n\n" + lines.join("\n") + "\n*/\n    ")();
	}
}
function printDepTree(tree, lines, depth) {
	if (lines.length >= 1e3) {
		lines.push("(and many more)");
		return;
	}
	lines.push("" + "	".repeat(depth - 1) + tree.name);
	if (tree.dependencies) tree.dependencies.forEach(function(child) {
		return printDepTree(child, lines, depth + 1);
	});
}
function onReactionError(handler) {
	globalState.globalReactionErrorHandlers.push(handler);
	return function() {
		var idx = globalState.globalReactionErrorHandlers.indexOf(handler);
		if (idx >= 0) globalState.globalReactionErrorHandlers.splice(idx, 1);
	};
}
function runReactions() {
	if (globalState.inBatch > 0 || globalState.isRunningReactions) return;
	reactionScheduler(runReactionsHelper);
}
function runReactionsHelper() {
	globalState.isRunningReactions = true;
	var allReactions = globalState.pendingReactions;
	var iterations = 0;
	while (allReactions.length > 0) {
		if (++iterations === MAX_REACTION_ITERATIONS) {
			console.error("Reaction doesn't converge to a stable state after " + MAX_REACTION_ITERATIONS + " iterations." + (" Probably there is a cycle in the reactive function: " + allReactions[0]));
			allReactions.splice(0);
		}
		var remainingReactions = allReactions.splice(0);
		for (var i = 0, l = remainingReactions.length; i < l; i++) remainingReactions[i].runReaction_();
	}
	globalState.isRunningReactions = false;
}
function setReactionScheduler(fn) {
	var baseScheduler = reactionScheduler;
	reactionScheduler = function reactionScheduler(f) {
		return fn(function() {
			return baseScheduler(f);
		});
	};
}
function isSpyEnabled() {
	return !!globalState.spyListeners.length;
}
function spyReport(event) {
	if (!globalState.spyListeners.length) return;
	var listeners = globalState.spyListeners;
	for (var i = 0, l = listeners.length; i < l; i++) listeners[i](event);
}
function spyReportStart(event) {
	spyReport(_extends({}, event, { spyReportStart: true }));
}
function spyReportEnd(change) {
	if (change) spyReport(_extends({}, change, {
		type: "report-end",
		spyReportEnd: true
	}));
	else spyReport(END_EVENT);
}
function spy(listener) {
	globalState.spyListeners.push(listener);
	return once(function() {
		globalState.spyListeners = globalState.spyListeners.filter(function(l) {
			return l !== listener;
		});
	});
}
function createActionFactory(autoAction) {
	return function action(arg1, arg2) {
		if (isFunction(arg1)) return createAction(arg1.name || DEFAULT_ACTION_NAME, arg1, autoAction);
		if (isFunction(arg2)) return createAction(arg1, arg2, autoAction);
		if (is20223Decorator(arg2)) return (autoAction ? autoActionAnnotation : actionAnnotation).decorate_20223_(arg1, arg2);
		if (isStringish(arg2)) return storeAnnotation(arg1, arg2, autoAction ? autoActionAnnotation : actionAnnotation);
		if (isStringish(arg1)) return createDecoratorAnnotation(createActionAnnotation(autoAction ? AUTOACTION : ACTION, {
			name: arg1,
			autoAction
		}));
		die("Invalid arguments for `action`");
	};
}
function runInAction(fn) {
	return executeAction(fn.name || DEFAULT_ACTION_NAME, false, fn, this, void 0);
}
function isAction(thing) {
	return isFunction(thing) && thing.isMobxAction === true;
}
/**
* Creates a named reactive view and keeps it alive, so that the view is always
* updated if one of the dependencies changes, even when the view is not further used by something else.
* @param view The reactive view
* @returns disposer function, which can be used to stop the view from being updated in the future.
*/
function autorun(view, opts) {
	var _opts$name;
	var _opts;
	var _opts2;
	var _opts3;
	if (opts === void 0) opts = EMPTY_OBJECT;
	if (!isFunction(view)) die("Autorun expects a function as first argument");
	if (isAction(view)) die("Autorun does not accept actions since actions are untrackable");
	var name = (_opts$name = (_opts = opts) == null ? void 0 : _opts.name) != null ? _opts$name : view.name || "Autorun@" + getNextId();
	var runSync = !opts.scheduler && !opts.delay;
	var reaction;
	if (runSync) reaction = new Reaction(name, function() {
		this.track(reactionRunner);
	}, opts.onError, opts.requiresObservable);
	else {
		var scheduler = createSchedulerFromOptions(opts);
		var isScheduled = false;
		reaction = new Reaction(name, function() {
			if (!isScheduled) {
				isScheduled = true;
				scheduler(function() {
					isScheduled = false;
					if (!reaction.isDisposed) reaction.track(reactionRunner);
				});
			}
		}, opts.onError, opts.requiresObservable);
	}
	function reactionRunner() {
		view(reaction);
	}
	if (!((_opts2 = opts) != null && (_opts2 = _opts2.signal) != null && _opts2.aborted)) reaction.schedule_();
	return reaction.getDisposer_((_opts3 = opts) == null ? void 0 : _opts3.signal);
}
function createSchedulerFromOptions(opts) {
	return opts.scheduler ? opts.scheduler : opts.delay ? function(f) {
		return setTimeout(f, opts.delay);
	} : run;
}
function reaction(expression, effect, opts) {
	var _opts$name2;
	var _opts4;
	var _opts5;
	if (opts === void 0) opts = EMPTY_OBJECT;
	if (!isFunction(expression) || !isFunction(effect)) die("First and second argument to reaction should be functions");
	if (!isPlainObject(opts)) die("Third argument of reactions should be an object");
	var name = (_opts$name2 = opts.name) != null ? _opts$name2 : "Reaction@" + getNextId();
	var effectAction = action(name, opts.onError ? wrapErrorHandler(opts.onError, effect) : effect);
	var runSync = !opts.scheduler && !opts.delay;
	var scheduler = createSchedulerFromOptions(opts);
	var firstTime = true;
	var isScheduled = false;
	var value;
	var equals = opts.compareStructural ? comparer.structural : opts.equals || comparer["default"];
	var r = new Reaction(name, function() {
		if (firstTime || runSync) reactionRunner();
		else if (!isScheduled) {
			isScheduled = true;
			scheduler(reactionRunner);
		}
	}, opts.onError, opts.requiresObservable);
	function reactionRunner() {
		isScheduled = false;
		if (r.isDisposed) return;
		var changed = false;
		var oldValue = value;
		r.track(function() {
			var nextValue = allowStateChanges(false, function() {
				return expression(r);
			});
			changed = firstTime || !equals(value, nextValue);
			value = nextValue;
		});
		if (firstTime && opts.fireImmediately) effectAction(value, oldValue, r);
		else if (!firstTime && changed) effectAction(value, oldValue, r);
		firstTime = false;
	}
	if (!((_opts4 = opts) != null && (_opts4 = _opts4.signal) != null && _opts4.aborted)) r.schedule_();
	return r.getDisposer_((_opts5 = opts) == null ? void 0 : _opts5.signal);
}
function wrapErrorHandler(errorHandler, baseFn) {
	return function() {
		try {
			return baseFn.apply(this, arguments);
		} catch (e) {
			errorHandler.call(this, e);
		}
	};
}
function onBecomeObserved(thing, arg2, arg3) {
	return interceptHook(ON_BECOME_OBSERVED, thing, arg2, arg3);
}
function onBecomeUnobserved(thing, arg2, arg3) {
	return interceptHook(ON_BECOME_UNOBSERVED, thing, arg2, arg3);
}
function interceptHook(hook, thing, arg2, arg3) {
	var atom = typeof arg3 === "function" ? getAtom(thing, arg2) : getAtom(thing);
	var cb = isFunction(arg3) ? arg3 : arg2;
	var listenersKey = hook + "L";
	if (atom[listenersKey]) atom[listenersKey].add(cb);
	else atom[listenersKey] = new Set([cb]);
	return function() {
		var hookListeners = atom[listenersKey];
		if (hookListeners) {
			hookListeners["delete"](cb);
			if (hookListeners.size === 0) delete atom[listenersKey];
		}
	};
}
function configure(options) {
	if (options.isolateGlobalState === true) isolateGlobalState();
	var useProxies = options.useProxies;
	var enforceActions = options.enforceActions;
	if (useProxies !== void 0) globalState.useProxies = useProxies === ALWAYS ? true : useProxies === NEVER ? false : typeof Proxy !== "undefined";
	if (useProxies === "ifavailable") globalState.verifyProxies = true;
	if (enforceActions !== void 0) {
		var ea = enforceActions === ALWAYS ? ALWAYS : enforceActions === OBSERVED;
		globalState.enforceActions = ea;
		globalState.allowStateChanges = ea === true || ea === ALWAYS ? false : true;
	}
	[
		"computedRequiresReaction",
		"reactionRequiresObservable",
		"observableRequiresReaction",
		"disableErrorBoundaries",
		"safeDescriptors"
	].forEach(function(key) {
		if (key in options) globalState[key] = !!options[key];
	});
	globalState.allowStateReads = !globalState.observableRequiresReaction;
	if (globalState.disableErrorBoundaries === true) console.warn("WARNING: Debug feature only. MobX will NOT recover from errors when `disableErrorBoundaries` is enabled.");
	if (options.reactionScheduler) setReactionScheduler(options.reactionScheduler);
}
function extendObservable(target, properties, annotations, options) {
	if (arguments.length > 4) die("'extendObservable' expected 2-4 arguments");
	if (typeof target !== "object") die("'extendObservable' expects an object as first argument");
	if (isObservableMap(target)) die("'extendObservable' should not be used on maps, use map.merge instead");
	if (!isPlainObject(properties)) die("'extendObservable' only accepts plain objects as second argument");
	if (isObservable(properties) || isObservable(annotations)) die("Extending an object with another observable (object) is not supported");
	var descriptors = getOwnPropertyDescriptors(properties);
	initObservable(function() {
		var adm = asObservableObject(target, options)[$mobx];
		ownKeys(descriptors).forEach(function(key) {
			adm.extend_(key, descriptors[key], !annotations ? true : key in annotations ? annotations[key] : true);
		});
	});
	return target;
}
function getDependencyTree(thing, property) {
	return nodeToDependencyTree(getAtom(thing, property));
}
function nodeToDependencyTree(node) {
	var result = { name: node.name_ };
	if (node.observing_ && node.observing_.length > 0) result.dependencies = unique(node.observing_).map(nodeToDependencyTree);
	return result;
}
function getObserverTree(thing, property) {
	return nodeToObserverTree(getAtom(thing, property));
}
function nodeToObserverTree(node) {
	var result = { name: node.name_ };
	if (hasObservers(node)) result.observers = Array.from(getObservers(node)).map(nodeToObserverTree);
	return result;
}
function unique(list) {
	return Array.from(new Set(list));
}
function FlowCancellationError() {
	this.message = "FLOW_CANCELLED";
}
function isFlowCancellationError(error) {
	return error instanceof FlowCancellationError;
}
function cancelPromise(promise) {
	if (isFunction(promise.cancel)) promise.cancel();
}
function flowResult(result) {
	return result;
}
function isFlow(fn) {
	return (fn == null ? void 0 : fn.isMobXFlow) === true;
}
function interceptReads(thing, propOrHandler, handler) {
	var target;
	if (isObservableMap(thing) || isObservableArray(thing) || isObservableValue(thing)) target = getAdministration(thing);
	else if (isObservableObject(thing)) {
		if (!isStringish(propOrHandler)) return die("InterceptReads can only be used with a specific property, not with an object in general");
		target = getAdministration(thing, propOrHandler);
	} else return die("Expected observable map, object or array as first array");
	if (target.dehancer !== void 0) return die("An intercept reader was already established");
	target.dehancer = typeof propOrHandler === "function" ? propOrHandler : handler;
	return function() {
		target.dehancer = void 0;
	};
}
function intercept(thing, propOrHandler, handler) {
	if (isFunction(handler)) return interceptProperty(thing, propOrHandler, handler);
	else return interceptInterceptable(thing, propOrHandler);
}
function interceptInterceptable(thing, handler) {
	return getAdministration(thing).intercept_(handler);
}
function interceptProperty(thing, property, handler) {
	return getAdministration(thing, property).intercept_(handler);
}
function _isComputed(value, property) {
	if (property === void 0) return isComputedValue(value);
	if (isObservableObject(value) === false) return false;
	if (!value[$mobx].values_.has(property)) return false;
	return isComputedValue(getAtom(value, property));
}
function isComputed(value) {
	if (arguments.length > 1) return die("isComputed expects only 1 argument. Use isComputedProp to inspect the observability of a property");
	return _isComputed(value);
}
function isComputedProp(value, propName) {
	if (!isStringish(propName)) return die("isComputed expected a property name as second argument");
	return _isComputed(value, propName);
}
function _isObservable(value, property) {
	if (!value) return false;
	if (property !== void 0) {
		if (isObservableMap(value) || isObservableArray(value)) return die("isObservable(object, propertyName) is not supported for arrays and maps. Use map.has or array.length instead.");
		if (isObservableObject(value)) return value[$mobx].values_.has(property);
		return false;
	}
	return isObservableObject(value) || !!value[$mobx] || isAtom(value) || isReaction(value) || isComputedValue(value);
}
function isObservable(value) {
	if (arguments.length !== 1) die("isObservable expects only 1 argument. Use isObservableProp to inspect the observability of a property");
	return _isObservable(value);
}
function isObservableProp(value, propName) {
	if (!isStringish(propName)) return die("expected a property name as second argument");
	return _isObservable(value, propName);
}
function keys$1(obj) {
	if (isObservableObject(obj)) return obj[$mobx].keys_();
	if (isObservableMap(obj) || isObservableSet(obj)) return Array.from(obj.keys());
	if (isObservableArray(obj)) return obj.map(function(_, index) {
		return index;
	});
	die(5);
}
function values(obj) {
	if (isObservableObject(obj)) return keys$1(obj).map(function(key) {
		return obj[key];
	});
	if (isObservableMap(obj)) return keys$1(obj).map(function(key) {
		return obj.get(key);
	});
	if (isObservableSet(obj)) return Array.from(obj.values());
	if (isObservableArray(obj)) return obj.slice();
	die(6);
}
function entries(obj) {
	if (isObservableObject(obj)) return keys$1(obj).map(function(key) {
		return [key, obj[key]];
	});
	if (isObservableMap(obj)) return keys$1(obj).map(function(key) {
		return [key, obj.get(key)];
	});
	if (isObservableSet(obj)) return Array.from(obj.entries());
	if (isObservableArray(obj)) return obj.map(function(key, index) {
		return [index, key];
	});
	die(7);
}
function set(obj, key, value) {
	if (arguments.length === 2 && !isObservableSet(obj)) {
		startBatch();
		var _values = key;
		try {
			for (var _key in _values) set(obj, _key, _values[_key]);
		} finally {
			endBatch();
		}
		return;
	}
	if (isObservableObject(obj)) obj[$mobx].set_(key, value);
	else if (isObservableMap(obj)) obj.set(key, value);
	else if (isObservableSet(obj)) obj.add(key);
	else if (isObservableArray(obj)) {
		if (typeof key !== "number") key = parseInt(key, 10);
		if (key < 0) die("Invalid index: '" + key + "'");
		startBatch();
		if (key >= obj.length) obj.length = key + 1;
		obj[key] = value;
		endBatch();
	} else die(8);
}
function remove(obj, key) {
	if (isObservableObject(obj)) obj[$mobx].delete_(key);
	else if (isObservableMap(obj)) obj["delete"](key);
	else if (isObservableSet(obj)) obj["delete"](key);
	else if (isObservableArray(obj)) {
		if (typeof key !== "number") key = parseInt(key, 10);
		obj.splice(key, 1);
	} else die(9);
}
function has(obj, key) {
	if (isObservableObject(obj)) return obj[$mobx].has_(key);
	else if (isObservableMap(obj)) return obj.has(key);
	else if (isObservableSet(obj)) return obj.has(key);
	else if (isObservableArray(obj)) return key >= 0 && key < obj.length;
	die(10);
}
function get(obj, key) {
	if (!has(obj, key)) return;
	if (isObservableObject(obj)) return obj[$mobx].get_(key);
	else if (isObservableMap(obj)) return obj.get(key);
	else if (isObservableArray(obj)) return obj[key];
	die(11);
}
function apiDefineProperty(obj, key, descriptor) {
	if (isObservableObject(obj)) return obj[$mobx].defineProperty_(key, descriptor);
	die(39);
}
function apiOwnKeys(obj) {
	if (isObservableObject(obj)) return obj[$mobx].ownKeys_();
	die(38);
}
function observe(thing, propOrCb, cbOrFire, fireImmediately) {
	if (isFunction(cbOrFire)) return observeObservableProperty(thing, propOrCb, cbOrFire, fireImmediately);
	else return observeObservable(thing, propOrCb, cbOrFire);
}
function observeObservable(thing, listener, fireImmediately) {
	return getAdministration(thing).observe_(listener, fireImmediately);
}
function observeObservableProperty(thing, property, listener, fireImmediately) {
	return getAdministration(thing, property).observe_(listener, fireImmediately);
}
function cache(map, key, value) {
	map.set(key, value);
	return value;
}
function toJSHelper(source, __alreadySeen) {
	if (source == null || typeof source !== "object" || source instanceof Date || !isObservable(source)) return source;
	if (isObservableValue(source) || isComputedValue(source)) return toJSHelper(source.get(), __alreadySeen);
	if (__alreadySeen.has(source)) return __alreadySeen.get(source);
	if (isObservableArray(source)) {
		var res = cache(__alreadySeen, source, new Array(source.length));
		source.forEach(function(value, idx) {
			res[idx] = toJSHelper(value, __alreadySeen);
		});
		return res;
	}
	if (isObservableSet(source)) {
		var _res = cache(__alreadySeen, source, /* @__PURE__ */ new Set());
		source.forEach(function(value) {
			_res.add(toJSHelper(value, __alreadySeen));
		});
		return _res;
	}
	if (isObservableMap(source)) {
		var _res2 = cache(__alreadySeen, source, /* @__PURE__ */ new Map());
		source.forEach(function(value, key) {
			_res2.set(key, toJSHelper(value, __alreadySeen));
		});
		return _res2;
	} else {
		var _res3 = cache(__alreadySeen, source, {});
		apiOwnKeys(source).forEach(function(key) {
			if (objectPrototype.propertyIsEnumerable.call(source, key)) _res3[key] = toJSHelper(source[key], __alreadySeen);
		});
		return _res3;
	}
}
/**
* Recursively converts an observable to it's non-observable native counterpart.
* It does NOT recurse into non-observables, these are left as they are, even if they contain observables.
* Computed and other non-enumerable properties are completely ignored.
* Complex scenarios require custom solution, eg implementing `toJSON` or using `serializr` lib.
*/
function toJS(source, options) {
	if (options) die("toJS no longer supports options");
	return toJSHelper(source, /* @__PURE__ */ new Map());
}
function trace() {
	var enterBreakPoint = false;
	for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) args[_key] = arguments[_key];
	if (typeof args[args.length - 1] === "boolean") enterBreakPoint = args.pop();
	var derivation = getAtomFromArgs(args);
	if (!derivation) return die("'trace(break?)' can only be used inside a tracked computed value or a Reaction. Consider passing in the computed value or reaction explicitly");
	if (derivation.isTracing_ === TraceMode.NONE) console.log("[mobx.trace] '" + derivation.name_ + "' tracing enabled");
	derivation.isTracing_ = enterBreakPoint ? TraceMode.BREAK : TraceMode.LOG;
}
function getAtomFromArgs(args) {
	switch (args.length) {
		case 0: return globalState.trackingDerivation;
		case 1: return getAtom(args[0]);
		case 2: return getAtom(args[0], args[1]);
	}
}
/**
* During a transaction no views are updated until the end of the transaction.
* The transaction will be run synchronously nonetheless.
*
* @param action a function that updates some reactive state
* @returns any value that was returned by the 'action' parameter.
*/
function transaction(action, thisArg) {
	if (thisArg === void 0) thisArg = void 0;
	startBatch();
	try {
		return action.apply(thisArg);
	} finally {
		endBatch();
	}
}
function when(predicate, arg1, arg2) {
	if (arguments.length === 1 || arg1 && typeof arg1 === "object") return whenPromise(predicate, arg1);
	return _when(predicate, arg1, arg2 || {});
}
function _when(predicate, effect, opts) {
	var timeoutHandle;
	if (typeof opts.timeout === "number") {
		var error = /* @__PURE__ */ new Error("WHEN_TIMEOUT");
		timeoutHandle = setTimeout(function() {
			if (!disposer[$mobx].isDisposed) {
				disposer();
				if (opts.onError) opts.onError(error);
				else throw error;
			}
		}, opts.timeout);
	}
	opts.name = opts.name || "When@" + getNextId();
	var effectAction = createAction(opts.name + "-effect", effect);
	var disposer = autorun(function(r) {
		if (allowStateChanges(false, predicate)) {
			r.dispose();
			if (timeoutHandle) clearTimeout(timeoutHandle);
			effectAction();
		}
	}, opts);
	return disposer;
}
function whenPromise(predicate, opts) {
	var _opts$signal;
	if (opts && opts.onError) return die("the options 'onError' and 'promise' cannot be combined");
	if (opts != null && (_opts$signal = opts.signal) != null && _opts$signal.aborted) return Object.assign(Promise.reject(/* @__PURE__ */ new Error("WHEN_ABORTED")), { cancel: function cancel() {
		return null;
	} });
	var cancel;
	var abort;
	var res = new Promise(function(resolve, reject) {
		var _opts$signal2;
		var disposer = _when(predicate, resolve, _extends({}, opts, { onError: reject }));
		cancel = function cancel() {
			disposer();
			reject(/* @__PURE__ */ new Error("WHEN_CANCELLED"));
		};
		abort = function abort() {
			disposer();
			reject(/* @__PURE__ */ new Error("WHEN_ABORTED"));
		};
		opts == null || (_opts$signal2 = opts.signal) == null || _opts$signal2.addEventListener == null || _opts$signal2.addEventListener("abort", abort);
	})["finally"](function() {
		var _opts$signal3;
		return opts == null || (_opts$signal3 = opts.signal) == null || _opts$signal3.removeEventListener == null ? void 0 : _opts$signal3.removeEventListener("abort", abort);
	});
	res.cancel = cancel;
	return res;
}
function getAdm(target) {
	return target[$mobx];
}
function asDynamicObservableObject(target, options) {
	var _target$$mobx;
	var _target$$mobx$proxy_;
	assertProxies();
	target = asObservableObject(target, options);
	return (_target$$mobx$proxy_ = (_target$$mobx = target[$mobx]).proxy_) != null ? _target$$mobx$proxy_ : _target$$mobx.proxy_ = new Proxy(target, objectProxyTraps);
}
function hasInterceptors(interceptable) {
	return interceptable.interceptors_ !== void 0 && interceptable.interceptors_.length > 0;
}
function registerInterceptor(interceptable, handler) {
	var interceptors = interceptable.interceptors_ || (interceptable.interceptors_ = []);
	interceptors.push(handler);
	return once(function() {
		var idx = interceptors.indexOf(handler);
		if (idx !== -1) interceptors.splice(idx, 1);
	});
}
function interceptChange(interceptable, change) {
	var prevU = untrackedStart();
	try {
		var interceptors = [].concat(interceptable.interceptors_ || []);
		for (var i = 0, l = interceptors.length; i < l; i++) {
			change = interceptors[i](change);
			if (change && !change.type) die(14);
			if (!change) break;
		}
		return change;
	} finally {
		untrackedEnd(prevU);
	}
}
function hasListeners(listenable) {
	return listenable.changeListeners_ !== void 0 && listenable.changeListeners_.length > 0;
}
function registerListener(listenable, handler) {
	var listeners = listenable.changeListeners_ || (listenable.changeListeners_ = []);
	listeners.push(handler);
	return once(function() {
		var idx = listeners.indexOf(handler);
		if (idx !== -1) listeners.splice(idx, 1);
	});
}
function notifyListeners(listenable, change) {
	var prevU = untrackedStart();
	var listeners = listenable.changeListeners_;
	if (!listeners) return;
	listeners = listeners.slice();
	for (var i = 0, l = listeners.length; i < l; i++) listeners[i](change);
	untrackedEnd(prevU);
}
function makeObservable(target, annotations, options) {
	initObservable(function() {
		var adm = asObservableObject(target, options)[$mobx];
		if (annotations && target[storedAnnotationsSymbol]) die("makeObservable second arg must be nullish when using decorators. Mixing @decorator syntax with annotations is not supported.");
		annotations ??= collectStoredAnnotations(target);
		ownKeys(annotations).forEach(function(key) {
			return adm.make_(key, annotations[key]);
		});
	});
	return target;
}
function makeAutoObservable(target, overrides, options) {
	if (!isPlainObject(target) && !isPlainObject(Object.getPrototypeOf(target))) die("'makeAutoObservable' can only be used for classes that don't have a superclass");
	if (isObservableObject(target)) die("makeAutoObservable can only be used on objects not already made observable");
	if (isPlainObject(target)) return extendObservable(target, target, overrides, options);
	initObservable(function() {
		var adm = asObservableObject(target, options)[$mobx];
		if (!target[keysSymbol]) {
			var proto = Object.getPrototypeOf(target);
			var keys = new Set([].concat(ownKeys(target), ownKeys(proto)));
			keys["delete"]("constructor");
			keys["delete"]($mobx);
			addHiddenProp(proto, keysSymbol, keys);
		}
		target[keysSymbol].forEach(function(key) {
			return adm.make_(key, !overrides ? true : key in overrides ? overrides[key] : true);
		});
	});
	return target;
}
function createObservableArray(initialValues, enhancer, name, owned) {
	if (name === void 0) name = "ObservableArray@" + getNextId();
	if (owned === void 0) owned = false;
	assertProxies();
	return initObservable(function() {
		var adm = new ObservableArrayAdministration(name, enhancer, owned, false);
		addHiddenFinalProp(adm.values_, $mobx, adm);
		var proxy = new Proxy(adm.values_, arrayTraps);
		adm.proxy_ = proxy;
		if (initialValues && initialValues.length) adm.spliceWithArray_(0, 0, initialValues);
		return proxy;
	});
}
function addArrayExtension(funcName, funcFactory) {
	if (typeof Array.prototype[funcName] === "function") arrayExtensions[funcName] = funcFactory(funcName);
}
function simpleFunc(funcName) {
	return function() {
		var adm = this[$mobx];
		adm.atom_.reportObserved();
		var dehancedValues = adm.dehanceValues_(adm.values_);
		return dehancedValues[funcName].apply(dehancedValues, arguments);
	};
}
function mapLikeFunc(funcName) {
	return function(callback, thisArg) {
		var _this2 = this;
		var adm = this[$mobx];
		adm.atom_.reportObserved();
		return adm.dehanceValues_(adm.values_)[funcName](function(element, index) {
			return callback.call(thisArg, element, index, _this2);
		});
	};
}
function reduceLikeFunc(funcName) {
	return function() {
		var _this3 = this;
		var adm = this[$mobx];
		adm.atom_.reportObserved();
		var dehancedValues = adm.dehanceValues_(adm.values_);
		var callback = arguments[0];
		arguments[0] = function(accumulator, currentValue, index) {
			return callback(accumulator, currentValue, index, _this3);
		};
		return dehancedValues[funcName].apply(dehancedValues, arguments);
	};
}
function isObservableArray(thing) {
	return isObject$1(thing) && isObservableArrayAdministration(thing[$mobx]);
}
function makeIterableForMap(iterator) {
	iterator[Symbol.toStringTag] = "MapIterator";
	return makeIterable(iterator);
}
function convertToMap(dataStructure) {
	if (isES6Map(dataStructure) || isObservableMap(dataStructure)) return dataStructure;
	else if (Array.isArray(dataStructure)) return new Map(dataStructure);
	else if (isPlainObject(dataStructure)) {
		var map = /* @__PURE__ */ new Map();
		for (var key in dataStructure) map.set(key, dataStructure[key]);
		return map;
	} else return die(21, dataStructure);
}
function makeIterableForSet(iterator) {
	iterator[Symbol.toStringTag] = "SetIterator";
	return makeIterable(iterator);
}
function asObservableObject(target, options) {
	var _options$name;
	if (options && isObservableObject(target)) die("Options can't be provided for already observable objects.");
	if (hasProp(target, $mobx)) {
		if (!(getAdministration(target) instanceof ObservableObjectAdministration)) die("Cannot convert '" + getDebugName(target) + "' into observable object:\nThe target is already observable of different type.\nExtending builtins is not supported.");
		return target;
	}
	if (!Object.isExtensible(target)) die("Cannot make the designated object observable; it is not extensible");
	var name = (_options$name = options == null ? void 0 : options.name) != null ? _options$name : (isPlainObject(target) ? "ObservableObject" : target.constructor.name) + "@" + getNextId();
	addHiddenProp(target, $mobx, new ObservableObjectAdministration(target, /* @__PURE__ */ new Map(), String(name), getAnnotationFromOptions(options)));
	return target;
}
function getCachedObservablePropDescriptor(key) {
	return descriptorCache[key] || (descriptorCache[key] = {
		get: function get() {
			return this[$mobx].getObservablePropValue_(key);
		},
		set: function set(value) {
			return this[$mobx].setObservablePropValue_(key, value);
		}
	});
}
function isObservableObject(thing) {
	if (isObject$1(thing)) return isObservableObjectAdministration(thing[$mobx]);
	return false;
}
function recordAnnotationApplied(adm, annotation, key) {
	var _adm$target_$storedAn;
	adm.appliedAnnotations_[key] = annotation;
	(_adm$target_$storedAn = adm.target_[storedAnnotationsSymbol]) == null || delete _adm$target_$storedAn[key];
}
function assertAnnotable(adm, annotation, key) {
	if (!isAnnotation(annotation)) die("Cannot annotate '" + adm.name_ + "." + key.toString() + "': Invalid annotation.");
	if (!isOverride(annotation) && hasProp(adm.appliedAnnotations_, key)) {
		var fieldName = adm.name_ + "." + key.toString();
		var currentAnnotationType = adm.appliedAnnotations_[key].annotationType_;
		var requestedAnnotationType = annotation.annotationType_;
		die("Cannot apply '" + requestedAnnotationType + "' to '" + fieldName + "':" + ("\nThe field is already annotated with '" + currentAnnotationType + "'.") + "\nRe-annotating fields is not allowed.\nUse 'override' annotation for methods overridden by subclass.");
	}
}
function inherit(ctor, proto) {
	if (Object.setPrototypeOf) Object.setPrototypeOf(ctor.prototype, proto);
	else if (ctor.prototype.__proto__ !== void 0) ctor.prototype.__proto__ = proto;
	else ctor.prototype = proto;
}
function createArrayEntryDescriptor(index) {
	return {
		enumerable: false,
		configurable: true,
		get: function get() {
			return this[$mobx].get_(index);
		},
		set: function set(value) {
			this[$mobx].set_(index, value);
		}
	};
}
function createArrayBufferItem(index) {
	defineProperty(LegacyObservableArray.prototype, "" + index, createArrayEntryDescriptor(index));
}
function reserveArrayBuffer(max) {
	if (max > OBSERVABLE_ARRAY_BUFFER_SIZE) {
		for (var index = OBSERVABLE_ARRAY_BUFFER_SIZE; index < max + 100; index++) createArrayBufferItem(index);
		OBSERVABLE_ARRAY_BUFFER_SIZE = max;
	}
}
function createLegacyArray(initialValues, enhancer, name) {
	return new LegacyObservableArray(initialValues, enhancer, name);
}
function getAtom(thing, property) {
	if (typeof thing === "object" && thing !== null) {
		if (isObservableArray(thing)) {
			if (property !== void 0) die(23);
			return thing[$mobx].atom_;
		}
		if (isObservableSet(thing)) return thing.atom_;
		if (isObservableMap(thing)) {
			if (property === void 0) return thing.keysAtom_;
			var observable = thing.data_.get(property) || thing.hasMap_.get(property);
			if (!observable) die(25, property, getDebugName(thing));
			return observable;
		}
		if (isObservableObject(thing)) {
			if (!property) return die(26);
			var _observable = thing[$mobx].values_.get(property);
			if (!_observable) die(27, property, getDebugName(thing));
			return _observable;
		}
		if (isAtom(thing) || isComputedValue(thing) || isReaction(thing)) return thing;
	} else if (isFunction(thing)) {
		if (isReaction(thing[$mobx])) return thing[$mobx];
	}
	die(28);
}
function getAdministration(thing, property) {
	if (!thing) die(29);
	if (property !== void 0) return getAdministration(getAtom(thing, property));
	if (isAtom(thing) || isComputedValue(thing) || isReaction(thing)) return thing;
	if (isObservableMap(thing) || isObservableSet(thing)) return thing;
	if (thing[$mobx]) return thing[$mobx];
	die(24, thing);
}
function getDebugName(thing, property) {
	var named;
	if (property !== void 0) named = getAtom(thing, property);
	else if (isAction(thing)) return thing.name;
	else if (isObservableObject(thing) || isObservableMap(thing) || isObservableSet(thing)) named = getAdministration(thing);
	else named = getAtom(thing);
	return named.name_;
}
/**
* Helper function for initializing observable structures, it applies:
* 1. allowStateChanges so we don't violate enforceActions.
* 2. untracked so we don't accidentaly subscribe to anything observable accessed during init in case the observable is created inside derivation.
* 3. batch to avoid state version updates
*/
function initObservable(cb) {
	var derivation = untrackedStart();
	var allowStateChanges = allowStateChangesStart(true);
	startBatch();
	try {
		return cb();
	} finally {
		endBatch();
		allowStateChangesEnd(allowStateChanges);
		untrackedEnd(derivation);
	}
}
function deepEqual(a, b, depth) {
	if (depth === void 0) depth = -1;
	return eq(a, b, depth);
}
function eq(a, b, depth, aStack, bStack) {
	if (a === b) return a !== 0 || 1 / a === 1 / b;
	if (a == null || b == null) return false;
	if (a !== a) return b !== b;
	var type = typeof a;
	if (type !== "function" && type !== "object" && typeof b != "object") return false;
	var className = toString.call(a);
	if (className !== toString.call(b)) return false;
	switch (className) {
		case "[object RegExp]":
		case "[object String]": return "" + a === "" + b;
		case "[object Number]":
			if (+a !== +a) return +b !== +b;
			return +a === 0 ? 1 / +a === 1 / b : +a === +b;
		case "[object Date]":
		case "[object Boolean]": return +a === +b;
		case "[object Symbol]": return typeof Symbol !== "undefined" && Symbol.valueOf.call(a) === Symbol.valueOf.call(b);
		case "[object Map]":
		case "[object Set]":
			if (depth >= 0) depth++;
			break;
	}
	a = unwrap(a);
	b = unwrap(b);
	var areArrays = className === "[object Array]";
	if (!areArrays) {
		if (typeof a != "object" || typeof b != "object") return false;
		var aCtor = a.constructor;
		var bCtor = b.constructor;
		if (aCtor !== bCtor && !(isFunction(aCtor) && aCtor instanceof aCtor && isFunction(bCtor) && bCtor instanceof bCtor) && "constructor" in a && "constructor" in b) return false;
	}
	if (depth === 0) return false;
	else if (depth < 0) depth = -1;
	aStack = aStack || [];
	bStack = bStack || [];
	var length = aStack.length;
	while (length--) if (aStack[length] === a) return bStack[length] === b;
	aStack.push(a);
	bStack.push(b);
	if (areArrays) {
		length = a.length;
		if (length !== b.length) return false;
		while (length--) if (!eq(a[length], b[length], depth - 1, aStack, bStack)) return false;
	} else {
		var keys = Object.keys(a);
		var _length = keys.length;
		if (Object.keys(b).length !== _length) return false;
		for (var i = 0; i < _length; i++) {
			var key = keys[i];
			if (!(hasProp(b, key) && eq(a[key], b[key], depth - 1, aStack, bStack))) return false;
		}
	}
	aStack.pop();
	bStack.pop();
	return true;
}
function unwrap(a) {
	if (isObservableArray(a)) return a.slice();
	if (isES6Map(a) || isObservableMap(a)) return Array.from(a.entries());
	if (isES6Set(a) || isObservableSet(a)) return Array.from(a.entries());
	return a;
}
function makeIterable(iterator) {
	iterator[Symbol.iterator] = getSelf;
	return Object.assign(Object.create(maybeIteratorPrototype), iterator);
}
function getSelf() {
	return this;
}
function isAnnotation(thing) {
	return thing instanceof Object && typeof thing.annotationType_ === "string" && isFunction(thing.make_) && isFunction(thing.extend_);
}
var errors;
var mockGlobal;
var assign$1;
var getDescriptor;
var defineProperty;
var objectPrototype;
var EMPTY_ARRAY;
var EMPTY_OBJECT;
var hasProxy;
var plainObjectString;
var noop;
var hasGetOwnPropertySymbols;
var ownKeys;
var getOwnPropertyDescriptors;
var storedAnnotationsSymbol;
var $mobx;
var Atom;
var isAtom;
var comparer;
var OVERRIDE;
var override;
var AUTO;
var autoAnnotation;
var OBSERVABLE;
var OBSERVABLE_REF;
var OBSERVABLE_SHALLOW;
var OBSERVABLE_STRUCT;
var defaultCreateObservableOptions;
var observableAnnotation;
var observableRefAnnotation;
var observableShallowAnnotation;
var observableStructAnnotation;
var observableDecoratorAnnotation;
var observable;
var COMPUTED;
var COMPUTED_STRUCT;
var computedAnnotation;
var computedStructAnnotation;
var computed;
var _getDescriptor$config;
var _getDescriptor;
var currentActionId;
var nextActionId;
var isFunctionNameConfigurable;
var tmpNameDescriptor;
var CREATE;
var ObservableValue;
var isObservableValue;
var ComputedValue;
var isComputedValue;
var IDerivationState_;
var TraceMode;
var CaughtException;
var persistentKeys;
var MobXGlobals;
var canMergeGlobalState;
var isolateCalled;
var globalState;
var Reaction;
var MAX_REACTION_ITERATIONS;
var reactionScheduler;
var isReaction;
var END_EVENT;
var ACTION;
var ACTION_BOUND;
var AUTOACTION;
var AUTOACTION_BOUND;
var DEFAULT_ACTION_NAME;
var actionAnnotation;
var actionBoundAnnotation;
var autoActionAnnotation;
var autoActionBoundAnnotation;
var action;
var autoAction;
var run;
var ON_BECOME_OBSERVED;
var ON_BECOME_UNOBSERVED;
var NEVER;
var ALWAYS;
var OBSERVED;
var generatorId;
var flowAnnotation;
var flowBoundAnnotation;
var flow;
var objectProxyTraps;
var keysSymbol;
var SPLICE;
var UPDATE;
var MAX_SPLICE_SIZE;
var arrayTraps;
var ObservableArrayAdministration;
var arrayExtensions;
var isObservableArrayAdministration;
var ObservableMapMarker;
var ADD;
var DELETE;
var ObservableMap;
var isObservableMap;
var ObservableSetMarker;
var ObservableSet;
var isObservableSet;
var descriptorCache;
var REMOVE;
var ObservableObjectAdministration;
var isObservableObjectAdministration;
var ENTRY_0;
var safariPrototypeSetterInheritanceBug;
var OBSERVABLE_ARRAY_BUFFER_SIZE;
var StubArray;
var LegacyObservableArray;
var toString;
var _getGlobal$Iterator;
var maybeIteratorPrototype;
var init_mobx_esm = __esmMin((() => {
	errors = {
		0: "Invalid value for configuration 'enforceActions', expected 'never', 'always' or 'observed'",
		1: function _(annotationType, key) {
			return "Cannot apply '" + annotationType + "' to '" + key.toString() + "': Field not found.";
		},
		5: "'keys()' can only be used on observable objects, arrays, sets and maps",
		6: "'values()' can only be used on observable objects, arrays, sets and maps",
		7: "'entries()' can only be used on observable objects, arrays and maps",
		8: "'set()' can only be used on observable objects, arrays and maps",
		9: "'remove()' can only be used on observable objects, arrays and maps",
		10: "'has()' can only be used on observable objects, arrays and maps",
		11: "'get()' can only be used on observable objects, arrays and maps",
		12: "Invalid annotation",
		13: "Dynamic observable objects cannot be frozen. If you're passing observables to 3rd party component/function that calls Object.freeze, pass copy instead: toJS(observable)",
		14: "Intercept handlers should return nothing or a change object",
		15: "Observable arrays cannot be frozen. If you're passing observables to 3rd party component/function that calls Object.freeze, pass copy instead: toJS(observable)",
		16: "Modification exception: the internal structure of an observable array was changed.",
		17: function _(index, length) {
			return "[mobx.array] Index out of bounds, " + index + " is larger than " + length;
		},
		18: "mobx.map requires Map polyfill for the current browser. Check babel-polyfill or core-js/es6/map.js",
		19: function _(other) {
			return "Cannot initialize from classes that inherit from Map: " + other.constructor.name;
		},
		20: function _(other) {
			return "Cannot initialize map from " + other;
		},
		21: function _(dataStructure) {
			return "Cannot convert to map from '" + dataStructure + "'";
		},
		22: "mobx.set requires Set polyfill for the current browser. Check babel-polyfill or core-js/es6/set.js",
		23: "It is not possible to get index atoms from arrays",
		24: function _(thing) {
			return "Cannot obtain administration from " + thing;
		},
		25: function _(property, name) {
			return "the entry '" + property + "' does not exist in the observable map '" + name + "'";
		},
		26: "please specify a property",
		27: function _(property, name) {
			return "no observable property '" + property.toString() + "' found on the observable object '" + name + "'";
		},
		28: function _(thing) {
			return "Cannot obtain atom from " + thing;
		},
		29: "Expecting some object",
		30: "invalid action stack. did you forget to finish an action?",
		31: "missing option for computed: get",
		32: function _(name, derivation) {
			return "Cycle detected in computation " + name + ": " + derivation;
		},
		33: function _(name) {
			return "The setter of computed value '" + name + "' is trying to update itself. Did you intend to update an _observable_ value, instead of the computed property?";
		},
		34: function _(name) {
			return "[ComputedValue '" + name + "'] It is not possible to assign a new value to a computed value.";
		},
		35: "There are multiple, different versions of MobX active. Make sure MobX is loaded only once or use `configure({ isolateGlobalState: true })`",
		36: "isolateGlobalState should be called before MobX is running any reactions",
		37: function _(method) {
			return "[mobx] `observableArray." + method + "()` mutates the array in-place, which is not allowed inside a derivation. Use `array.slice()." + method + "()` instead";
		},
		38: "'ownKeys()' can only be used on observable objects",
		39: "'defineProperty()' can only be used on observable objects"
	};
	mockGlobal = {};
	assign$1 = Object.assign;
	getDescriptor = Object.getOwnPropertyDescriptor;
	defineProperty = Object.defineProperty;
	objectPrototype = Object.prototype;
	EMPTY_ARRAY = [];
	Object.freeze(EMPTY_ARRAY);
	EMPTY_OBJECT = {};
	Object.freeze(EMPTY_OBJECT);
	hasProxy = typeof Proxy !== "undefined";
	plainObjectString = /* @__PURE__ */ Object.toString();
	noop = function noop() {};
	__name(isObject$1, "isObject");
	hasGetOwnPropertySymbols = typeof Object.getOwnPropertySymbols !== "undefined";
	ownKeys = typeof Reflect !== "undefined" && Reflect.ownKeys ? Reflect.ownKeys : hasGetOwnPropertySymbols ? function(obj) {
		return Object.getOwnPropertyNames(obj).concat(Object.getOwnPropertySymbols(obj));
	} : Object.getOwnPropertyNames;
	getOwnPropertyDescriptors = Object.getOwnPropertyDescriptors || function getOwnPropertyDescriptors(target) {
		var res = {};
		ownKeys(target).forEach(function(key) {
			res[key] = getDescriptor(target, key);
		});
		return res;
	};
	storedAnnotationsSymbol = /* @__PURE__ */ Symbol("mobx-stored-annotations");
	$mobx = /* @__PURE__ */ Symbol("mobx administration");
	Atom = /* @__PURE__ */ function() {
		/**
		* Create a new atom. For debugging purposes it is recommended to give it a name.
		* The onBecomeObserved and onBecomeUnobserved callbacks can be used for resource management.
		*/
		function Atom(name_) {
			if (name_ === void 0) name_ = "Atom@" + getNextId();
			this.name_ = void 0;
			this.flags_ = 0;
			this.observers_ = /* @__PURE__ */ new Set();
			this.lastAccessedBy_ = 0;
			this.lowestObserverState_ = IDerivationState_.NOT_TRACKING_;
			this.onBOL = void 0;
			this.onBUOL = void 0;
			this.name_ = name_;
		}
		var _proto = Atom.prototype;
		_proto.onBO = function onBO() {
			if (this.onBOL) this.onBOL.forEach(function(listener) {
				return listener();
			});
		};
		_proto.onBUO = function onBUO() {
			if (this.onBUOL) this.onBUOL.forEach(function(listener) {
				return listener();
			});
		};
		_proto.reportObserved = function reportObserved$1() {
			return reportObserved(this);
		};
		_proto.reportChanged = function reportChanged() {
			startBatch();
			propagateChanged(this);
			endBatch();
		};
		_proto.toString = function toString() {
			return this.name_;
		};
		return _createClass(Atom, [
			{
				key: "isBeingObserved",
				get: function get() {
					return getFlag(this.flags_, Atom.isBeingObservedMask_);
				},
				set: function set(newValue) {
					this.flags_ = setFlag(this.flags_, Atom.isBeingObservedMask_, newValue);
				}
			},
			{
				key: "isPendingUnobservation",
				get: function get() {
					return getFlag(this.flags_, Atom.isPendingUnobservationMask_);
				},
				set: function set(newValue) {
					this.flags_ = setFlag(this.flags_, Atom.isPendingUnobservationMask_, newValue);
				}
			},
			{
				key: "diffValue",
				get: function get() {
					return getFlag(this.flags_, Atom.diffValueMask_) ? 1 : 0;
				},
				set: function set(newValue) {
					this.flags_ = setFlag(this.flags_, Atom.diffValueMask_, newValue === 1 ? true : false);
				}
			}
		]);
	}();
	Atom.isBeingObservedMask_ = 1;
	Atom.isPendingUnobservationMask_ = 2;
	Atom.diffValueMask_ = 4;
	isAtom = /* @__PURE__ */ createInstanceofPredicate("Atom", Atom);
	comparer = {
		identity: identityComparer,
		structural: structuralComparer,
		"default": defaultComparer,
		shallow: shallowComparer
	};
	OVERRIDE = "override";
	override = /* @__PURE__ */ createDecoratorAnnotation({
		annotationType_: OVERRIDE,
		make_,
		extend_,
		decorate_20223_
	});
	AUTO = "true";
	autoAnnotation = /* @__PURE__ */ createAutoAnnotation();
	OBSERVABLE = "observable";
	OBSERVABLE_REF = "observable.ref";
	OBSERVABLE_SHALLOW = "observable.shallow";
	OBSERVABLE_STRUCT = "observable.struct";
	defaultCreateObservableOptions = {
		deep: true,
		name: void 0,
		defaultDecorator: void 0,
		proxy: true
	};
	Object.freeze(defaultCreateObservableOptions);
	observableAnnotation = /* @__PURE__ */ createObservableAnnotation(OBSERVABLE);
	observableRefAnnotation = /* @__PURE__ */ createObservableAnnotation(OBSERVABLE_REF, { enhancer: referenceEnhancer });
	observableShallowAnnotation = /* @__PURE__ */ createObservableAnnotation(OBSERVABLE_SHALLOW, { enhancer: shallowEnhancer });
	observableStructAnnotation = /* @__PURE__ */ createObservableAnnotation(OBSERVABLE_STRUCT, { enhancer: refStructEnhancer });
	observableDecoratorAnnotation = /* @__PURE__ */ createDecoratorAnnotation(observableAnnotation);
	assign$1(createObservable, observableDecoratorAnnotation);
	observable = /* @__PURE__ */ assign$1(createObservable, {
		box: function box(value, options) {
			var o = asCreateObservableOptions(options);
			return new ObservableValue(value, getEnhancerFromOptions(o), o.name, true, o.equals);
		},
		array: function array(initialValues, options) {
			var o = asCreateObservableOptions(options);
			return (globalState.useProxies === false || o.proxy === false ? createLegacyArray : createObservableArray)(initialValues, getEnhancerFromOptions(o), o.name);
		},
		map: function map(initialValues, options) {
			var o = asCreateObservableOptions(options);
			return new ObservableMap(initialValues, getEnhancerFromOptions(o), o.name);
		},
		set: function set(initialValues, options) {
			var o = asCreateObservableOptions(options);
			return new ObservableSet(initialValues, getEnhancerFromOptions(o), o.name);
		},
		object: function object(props, decorators, options) {
			return initObservable(function() {
				return extendObservable(globalState.useProxies === false || (options == null ? void 0 : options.proxy) === false ? asObservableObject({}, options) : asDynamicObservableObject({}, options), props, decorators);
			});
		},
		ref: /* @__PURE__ */ createDecoratorAnnotation(observableRefAnnotation),
		shallow: /* @__PURE__ */ createDecoratorAnnotation(observableShallowAnnotation),
		deep: observableDecoratorAnnotation,
		struct: /* @__PURE__ */ createDecoratorAnnotation(observableStructAnnotation)
	});
	COMPUTED = "computed";
	COMPUTED_STRUCT = "computed.struct";
	computedAnnotation = /* @__PURE__ */ createComputedAnnotation(COMPUTED);
	computedStructAnnotation = /* @__PURE__ */ createComputedAnnotation(COMPUTED_STRUCT, { equals: comparer.structural });
	computed = function computed(arg1, arg2) {
		if (is20223Decorator(arg2)) return computedAnnotation.decorate_20223_(arg1, arg2);
		if (isStringish(arg2)) return storeAnnotation(arg1, arg2, computedAnnotation);
		if (isPlainObject(arg1)) return createDecoratorAnnotation(createComputedAnnotation(COMPUTED, arg1));
		if (!isFunction(arg1)) die("First argument to `computed` should be an expression.");
		if (isFunction(arg2)) die("A setter as second argument is no longer supported, use `{ set: fn }` option instead");
		var opts = isPlainObject(arg2) ? arg2 : {};
		opts.get = arg1;
		opts.name || (opts.name = arg1.name || "");
		return new ComputedValue(opts);
	};
	Object.assign(computed, computedAnnotation);
	computed.struct = /* @__PURE__ */ createDecoratorAnnotation(computedStructAnnotation);
	currentActionId = 0;
	nextActionId = 1;
	isFunctionNameConfigurable = (_getDescriptor$config = (_getDescriptor = /* @__PURE__ */ getDescriptor(function() {}, "name")) == null ? void 0 : _getDescriptor.configurable) != null ? _getDescriptor$config : false;
	tmpNameDescriptor = {
		value: "action",
		configurable: true,
		writable: false,
		enumerable: false
	};
	CREATE = "create";
	ObservableValue = /* @__PURE__ */ function(_Atom) {
		function ObservableValue(value, enhancer, name_, notifySpy, equals) {
			var _this;
			if (name_ === void 0) name_ = "ObservableValue@" + getNextId();
			if (notifySpy === void 0) notifySpy = true;
			if (equals === void 0) equals = comparer["default"];
			_this = _Atom.call(this, name_) || this;
			_this.enhancer = void 0;
			_this.name_ = void 0;
			_this.equals = void 0;
			_this.hasUnreportedChange_ = false;
			_this.interceptors_ = void 0;
			_this.changeListeners_ = void 0;
			_this.value_ = void 0;
			_this.dehancer = void 0;
			_this.enhancer = enhancer;
			_this.name_ = name_;
			_this.equals = equals;
			_this.value_ = enhancer(value, void 0, name_);
			if (notifySpy && isSpyEnabled()) {
				var _this$value_;
				spyReport({
					type: CREATE,
					object: _this,
					observableKind: "value",
					debugObjectName: _this.name_,
					newValue: "" + ((_this$value_ = _this.value_) == null ? void 0 : _this$value_.toString())
				});
			}
			return _this;
		}
		_inheritsLoose(ObservableValue, _Atom);
		var _proto = ObservableValue.prototype;
		_proto.dehanceValue = function dehanceValue(value) {
			if (this.dehancer !== void 0) return this.dehancer(value);
			return value;
		};
		_proto.set = function set(newValue) {
			var oldValue = this.value_;
			newValue = this.prepareNewValue_(newValue);
			if (newValue !== globalState.UNCHANGED) {
				var notifySpy = isSpyEnabled();
				if (notifySpy) spyReportStart({
					type: UPDATE,
					object: this,
					observableKind: "value",
					debugObjectName: this.name_,
					newValue,
					oldValue
				});
				this.setNewValue_(newValue);
				if (notifySpy) spyReportEnd();
			}
		};
		_proto.prepareNewValue_ = function prepareNewValue_(newValue) {
			checkIfStateModificationsAreAllowed(this);
			if (hasInterceptors(this)) {
				var change = interceptChange(this, {
					object: this,
					type: UPDATE,
					newValue
				});
				if (!change) return globalState.UNCHANGED;
				newValue = change.newValue;
			}
			newValue = this.enhancer(newValue, this.value_, this.name_);
			return this.equals(this.value_, newValue) ? globalState.UNCHANGED : newValue;
		};
		_proto.setNewValue_ = function setNewValue_(newValue) {
			var oldValue = this.value_;
			this.value_ = newValue;
			this.reportChanged();
			if (hasListeners(this)) notifyListeners(this, {
				type: UPDATE,
				object: this,
				newValue,
				oldValue
			});
		};
		_proto.get = function get() {
			this.reportObserved();
			return this.dehanceValue(this.value_);
		};
		_proto.intercept_ = function intercept_(handler) {
			return registerInterceptor(this, handler);
		};
		_proto.observe_ = function observe_(listener, fireImmediately) {
			if (fireImmediately) listener({
				observableKind: "value",
				debugObjectName: this.name_,
				object: this,
				type: UPDATE,
				newValue: this.value_,
				oldValue: void 0
			});
			return registerListener(this, listener);
		};
		_proto.raw = function raw() {
			return this.value_;
		};
		_proto.toJSON = function toJSON() {
			return this.get();
		};
		_proto.toString = function toString() {
			return this.name_ + "[" + this.value_ + "]";
		};
		_proto.valueOf = function valueOf() {
			return toPrimitive(this.get());
		};
		_proto[Symbol.toPrimitive] = function() {
			return this.valueOf();
		};
		return ObservableValue;
	}(Atom);
	isObservableValue = /* @__PURE__ */ createInstanceofPredicate("ObservableValue", ObservableValue);
	ComputedValue = /* @__PURE__ */ function() {
		/**
		* Create a new computed value based on a function expression.
		*
		* The `name` property is for debug purposes only.
		*
		* The `equals` property specifies the comparer function to use to determine if a newly produced
		* value differs from the previous value. Two comparers are provided in the library; `defaultComparer`
		* compares based on identity comparison (===), and `structuralComparer` deeply compares the structure.
		* Structural comparison can be convenient if you always produce a new aggregated object and
		* don't want to notify observers if it is structurally the same.
		* This is useful for working with vectors, mouse coordinates etc.
		*/
		function ComputedValue(options) {
			this.dependenciesState_ = IDerivationState_.NOT_TRACKING_;
			this.observing_ = [];
			this.newObserving_ = null;
			this.observers_ = /* @__PURE__ */ new Set();
			this.runId_ = 0;
			this.lastAccessedBy_ = 0;
			this.lowestObserverState_ = IDerivationState_.UP_TO_DATE_;
			this.unboundDepsCount_ = 0;
			this.value_ = new CaughtException(null);
			this.name_ = void 0;
			this.triggeredBy_ = void 0;
			this.flags_ = 0;
			this.derivation = void 0;
			this.setter_ = void 0;
			this.isTracing_ = TraceMode.NONE;
			this.scope_ = void 0;
			this.equals_ = void 0;
			this.requiresReaction_ = void 0;
			this.keepAlive_ = void 0;
			this.onBOL = void 0;
			this.onBUOL = void 0;
			if (!options.get) die(31);
			this.derivation = options.get;
			this.name_ = options.name || "ComputedValue@" + getNextId();
			if (options.set) this.setter_ = createAction(this.name_ + "-setter", options.set);
			this.equals_ = options.equals || (options.compareStructural || options.struct ? comparer.structural : comparer["default"]);
			this.scope_ = options.context;
			this.requiresReaction_ = options.requiresReaction;
			this.keepAlive_ = !!options.keepAlive;
		}
		var _proto = ComputedValue.prototype;
		_proto.onBecomeStale_ = function onBecomeStale_() {
			propagateMaybeChanged(this);
		};
		_proto.onBO = function onBO() {
			if (this.onBOL) this.onBOL.forEach(function(listener) {
				return listener();
			});
		};
		_proto.onBUO = function onBUO() {
			if (this.onBUOL) this.onBUOL.forEach(function(listener) {
				return listener();
			});
		};
		/**
		* Returns the current value of this computed value.
		* Will evaluate its computation first if needed.
		*/
		_proto.get = function get() {
			if (this.isComputing) die(32, this.name_, this.derivation);
			if (globalState.inBatch === 0 && this.observers_.size === 0 && !this.keepAlive_) {
				if (shouldCompute(this)) {
					this.warnAboutUntrackedRead_();
					startBatch();
					this.value_ = this.computeValue_(false);
					endBatch();
				}
			} else {
				reportObserved(this);
				if (shouldCompute(this)) {
					var prevTrackingContext = globalState.trackingContext;
					if (this.keepAlive_ && !prevTrackingContext) globalState.trackingContext = this;
					if (this.trackAndCompute()) propagateChangeConfirmed(this);
					globalState.trackingContext = prevTrackingContext;
				}
			}
			var result = this.value_;
			if (isCaughtException(result)) throw result.cause;
			return result;
		};
		_proto.set = function set(value) {
			if (this.setter_) {
				if (this.isRunningSetter) die(33, this.name_);
				this.isRunningSetter = true;
				try {
					this.setter_.call(this.scope_, value);
				} finally {
					this.isRunningSetter = false;
				}
			} else die(34, this.name_);
		};
		_proto.trackAndCompute = function trackAndCompute() {
			var oldValue = this.value_;
			var wasSuspended = this.dependenciesState_ === IDerivationState_.NOT_TRACKING_;
			var newValue = this.computeValue_(true);
			var changed = wasSuspended || isCaughtException(oldValue) || isCaughtException(newValue) || !this.equals_(oldValue, newValue);
			if (changed) {
				this.value_ = newValue;
				if (isSpyEnabled()) spyReport({
					observableKind: "computed",
					debugObjectName: this.name_,
					object: this.scope_,
					type: "update",
					oldValue,
					newValue
				});
			}
			return changed;
		};
		_proto.computeValue_ = function computeValue_(track) {
			this.isComputing = true;
			var prev = allowStateChangesStart(false);
			var res;
			if (track) res = trackDerivedFunction(this, this.derivation, this.scope_);
			else if (globalState.disableErrorBoundaries === true) res = this.derivation.call(this.scope_);
			else try {
				res = this.derivation.call(this.scope_);
			} catch (e) {
				res = new CaughtException(e);
			}
			allowStateChangesEnd(prev);
			this.isComputing = false;
			return res;
		};
		_proto.suspend_ = function suspend_() {
			if (!this.keepAlive_) {
				clearObserving(this);
				this.value_ = void 0;
				if (this.isTracing_ !== TraceMode.NONE) console.log("[mobx.trace] Computed value '" + this.name_ + "' was suspended and it will recompute on the next access.");
			}
		};
		_proto.observe_ = function observe_(listener, fireImmediately) {
			var _this = this;
			var firstTime = true;
			var prevValue = void 0;
			return autorun(function() {
				var newValue = _this.get();
				if (!firstTime || fireImmediately) {
					var prevU = untrackedStart();
					listener({
						observableKind: "computed",
						debugObjectName: _this.name_,
						type: UPDATE,
						object: _this,
						newValue,
						oldValue: prevValue
					});
					untrackedEnd(prevU);
				}
				firstTime = false;
				prevValue = newValue;
			});
		};
		_proto.warnAboutUntrackedRead_ = function warnAboutUntrackedRead_() {
			if (this.isTracing_ !== TraceMode.NONE) console.log("[mobx.trace] Computed value '" + this.name_ + "' is being read outside a reactive context. Doing a full recompute.");
			if (typeof this.requiresReaction_ === "boolean" ? this.requiresReaction_ : globalState.computedRequiresReaction) console.warn("[mobx] Computed value '" + this.name_ + "' is being read outside a reactive context. Doing a full recompute.");
		};
		_proto.toString = function toString() {
			return this.name_ + "[" + this.derivation.toString() + "]";
		};
		_proto.valueOf = function valueOf() {
			return toPrimitive(this.get());
		};
		_proto[Symbol.toPrimitive] = function() {
			return this.valueOf();
		};
		return _createClass(ComputedValue, [
			{
				key: "isComputing",
				get: function get() {
					return getFlag(this.flags_, ComputedValue.isComputingMask_);
				},
				set: function set(newValue) {
					this.flags_ = setFlag(this.flags_, ComputedValue.isComputingMask_, newValue);
				}
			},
			{
				key: "isRunningSetter",
				get: function get() {
					return getFlag(this.flags_, ComputedValue.isRunningSetterMask_);
				},
				set: function set(newValue) {
					this.flags_ = setFlag(this.flags_, ComputedValue.isRunningSetterMask_, newValue);
				}
			},
			{
				key: "isBeingObserved",
				get: function get() {
					return getFlag(this.flags_, ComputedValue.isBeingObservedMask_);
				},
				set: function set(newValue) {
					this.flags_ = setFlag(this.flags_, ComputedValue.isBeingObservedMask_, newValue);
				}
			},
			{
				key: "isPendingUnobservation",
				get: function get() {
					return getFlag(this.flags_, ComputedValue.isPendingUnobservationMask_);
				},
				set: function set(newValue) {
					this.flags_ = setFlag(this.flags_, ComputedValue.isPendingUnobservationMask_, newValue);
				}
			},
			{
				key: "diffValue",
				get: function get() {
					return getFlag(this.flags_, ComputedValue.diffValueMask_) ? 1 : 0;
				},
				set: function set(newValue) {
					this.flags_ = setFlag(this.flags_, ComputedValue.diffValueMask_, newValue === 1 ? true : false);
				}
			}
		]);
	}();
	ComputedValue.isComputingMask_ = 1;
	ComputedValue.isRunningSetterMask_ = 2;
	ComputedValue.isBeingObservedMask_ = 4;
	ComputedValue.isPendingUnobservationMask_ = 8;
	ComputedValue.diffValueMask_ = 16;
	isComputedValue = /* @__PURE__ */ createInstanceofPredicate("ComputedValue", ComputedValue);
	(function(IDerivationState_) {
		IDerivationState_[IDerivationState_["NOT_TRACKING_"] = -1] = "NOT_TRACKING_";
		IDerivationState_[IDerivationState_["UP_TO_DATE_"] = 0] = "UP_TO_DATE_";
		IDerivationState_[IDerivationState_["POSSIBLY_STALE_"] = 1] = "POSSIBLY_STALE_";
		IDerivationState_[IDerivationState_["STALE_"] = 2] = "STALE_";
	})(IDerivationState_ || (IDerivationState_ = {}));
	(function(TraceMode) {
		TraceMode[TraceMode["NONE"] = 0] = "NONE";
		TraceMode[TraceMode["LOG"] = 1] = "LOG";
		TraceMode[TraceMode["BREAK"] = 2] = "BREAK";
	})(TraceMode || (TraceMode = {}));
	CaughtException = function CaughtException(cause) {
		this.cause = void 0;
		this.cause = cause;
	};
	persistentKeys = [
		"mobxGuid",
		"spyListeners",
		"enforceActions",
		"computedRequiresReaction",
		"reactionRequiresObservable",
		"observableRequiresReaction",
		"allowStateReads",
		"disableErrorBoundaries",
		"runId",
		"UNCHANGED",
		"useProxies"
	];
	MobXGlobals = function MobXGlobals() {
		/**
		* MobXGlobals version.
		* MobX compatiblity with other versions loaded in memory as long as this version matches.
		* It indicates that the global state still stores similar information
		*
		* N.B: this version is unrelated to the package version of MobX, and is only the version of the
		* internal state storage of MobX, and can be the same across many different package versions
		*/
		this.version = 6;
		/**
		* globally unique token to signal unchanged
		*/
		this.UNCHANGED = {};
		/**
		* Currently running derivation
		*/
		this.trackingDerivation = null;
		/**
		* Currently running reaction. This determines if we currently have a reactive context.
		* (Tracking derivation is also set for temporal tracking of computed values inside actions,
		* but trackingReaction can only be set by a form of Reaction)
		*/
		this.trackingContext = null;
		/**
		* Each time a derivation is tracked, it is assigned a unique run-id
		*/
		this.runId = 0;
		/**
		* 'guid' for general purpose. Will be persisted amongst resets.
		*/
		this.mobxGuid = 0;
		/**
		* Are we in a batch block? (and how many of them)
		*/
		this.inBatch = 0;
		/**
		* Observables that don't have observers anymore, and are about to be
		* suspended, unless somebody else accesses it in the same batch
		*
		* @type {IObservable[]}
		*/
		this.pendingUnobservations = [];
		/**
		* List of scheduled, not yet executed, reactions.
		*/
		this.pendingReactions = [];
		/**
		* Are we currently processing reactions?
		*/
		this.isRunningReactions = false;
		/**
		* Is it allowed to change observables at this point?
		* In general, MobX doesn't allow that when running computations and React.render.
		* To ensure that those functions stay pure.
		*/
		this.allowStateChanges = false;
		/**
		* Is it allowed to read observables at this point?
		* Used to hold the state needed for `observableRequiresReaction`
		*/
		this.allowStateReads = true;
		/**
		* If strict mode is enabled, state changes are by default not allowed
		*/
		this.enforceActions = true;
		/**
		* Spy callbacks
		*/
		this.spyListeners = [];
		/**
		* Globally attached error handlers that react specifically to errors in reactions
		*/
		this.globalReactionErrorHandlers = [];
		/**
		* Warn if computed values are accessed outside a reactive context
		*/
		this.computedRequiresReaction = false;
		/**
		* (Experimental)
		* Warn if you try to create to derivation / reactive context without accessing any observable.
		*/
		this.reactionRequiresObservable = false;
		/**
		* (Experimental)
		* Warn if observables are accessed outside a reactive context
		*/
		this.observableRequiresReaction = false;
		this.disableErrorBoundaries = false;
		this.suppressReactionErrors = false;
		this.useProxies = true;
		this.verifyProxies = false;
		/**
		* False forces all object's descriptors to
		* writable: true
		* configurable: true
		*/
		this.safeDescriptors = true;
	};
	canMergeGlobalState = true;
	isolateCalled = false;
	globalState = /* @__PURE__ */ function() {
		var global = /* @__PURE__ */ getGlobal();
		if (global.__mobxInstanceCount > 0 && !global.__mobxGlobals) canMergeGlobalState = false;
		if (global.__mobxGlobals && global.__mobxGlobals.version !== new MobXGlobals().version) canMergeGlobalState = false;
		if (!canMergeGlobalState) {
			setTimeout(function() {
				if (!isolateCalled) die(35);
			}, 1);
			return new MobXGlobals();
		} else if (global.__mobxGlobals) {
			global.__mobxInstanceCount += 1;
			if (!global.__mobxGlobals.UNCHANGED) global.__mobxGlobals.UNCHANGED = {};
			return global.__mobxGlobals;
		} else {
			global.__mobxInstanceCount = 1;
			return global.__mobxGlobals = /* @__PURE__ */ new MobXGlobals();
		}
	}();
	Reaction = /* @__PURE__ */ function() {
		function Reaction(name_, onInvalidate_, errorHandler_, requiresObservable_) {
			if (name_ === void 0) name_ = "Reaction@" + getNextId();
			this.name_ = void 0;
			this.onInvalidate_ = void 0;
			this.errorHandler_ = void 0;
			this.requiresObservable_ = void 0;
			this.observing_ = [];
			this.newObserving_ = [];
			this.dependenciesState_ = IDerivationState_.NOT_TRACKING_;
			this.runId_ = 0;
			this.unboundDepsCount_ = 0;
			this.flags_ = 0;
			this.isTracing_ = TraceMode.NONE;
			this.name_ = name_;
			this.onInvalidate_ = onInvalidate_;
			this.errorHandler_ = errorHandler_;
			this.requiresObservable_ = requiresObservable_;
		}
		var _proto = Reaction.prototype;
		_proto.onBecomeStale_ = function onBecomeStale_() {
			this.schedule_();
		};
		_proto.schedule_ = function schedule_() {
			if (!this.isScheduled) {
				this.isScheduled = true;
				globalState.pendingReactions.push(this);
				runReactions();
			}
		};
		_proto.runReaction_ = function runReaction_() {
			if (!this.isDisposed) {
				startBatch();
				this.isScheduled = false;
				var prev = globalState.trackingContext;
				globalState.trackingContext = this;
				if (shouldCompute(this)) {
					this.isTrackPending = true;
					try {
						this.onInvalidate_();
						if (this.isTrackPending && isSpyEnabled()) spyReport({
							name: this.name_,
							type: "scheduled-reaction"
						});
					} catch (e) {
						this.reportExceptionInDerivation_(e);
					}
				}
				globalState.trackingContext = prev;
				endBatch();
			}
		};
		_proto.track = function track(fn) {
			if (this.isDisposed) return;
			startBatch();
			var notify = isSpyEnabled();
			var startTime;
			if (notify) {
				startTime = Date.now();
				spyReportStart({
					name: this.name_,
					type: "reaction"
				});
			}
			this.isRunning = true;
			var prevReaction = globalState.trackingContext;
			globalState.trackingContext = this;
			var result = trackDerivedFunction(this, fn, void 0);
			globalState.trackingContext = prevReaction;
			this.isRunning = false;
			this.isTrackPending = false;
			if (this.isDisposed) clearObserving(this);
			if (isCaughtException(result)) this.reportExceptionInDerivation_(result.cause);
			if (notify) spyReportEnd({ time: Date.now() - startTime });
			endBatch();
		};
		_proto.reportExceptionInDerivation_ = function reportExceptionInDerivation_(error) {
			var _this = this;
			if (this.errorHandler_) {
				this.errorHandler_(error, this);
				return;
			}
			if (globalState.disableErrorBoundaries) throw error;
			var message = "[mobx] Encountered an uncaught exception that was thrown by a reaction or observer component, in: '" + this + "'";
			if (!globalState.suppressReactionErrors) console.error(message, error);
			else console.warn("[mobx] (error in reaction '" + this.name_ + "' suppressed, fix error of causing action below)");
			if (isSpyEnabled()) spyReport({
				type: "error",
				name: this.name_,
				message,
				error: "" + error
			});
			globalState.globalReactionErrorHandlers.forEach(function(f) {
				return f(error, _this);
			});
		};
		_proto.dispose = function dispose() {
			if (!this.isDisposed) {
				this.isDisposed = true;
				if (!this.isRunning) {
					startBatch();
					clearObserving(this);
					endBatch();
				}
			}
		};
		_proto.getDisposer_ = function getDisposer_(abortSignal) {
			var _this2 = this;
			var dispose = function dispose() {
				_this2.dispose();
				abortSignal == null || abortSignal.removeEventListener == null || abortSignal.removeEventListener("abort", dispose);
			};
			abortSignal == null || abortSignal.addEventListener == null || abortSignal.addEventListener("abort", dispose);
			dispose[$mobx] = this;
			if ("dispose" in Symbol && typeof Symbol.dispose === "symbol") dispose[Symbol.dispose] = dispose;
			return dispose;
		};
		_proto.toString = function toString() {
			return "Reaction[" + this.name_ + "]";
		};
		_proto.trace = function trace$1(enterBreakPoint) {
			if (enterBreakPoint === void 0) enterBreakPoint = false;
			trace(this, enterBreakPoint);
		};
		return _createClass(Reaction, [
			{
				key: "isDisposed",
				get: function get() {
					return getFlag(this.flags_, Reaction.isDisposedMask_);
				},
				set: function set(newValue) {
					this.flags_ = setFlag(this.flags_, Reaction.isDisposedMask_, newValue);
				}
			},
			{
				key: "isScheduled",
				get: function get() {
					return getFlag(this.flags_, Reaction.isScheduledMask_);
				},
				set: function set(newValue) {
					this.flags_ = setFlag(this.flags_, Reaction.isScheduledMask_, newValue);
				}
			},
			{
				key: "isTrackPending",
				get: function get() {
					return getFlag(this.flags_, Reaction.isTrackPendingMask_);
				},
				set: function set(newValue) {
					this.flags_ = setFlag(this.flags_, Reaction.isTrackPendingMask_, newValue);
				}
			},
			{
				key: "isRunning",
				get: function get() {
					return getFlag(this.flags_, Reaction.isRunningMask_);
				},
				set: function set(newValue) {
					this.flags_ = setFlag(this.flags_, Reaction.isRunningMask_, newValue);
				}
			},
			{
				key: "diffValue",
				get: function get() {
					return getFlag(this.flags_, Reaction.diffValueMask_) ? 1 : 0;
				},
				set: function set(newValue) {
					this.flags_ = setFlag(this.flags_, Reaction.diffValueMask_, newValue === 1 ? true : false);
				}
			}
		]);
	}();
	Reaction.isDisposedMask_ = 1;
	Reaction.isScheduledMask_ = 2;
	Reaction.isTrackPendingMask_ = 4;
	Reaction.isRunningMask_ = 8;
	Reaction.diffValueMask_ = 16;
	MAX_REACTION_ITERATIONS = 100;
	reactionScheduler = function reactionScheduler(f) {
		return f();
	};
	isReaction = /* @__PURE__ */ createInstanceofPredicate("Reaction", Reaction);
	END_EVENT = {
		type: "report-end",
		spyReportEnd: true
	};
	ACTION = "action";
	ACTION_BOUND = "action.bound";
	AUTOACTION = "autoAction";
	AUTOACTION_BOUND = "autoAction.bound";
	DEFAULT_ACTION_NAME = "<unnamed action>";
	actionAnnotation = /* @__PURE__ */ createActionAnnotation(ACTION);
	actionBoundAnnotation = /* @__PURE__ */ createActionAnnotation(ACTION_BOUND, { bound: true });
	autoActionAnnotation = /* @__PURE__ */ createActionAnnotation(AUTOACTION, { autoAction: true });
	autoActionBoundAnnotation = /* @__PURE__ */ createActionAnnotation(AUTOACTION_BOUND, {
		autoAction: true,
		bound: true
	});
	action = /* @__PURE__ */ createActionFactory(false);
	Object.assign(action, actionAnnotation);
	autoAction = /* @__PURE__ */ createActionFactory(true);
	Object.assign(autoAction, autoActionAnnotation);
	action.bound = /* @__PURE__ */ createDecoratorAnnotation(actionBoundAnnotation);
	autoAction.bound = /* @__PURE__ */ createDecoratorAnnotation(autoActionBoundAnnotation);
	run = function run(f) {
		return f();
	};
	ON_BECOME_OBSERVED = "onBO";
	ON_BECOME_UNOBSERVED = "onBUO";
	NEVER = "never";
	ALWAYS = "always";
	OBSERVED = "observed";
	generatorId = 0;
	FlowCancellationError.prototype = /* @__PURE__ */ Object.create(Error.prototype);
	flowAnnotation = /* @__PURE__ */ createFlowAnnotation("flow");
	flowBoundAnnotation = /* @__PURE__ */ createFlowAnnotation("flow.bound", { bound: true });
	flow = /* @__PURE__ */ Object.assign(function flow(arg1, arg2) {
		if (is20223Decorator(arg2)) return flowAnnotation.decorate_20223_(arg1, arg2);
		if (isStringish(arg2)) return storeAnnotation(arg1, arg2, flowAnnotation);
		if (arguments.length !== 1) die("Flow expects single argument with generator function");
		var generator = arg1;
		var name = generator.name || "<unnamed flow>";
		var res = function res() {
			var ctx = this;
			var args = arguments;
			var runId = ++generatorId;
			var gen = action(name + " - runid: " + runId + " - init", generator).apply(ctx, args);
			var rejector;
			var pendingPromise = void 0;
			var promise = new Promise(function(resolve, reject) {
				var stepId = 0;
				rejector = reject;
				function onFulfilled(res) {
					pendingPromise = void 0;
					var ret;
					try {
						ret = action(name + " - runid: " + runId + " - yield " + stepId++, gen.next).call(gen, res);
					} catch (e) {
						return reject(e);
					}
					next(ret);
				}
				function onRejected(err) {
					pendingPromise = void 0;
					var ret;
					try {
						ret = action(name + " - runid: " + runId + " - yield " + stepId++, gen["throw"]).call(gen, err);
					} catch (e) {
						return reject(e);
					}
					next(ret);
				}
				function next(ret) {
					if (isFunction(ret == null ? void 0 : ret.then)) {
						ret.then(next, reject);
						return;
					}
					if (ret.done) return resolve(ret.value);
					pendingPromise = Promise.resolve(ret.value);
					return pendingPromise.then(onFulfilled, onRejected);
				}
				onFulfilled(void 0);
			});
			promise.cancel = action(name + " - runid: " + runId + " - cancel", function() {
				try {
					if (pendingPromise) cancelPromise(pendingPromise);
					var _res = gen["return"](void 0);
					var yieldedPromise = Promise.resolve(_res.value);
					yieldedPromise.then(noop, noop);
					cancelPromise(yieldedPromise);
					rejector(new FlowCancellationError());
				} catch (e) {
					rejector(e);
				}
			});
			return promise;
		};
		res.isMobXFlow = true;
		return res;
	}, flowAnnotation);
	flow.bound = /* @__PURE__ */ createDecoratorAnnotation(flowBoundAnnotation);
	__name(keys$1, "keys");
	objectProxyTraps = {
		has: function has(target, name) {
			if (globalState.trackingDerivation) warnAboutProxyRequirement("detect new properties using the 'in' operator. Use 'has' from 'mobx' instead.");
			return getAdm(target).has_(name);
		},
		get: function get(target, name) {
			return getAdm(target).get_(name);
		},
		set: function set(target, name, value) {
			var _getAdm$set_;
			if (!isStringish(name)) return false;
			if (!getAdm(target).values_.has(name)) warnAboutProxyRequirement("add a new observable property through direct assignment. Use 'set' from 'mobx' instead.");
			return (_getAdm$set_ = getAdm(target).set_(name, value, true)) != null ? _getAdm$set_ : true;
		},
		deleteProperty: function deleteProperty(target, name) {
			var _getAdm$delete_;
			warnAboutProxyRequirement("delete properties from an observable object. Use 'remove' from 'mobx' instead.");
			if (!isStringish(name)) return false;
			return (_getAdm$delete_ = getAdm(target).delete_(name, true)) != null ? _getAdm$delete_ : true;
		},
		defineProperty: function defineProperty(target, name, descriptor) {
			var _getAdm$definePropert;
			warnAboutProxyRequirement("define property on an observable object. Use 'defineProperty' from 'mobx' instead.");
			return (_getAdm$definePropert = getAdm(target).defineProperty_(name, descriptor)) != null ? _getAdm$definePropert : true;
		},
		ownKeys: function ownKeys(target) {
			if (globalState.trackingDerivation) warnAboutProxyRequirement("iterate keys to detect added / removed properties. Use 'keys' from 'mobx' instead.");
			return getAdm(target).ownKeys_();
		},
		preventExtensions: function preventExtensions(target) {
			die(13);
		}
	};
	keysSymbol = /* @__PURE__ */ Symbol("mobx-keys");
	SPLICE = "splice";
	UPDATE = "update";
	MAX_SPLICE_SIZE = 1e4;
	arrayTraps = {
		get: function get(target, name) {
			var adm = target[$mobx];
			if (name === $mobx) return adm;
			if (name === "length") return adm.getArrayLength_();
			if (typeof name === "string" && !isNaN(name)) return adm.get_(parseInt(name));
			if (hasProp(arrayExtensions, name)) return arrayExtensions[name];
			return target[name];
		},
		set: function set(target, name, value) {
			var adm = target[$mobx];
			if (name === "length") adm.setArrayLength_(value);
			if (typeof name === "symbol" || isNaN(name)) target[name] = value;
			else adm.set_(parseInt(name), value);
			return true;
		},
		preventExtensions: function preventExtensions() {
			die(15);
		}
	};
	ObservableArrayAdministration = /* @__PURE__ */ function() {
		function ObservableArrayAdministration(name, enhancer, owned_, legacyMode_) {
			if (name === void 0) name = "ObservableArray@" + getNextId();
			this.owned_ = void 0;
			this.legacyMode_ = void 0;
			this.atom_ = void 0;
			this.values_ = [];
			this.interceptors_ = void 0;
			this.changeListeners_ = void 0;
			this.enhancer_ = void 0;
			this.dehancer = void 0;
			this.proxy_ = void 0;
			this.lastKnownLength_ = 0;
			this.owned_ = owned_;
			this.legacyMode_ = legacyMode_;
			this.atom_ = new Atom(name);
			this.enhancer_ = function(newV, oldV) {
				return enhancer(newV, oldV, name + "[..]");
			};
		}
		var _proto = ObservableArrayAdministration.prototype;
		_proto.dehanceValue_ = function dehanceValue_(value) {
			if (this.dehancer !== void 0) return this.dehancer(value);
			return value;
		};
		_proto.dehanceValues_ = function dehanceValues_(values) {
			if (this.dehancer !== void 0 && values.length > 0) return values.map(this.dehancer);
			return values;
		};
		_proto.intercept_ = function intercept_(handler) {
			return registerInterceptor(this, handler);
		};
		_proto.observe_ = function observe_(listener, fireImmediately) {
			if (fireImmediately === void 0) fireImmediately = false;
			if (fireImmediately) listener({
				observableKind: "array",
				object: this.proxy_,
				debugObjectName: this.atom_.name_,
				type: "splice",
				index: 0,
				added: this.values_.slice(),
				addedCount: this.values_.length,
				removed: [],
				removedCount: 0
			});
			return registerListener(this, listener);
		};
		_proto.getArrayLength_ = function getArrayLength_() {
			this.atom_.reportObserved();
			return this.values_.length;
		};
		_proto.setArrayLength_ = function setArrayLength_(newLength) {
			if (typeof newLength !== "number" || isNaN(newLength) || newLength < 0) die("Out of range: " + newLength);
			var currentLength = this.values_.length;
			if (newLength === currentLength) return;
			else if (newLength > currentLength) {
				var newItems = new Array(newLength - currentLength);
				for (var i = 0; i < newLength - currentLength; i++) newItems[i] = void 0;
				this.spliceWithArray_(currentLength, 0, newItems);
			} else this.spliceWithArray_(newLength, currentLength - newLength);
		};
		_proto.updateArrayLength_ = function updateArrayLength_(oldLength, delta) {
			if (oldLength !== this.lastKnownLength_) die(16);
			this.lastKnownLength_ += delta;
			if (this.legacyMode_ && delta > 0) reserveArrayBuffer(oldLength + delta + 1);
		};
		_proto.spliceWithArray_ = function spliceWithArray_(index, deleteCount, newItems) {
			var _this = this;
			checkIfStateModificationsAreAllowed(this.atom_);
			var length = this.values_.length;
			if (index === void 0) index = 0;
			else if (index > length) index = length;
			else if (index < 0) index = Math.max(0, length + index);
			if (arguments.length === 1) deleteCount = length - index;
			else if (deleteCount === void 0 || deleteCount === null) deleteCount = 0;
			else deleteCount = Math.max(0, Math.min(deleteCount, length - index));
			if (newItems === void 0) newItems = EMPTY_ARRAY;
			if (hasInterceptors(this)) {
				var change = interceptChange(this, {
					object: this.proxy_,
					type: SPLICE,
					index,
					removedCount: deleteCount,
					added: newItems
				});
				if (!change) return EMPTY_ARRAY;
				deleteCount = change.removedCount;
				newItems = change.added;
			}
			newItems = newItems.length === 0 ? newItems : newItems.map(function(v) {
				return _this.enhancer_(v, void 0);
			});
			if (this.legacyMode_ || true) {
				var lengthDelta = newItems.length - deleteCount;
				this.updateArrayLength_(length, lengthDelta);
			}
			var res = this.spliceItemsIntoValues_(index, deleteCount, newItems);
			if (deleteCount !== 0 || newItems.length !== 0) this.notifyArraySplice_(index, newItems, res);
			return this.dehanceValues_(res);
		};
		_proto.spliceItemsIntoValues_ = function spliceItemsIntoValues_(index, deleteCount, newItems) {
			if (newItems.length < MAX_SPLICE_SIZE) {
				var _this$values_;
				return (_this$values_ = this.values_).splice.apply(_this$values_, [index, deleteCount].concat(newItems));
			} else {
				var res = this.values_.slice(index, index + deleteCount);
				var oldItems = this.values_.slice(index + deleteCount);
				this.values_.length += newItems.length - deleteCount;
				for (var i = 0; i < newItems.length; i++) this.values_[index + i] = newItems[i];
				for (var _i = 0; _i < oldItems.length; _i++) this.values_[index + newItems.length + _i] = oldItems[_i];
				return res;
			}
		};
		_proto.notifyArrayChildUpdate_ = function notifyArrayChildUpdate_(index, newValue, oldValue) {
			var notifySpy = !this.owned_ && isSpyEnabled();
			var notify = hasListeners(this);
			var change = notify || notifySpy ? {
				observableKind: "array",
				object: this.proxy_,
				type: UPDATE,
				debugObjectName: this.atom_.name_,
				index,
				newValue,
				oldValue
			} : null;
			if (notifySpy) spyReportStart(change);
			this.atom_.reportChanged();
			if (notify) notifyListeners(this, change);
			if (notifySpy) spyReportEnd();
		};
		_proto.notifyArraySplice_ = function notifyArraySplice_(index, added, removed) {
			var notifySpy = !this.owned_ && isSpyEnabled();
			var notify = hasListeners(this);
			var change = notify || notifySpy ? {
				observableKind: "array",
				object: this.proxy_,
				debugObjectName: this.atom_.name_,
				type: SPLICE,
				index,
				removed,
				added,
				removedCount: removed.length,
				addedCount: added.length
			} : null;
			if (notifySpy) spyReportStart(change);
			this.atom_.reportChanged();
			if (notify) notifyListeners(this, change);
			if (notifySpy) spyReportEnd();
		};
		_proto.get_ = function get_(index) {
			if (this.legacyMode_ && index >= this.values_.length) {
				console.warn("[mobx.array] Attempt to read an array index (" + index + ") that is out of bounds (" + this.values_.length + "). Please check length first. Out of bound indices will not be tracked by MobX");
				return;
			}
			this.atom_.reportObserved();
			return this.dehanceValue_(this.values_[index]);
		};
		_proto.set_ = function set_(index, newValue) {
			var values = this.values_;
			if (this.legacyMode_ && index > values.length) die(17, index, values.length);
			if (index < values.length) {
				checkIfStateModificationsAreAllowed(this.atom_);
				var oldValue = values[index];
				if (hasInterceptors(this)) {
					var change = interceptChange(this, {
						type: UPDATE,
						object: this.proxy_,
						index,
						newValue
					});
					if (!change) return;
					newValue = change.newValue;
				}
				newValue = this.enhancer_(newValue, oldValue);
				if (newValue !== oldValue) {
					values[index] = newValue;
					this.notifyArrayChildUpdate_(index, newValue, oldValue);
				}
			} else {
				var newItems = new Array(index + 1 - values.length);
				for (var i = 0; i < newItems.length - 1; i++) newItems[i] = void 0;
				newItems[newItems.length - 1] = newValue;
				this.spliceWithArray_(values.length, 0, newItems);
			}
		};
		return ObservableArrayAdministration;
	}();
	arrayExtensions = {
		clear: function clear() {
			return this.splice(0);
		},
		replace: function replace(newItems) {
			var adm = this[$mobx];
			return adm.spliceWithArray_(0, adm.values_.length, newItems);
		},
		toJSON: function toJSON() {
			return this.slice();
		},
		splice: function splice(index, deleteCount) {
			for (var _len = arguments.length, newItems = new Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++) newItems[_key - 2] = arguments[_key];
			var adm = this[$mobx];
			switch (arguments.length) {
				case 0: return [];
				case 1: return adm.spliceWithArray_(index);
				case 2: return adm.spliceWithArray_(index, deleteCount);
			}
			return adm.spliceWithArray_(index, deleteCount, newItems);
		},
		spliceWithArray: function spliceWithArray(index, deleteCount, newItems) {
			return this[$mobx].spliceWithArray_(index, deleteCount, newItems);
		},
		push: function push() {
			var adm = this[$mobx];
			for (var _len2 = arguments.length, items = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) items[_key2] = arguments[_key2];
			adm.spliceWithArray_(adm.values_.length, 0, items);
			return adm.values_.length;
		},
		pop: function pop() {
			return this.splice(Math.max(this[$mobx].values_.length - 1, 0), 1)[0];
		},
		shift: function shift() {
			return this.splice(0, 1)[0];
		},
		unshift: function unshift() {
			var adm = this[$mobx];
			for (var _len3 = arguments.length, items = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) items[_key3] = arguments[_key3];
			adm.spliceWithArray_(0, 0, items);
			return adm.values_.length;
		},
		reverse: function reverse() {
			if (globalState.trackingDerivation) die(37, "reverse");
			this.replace(this.slice().reverse());
			return this;
		},
		sort: function sort() {
			if (globalState.trackingDerivation) die(37, "sort");
			var copy = this.slice();
			copy.sort.apply(copy, arguments);
			this.replace(copy);
			return this;
		},
		remove: function remove(value) {
			var adm = this[$mobx];
			var idx = adm.dehanceValues_(adm.values_).indexOf(value);
			if (idx > -1) {
				this.splice(idx, 1);
				return true;
			}
			return false;
		}
	};
	/**
	* Wrap function from prototype
	* Without this, everything works as well, but this works
	* faster as everything works on unproxied values
	*/
	addArrayExtension("at", simpleFunc);
	addArrayExtension("concat", simpleFunc);
	addArrayExtension("flat", simpleFunc);
	addArrayExtension("includes", simpleFunc);
	addArrayExtension("indexOf", simpleFunc);
	addArrayExtension("join", simpleFunc);
	addArrayExtension("lastIndexOf", simpleFunc);
	addArrayExtension("slice", simpleFunc);
	addArrayExtension("toString", simpleFunc);
	addArrayExtension("toLocaleString", simpleFunc);
	addArrayExtension("toSorted", simpleFunc);
	addArrayExtension("toSpliced", simpleFunc);
	addArrayExtension("with", simpleFunc);
	addArrayExtension("every", mapLikeFunc);
	addArrayExtension("filter", mapLikeFunc);
	addArrayExtension("find", mapLikeFunc);
	addArrayExtension("findIndex", mapLikeFunc);
	addArrayExtension("findLast", mapLikeFunc);
	addArrayExtension("findLastIndex", mapLikeFunc);
	addArrayExtension("flatMap", mapLikeFunc);
	addArrayExtension("forEach", mapLikeFunc);
	addArrayExtension("map", mapLikeFunc);
	addArrayExtension("some", mapLikeFunc);
	addArrayExtension("toReversed", mapLikeFunc);
	addArrayExtension("reduce", reduceLikeFunc);
	addArrayExtension("reduceRight", reduceLikeFunc);
	isObservableArrayAdministration = /* @__PURE__ */ createInstanceofPredicate("ObservableArrayAdministration", ObservableArrayAdministration);
	ObservableMapMarker = {};
	ADD = "add";
	DELETE = "delete";
	ObservableMap = /* @__PURE__ */ function() {
		function ObservableMap(initialData, enhancer_, name_) {
			var _this = this;
			if (enhancer_ === void 0) enhancer_ = deepEnhancer;
			if (name_ === void 0) name_ = "ObservableMap@" + getNextId();
			this.enhancer_ = void 0;
			this.name_ = void 0;
			this[$mobx] = ObservableMapMarker;
			this.data_ = void 0;
			this.hasMap_ = void 0;
			this.keysAtom_ = void 0;
			this.interceptors_ = void 0;
			this.changeListeners_ = void 0;
			this.dehancer = void 0;
			this.enhancer_ = enhancer_;
			this.name_ = name_;
			if (!isFunction(Map)) die(18);
			initObservable(function() {
				_this.keysAtom_ = createAtom(_this.name_ + ".keys()");
				_this.data_ = /* @__PURE__ */ new Map();
				_this.hasMap_ = /* @__PURE__ */ new Map();
				if (initialData) _this.merge(initialData);
			});
		}
		var _proto = ObservableMap.prototype;
		_proto.has_ = function has_(key) {
			return this.data_.has(key);
		};
		_proto.has = function has(key) {
			var _this2 = this;
			if (!globalState.trackingDerivation) return this.has_(key);
			var entry = this.hasMap_.get(key);
			if (!entry) {
				var newEntry = entry = new ObservableValue(this.has_(key), referenceEnhancer, this.name_ + "." + stringifyKey(key) + "?", false);
				this.hasMap_.set(key, newEntry);
				onBecomeUnobserved(newEntry, function() {
					return _this2.hasMap_["delete"](key);
				});
			}
			return entry.get();
		};
		_proto.set = function set(key, value) {
			var hasKey = this.has_(key);
			if (hasInterceptors(this)) {
				var change = interceptChange(this, {
					type: hasKey ? UPDATE : ADD,
					object: this,
					newValue: value,
					name: key
				});
				if (!change) return this;
				value = change.newValue;
			}
			if (hasKey) this.updateValue_(key, value);
			else this.addValue_(key, value);
			return this;
		};
		_proto["delete"] = function _delete(key) {
			var _this3 = this;
			checkIfStateModificationsAreAllowed(this.keysAtom_);
			if (hasInterceptors(this)) {
				if (!interceptChange(this, {
					type: DELETE,
					object: this,
					name: key
				})) return false;
			}
			if (this.has_(key)) {
				var notifySpy = isSpyEnabled();
				var notify = hasListeners(this);
				var _change = notify || notifySpy ? {
					observableKind: "map",
					debugObjectName: this.name_,
					type: DELETE,
					object: this,
					oldValue: this.data_.get(key).value_,
					name: key
				} : null;
				if (notifySpy) spyReportStart(_change);
				transaction(function() {
					var _this3$hasMap_$get;
					_this3.keysAtom_.reportChanged();
					(_this3$hasMap_$get = _this3.hasMap_.get(key)) == null || _this3$hasMap_$get.setNewValue_(false);
					_this3.data_.get(key).setNewValue_(void 0);
					_this3.data_["delete"](key);
				});
				if (notify) notifyListeners(this, _change);
				if (notifySpy) spyReportEnd();
				return true;
			}
			return false;
		};
		_proto.updateValue_ = function updateValue_(key, newValue) {
			var observable = this.data_.get(key);
			newValue = observable.prepareNewValue_(newValue);
			if (newValue !== globalState.UNCHANGED) {
				var notifySpy = isSpyEnabled();
				var notify = hasListeners(this);
				var change = notify || notifySpy ? {
					observableKind: "map",
					debugObjectName: this.name_,
					type: UPDATE,
					object: this,
					oldValue: observable.value_,
					name: key,
					newValue
				} : null;
				if (notifySpy) spyReportStart(change);
				observable.setNewValue_(newValue);
				if (notify) notifyListeners(this, change);
				if (notifySpy) spyReportEnd();
			}
		};
		_proto.addValue_ = function addValue_(key, newValue) {
			var _this4 = this;
			checkIfStateModificationsAreAllowed(this.keysAtom_);
			transaction(function() {
				var _this4$hasMap_$get;
				var observable = new ObservableValue(newValue, _this4.enhancer_, _this4.name_ + "." + stringifyKey(key), false);
				_this4.data_.set(key, observable);
				newValue = observable.value_;
				(_this4$hasMap_$get = _this4.hasMap_.get(key)) == null || _this4$hasMap_$get.setNewValue_(true);
				_this4.keysAtom_.reportChanged();
			});
			var notifySpy = isSpyEnabled();
			var notify = hasListeners(this);
			var change = notify || notifySpy ? {
				observableKind: "map",
				debugObjectName: this.name_,
				type: ADD,
				object: this,
				name: key,
				newValue
			} : null;
			if (notifySpy) spyReportStart(change);
			if (notify) notifyListeners(this, change);
			if (notifySpy) spyReportEnd();
		};
		_proto.get = function get(key) {
			if (this.has(key)) return this.dehanceValue_(this.data_.get(key).get());
			return this.dehanceValue_(void 0);
		};
		_proto.dehanceValue_ = function dehanceValue_(value) {
			if (this.dehancer !== void 0) return this.dehancer(value);
			return value;
		};
		_proto.keys = function keys() {
			this.keysAtom_.reportObserved();
			return this.data_.keys();
		};
		_proto.values = function values() {
			var self = this;
			var keys = this.keys();
			return makeIterableForMap({ next: function next() {
				var _keys$next = keys.next();
				var done = _keys$next.done;
				var value = _keys$next.value;
				return {
					done,
					value: done ? void 0 : self.get(value)
				};
			} });
		};
		_proto.entries = function entries() {
			var self = this;
			var keys = this.keys();
			return makeIterableForMap({ next: function next() {
				var _keys$next2 = keys.next();
				var done = _keys$next2.done;
				var value = _keys$next2.value;
				return {
					done,
					value: done ? void 0 : [value, self.get(value)]
				};
			} });
		};
		_proto[Symbol.iterator] = function() {
			return this.entries();
		};
		_proto.forEach = function forEach(callback, thisArg) {
			for (var _iterator = _createForOfIteratorHelperLoose(this), _step; !(_step = _iterator()).done;) {
				var _step$value = _step.value;
				var key = _step$value[0];
				var value = _step$value[1];
				callback.call(thisArg, value, key, this);
			}
		};
		_proto.merge = function merge(other) {
			var _this5 = this;
			if (isObservableMap(other)) other = new Map(other);
			transaction(function() {
				if (isPlainObject(other)) getPlainObjectKeys(other).forEach(function(key) {
					return _this5.set(key, other[key]);
				});
				else if (Array.isArray(other)) other.forEach(function(_ref) {
					var key = _ref[0];
					var value = _ref[1];
					return _this5.set(key, value);
				});
				else if (isES6Map(other)) {
					if (!isPlainES6Map(other)) die(19, other);
					other.forEach(function(value, key) {
						return _this5.set(key, value);
					});
				} else if (other !== null && other !== void 0) die(20, other);
			});
			return this;
		};
		_proto.clear = function clear() {
			var _this6 = this;
			transaction(function() {
				untracked(function() {
					for (var _iterator2 = _createForOfIteratorHelperLoose(_this6.keys()), _step2; !(_step2 = _iterator2()).done;) {
						var key = _step2.value;
						_this6["delete"](key);
					}
				});
			});
		};
		_proto.replace = function replace(values) {
			var _this7 = this;
			transaction(function() {
				var replacementMap = convertToMap(values);
				var orderedData = /* @__PURE__ */ new Map();
				var keysReportChangedCalled = false;
				for (var _iterator3 = _createForOfIteratorHelperLoose(_this7.data_.keys()), _step3; !(_step3 = _iterator3()).done;) {
					var key = _step3.value;
					if (!replacementMap.has(key)) if (_this7["delete"](key)) keysReportChangedCalled = true;
					else {
						var value = _this7.data_.get(key);
						orderedData.set(key, value);
					}
				}
				for (var _iterator4 = _createForOfIteratorHelperLoose(replacementMap.entries()), _step4; !(_step4 = _iterator4()).done;) {
					var _step4$value = _step4.value;
					var _key = _step4$value[0];
					var _value = _step4$value[1];
					var keyExisted = _this7.data_.has(_key);
					_this7.set(_key, _value);
					if (_this7.data_.has(_key)) {
						var _value2 = _this7.data_.get(_key);
						orderedData.set(_key, _value2);
						if (!keyExisted) keysReportChangedCalled = true;
					}
				}
				if (!keysReportChangedCalled) if (_this7.data_.size !== orderedData.size) _this7.keysAtom_.reportChanged();
				else {
					var iter1 = _this7.data_.keys();
					var iter2 = orderedData.keys();
					var next1 = iter1.next();
					var next2 = iter2.next();
					while (!next1.done) {
						if (next1.value !== next2.value) {
							_this7.keysAtom_.reportChanged();
							break;
						}
						next1 = iter1.next();
						next2 = iter2.next();
					}
				}
				_this7.data_ = orderedData;
			});
			return this;
		};
		_proto.toString = function toString() {
			return "[object ObservableMap]";
		};
		_proto.toJSON = function toJSON() {
			return Array.from(this);
		};
		/**
		* Observes this object. Triggers for the events 'add', 'update' and 'delete'.
		* See: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/observe
		* for callback details
		*/
		_proto.observe_ = function observe_(listener, fireImmediately) {
			if (fireImmediately === true) die("`observe` doesn't support fireImmediately=true in combination with maps.");
			return registerListener(this, listener);
		};
		_proto.intercept_ = function intercept_(handler) {
			return registerInterceptor(this, handler);
		};
		return _createClass(ObservableMap, [{
			key: "size",
			get: function get() {
				this.keysAtom_.reportObserved();
				return this.data_.size;
			}
		}, {
			key: Symbol.toStringTag,
			get: function get() {
				return "Map";
			}
		}]);
	}();
	isObservableMap = /* @__PURE__ */ createInstanceofPredicate("ObservableMap", ObservableMap);
	ObservableSetMarker = {};
	ObservableSet = /* @__PURE__ */ function() {
		function ObservableSet(initialData, enhancer, name_) {
			var _this = this;
			if (enhancer === void 0) enhancer = deepEnhancer;
			if (name_ === void 0) name_ = "ObservableSet@" + getNextId();
			this.name_ = void 0;
			this[$mobx] = ObservableSetMarker;
			this.data_ = /* @__PURE__ */ new Set();
			this.atom_ = void 0;
			this.changeListeners_ = void 0;
			this.interceptors_ = void 0;
			this.dehancer = void 0;
			this.enhancer_ = void 0;
			this.name_ = name_;
			if (!isFunction(Set)) die(22);
			this.enhancer_ = function(newV, oldV) {
				return enhancer(newV, oldV, name_);
			};
			initObservable(function() {
				_this.atom_ = createAtom(_this.name_);
				if (initialData) _this.replace(initialData);
			});
		}
		var _proto = ObservableSet.prototype;
		_proto.dehanceValue_ = function dehanceValue_(value) {
			if (this.dehancer !== void 0) return this.dehancer(value);
			return value;
		};
		_proto.clear = function clear() {
			var _this2 = this;
			transaction(function() {
				untracked(function() {
					for (var _iterator = _createForOfIteratorHelperLoose(_this2.data_.values()), _step; !(_step = _iterator()).done;) {
						var value = _step.value;
						_this2["delete"](value);
					}
				});
			});
		};
		_proto.forEach = function forEach(callbackFn, thisArg) {
			for (var _iterator2 = _createForOfIteratorHelperLoose(this), _step2; !(_step2 = _iterator2()).done;) {
				var value = _step2.value;
				callbackFn.call(thisArg, value, value, this);
			}
		};
		_proto.add = function add(value) {
			var _this3 = this;
			checkIfStateModificationsAreAllowed(this.atom_);
			if (hasInterceptors(this)) {
				var change = interceptChange(this, {
					type: ADD,
					object: this,
					newValue: value
				});
				if (!change) return this;
				value = change.newValue;
			}
			if (!this.has(value)) {
				transaction(function() {
					_this3.data_.add(_this3.enhancer_(value, void 0));
					_this3.atom_.reportChanged();
				});
				var notifySpy = isSpyEnabled();
				var notify = hasListeners(this);
				var _change = notify || notifySpy ? {
					observableKind: "set",
					debugObjectName: this.name_,
					type: ADD,
					object: this,
					newValue: value
				} : null;
				if (notifySpy && true) spyReportStart(_change);
				if (notify) notifyListeners(this, _change);
				if (notifySpy && true) spyReportEnd();
			}
			return this;
		};
		_proto["delete"] = function _delete(value) {
			var _this4 = this;
			if (hasInterceptors(this)) {
				if (!interceptChange(this, {
					type: DELETE,
					object: this,
					oldValue: value
				})) return false;
			}
			if (this.has(value)) {
				var notifySpy = isSpyEnabled();
				var notify = hasListeners(this);
				var _change2 = notify || notifySpy ? {
					observableKind: "set",
					debugObjectName: this.name_,
					type: DELETE,
					object: this,
					oldValue: value
				} : null;
				if (notifySpy && true) spyReportStart(_change2);
				transaction(function() {
					_this4.atom_.reportChanged();
					_this4.data_["delete"](value);
				});
				if (notify) notifyListeners(this, _change2);
				if (notifySpy && true) spyReportEnd();
				return true;
			}
			return false;
		};
		_proto.has = function has(value) {
			this.atom_.reportObserved();
			return this.data_.has(this.dehanceValue_(value));
		};
		_proto.entries = function entries() {
			var values = this.values();
			return makeIterableForSet({ next: function next() {
				var _values$next = values.next();
				var value = _values$next.value;
				var done = _values$next.done;
				return !done ? {
					value: [value, value],
					done
				} : {
					value: void 0,
					done
				};
			} });
		};
		_proto.keys = function keys() {
			return this.values();
		};
		_proto.values = function values() {
			this.atom_.reportObserved();
			var self = this;
			var values = this.data_.values();
			return makeIterableForSet({ next: function next() {
				var _values$next2 = values.next();
				var value = _values$next2.value;
				var done = _values$next2.done;
				return !done ? {
					value: self.dehanceValue_(value),
					done
				} : {
					value: void 0,
					done
				};
			} });
		};
		_proto.intersection = function intersection(otherSet) {
			if (isES6Set(otherSet) && !isObservableSet(otherSet)) return otherSet.intersection(this);
			else return new Set(this).intersection(otherSet);
		};
		_proto.union = function union(otherSet) {
			if (isES6Set(otherSet) && !isObservableSet(otherSet)) return otherSet.union(this);
			else return new Set(this).union(otherSet);
		};
		_proto.difference = function difference(otherSet) {
			return new Set(this).difference(otherSet);
		};
		_proto.symmetricDifference = function symmetricDifference(otherSet) {
			if (isES6Set(otherSet) && !isObservableSet(otherSet)) return otherSet.symmetricDifference(this);
			else return new Set(this).symmetricDifference(otherSet);
		};
		_proto.isSubsetOf = function isSubsetOf(otherSet) {
			return new Set(this).isSubsetOf(otherSet);
		};
		_proto.isSupersetOf = function isSupersetOf(otherSet) {
			return new Set(this).isSupersetOf(otherSet);
		};
		_proto.isDisjointFrom = function isDisjointFrom(otherSet) {
			if (isES6Set(otherSet) && !isObservableSet(otherSet)) return otherSet.isDisjointFrom(this);
			else return new Set(this).isDisjointFrom(otherSet);
		};
		_proto.replace = function replace(other) {
			var _this5 = this;
			if (isObservableSet(other)) other = new Set(other);
			transaction(function() {
				if (Array.isArray(other)) {
					_this5.clear();
					other.forEach(function(value) {
						return _this5.add(value);
					});
				} else if (isES6Set(other)) {
					_this5.clear();
					other.forEach(function(value) {
						return _this5.add(value);
					});
				} else if (other !== null && other !== void 0) die("Cannot initialize set from " + other);
			});
			return this;
		};
		_proto.observe_ = function observe_(listener, fireImmediately) {
			if (fireImmediately === true) die("`observe` doesn't support fireImmediately=true in combination with sets.");
			return registerListener(this, listener);
		};
		_proto.intercept_ = function intercept_(handler) {
			return registerInterceptor(this, handler);
		};
		_proto.toJSON = function toJSON() {
			return Array.from(this);
		};
		_proto.toString = function toString() {
			return "[object ObservableSet]";
		};
		_proto[Symbol.iterator] = function() {
			return this.values();
		};
		return _createClass(ObservableSet, [{
			key: "size",
			get: function get() {
				this.atom_.reportObserved();
				return this.data_.size;
			}
		}, {
			key: Symbol.toStringTag,
			get: function get() {
				return "Set";
			}
		}]);
	}();
	isObservableSet = /* @__PURE__ */ createInstanceofPredicate("ObservableSet", ObservableSet);
	descriptorCache = /* @__PURE__ */ Object.create(null);
	REMOVE = "remove";
	ObservableObjectAdministration = /* @__PURE__ */ function() {
		function ObservableObjectAdministration(target_, values_, name_, defaultAnnotation_) {
			if (values_ === void 0) values_ = /* @__PURE__ */ new Map();
			if (defaultAnnotation_ === void 0) defaultAnnotation_ = autoAnnotation;
			this.target_ = void 0;
			this.values_ = void 0;
			this.name_ = void 0;
			this.defaultAnnotation_ = void 0;
			this.keysAtom_ = void 0;
			this.changeListeners_ = void 0;
			this.interceptors_ = void 0;
			this.proxy_ = void 0;
			this.isPlainObject_ = void 0;
			this.appliedAnnotations_ = void 0;
			this.pendingKeys_ = void 0;
			this.target_ = target_;
			this.values_ = values_;
			this.name_ = name_;
			this.defaultAnnotation_ = defaultAnnotation_;
			this.keysAtom_ = new Atom(this.name_ + ".keys");
			this.isPlainObject_ = isPlainObject(this.target_);
			if (!isAnnotation(this.defaultAnnotation_)) die("defaultAnnotation must be valid annotation");
			this.appliedAnnotations_ = {};
		}
		var _proto = ObservableObjectAdministration.prototype;
		_proto.getObservablePropValue_ = function getObservablePropValue_(key) {
			return this.values_.get(key).get();
		};
		_proto.setObservablePropValue_ = function setObservablePropValue_(key, newValue) {
			var observable = this.values_.get(key);
			if (observable instanceof ComputedValue) {
				observable.set(newValue);
				return true;
			}
			if (hasInterceptors(this)) {
				var change = interceptChange(this, {
					type: UPDATE,
					object: this.proxy_ || this.target_,
					name: key,
					newValue
				});
				if (!change) return null;
				newValue = change.newValue;
			}
			newValue = observable.prepareNewValue_(newValue);
			if (newValue !== globalState.UNCHANGED) {
				var notify = hasListeners(this);
				var notifySpy = isSpyEnabled();
				var _change = notify || notifySpy ? {
					type: UPDATE,
					observableKind: "object",
					debugObjectName: this.name_,
					object: this.proxy_ || this.target_,
					oldValue: observable.value_,
					name: key,
					newValue
				} : null;
				if (notifySpy) spyReportStart(_change);
				observable.setNewValue_(newValue);
				if (notify) notifyListeners(this, _change);
				if (notifySpy) spyReportEnd();
			}
			return true;
		};
		_proto.get_ = function get_(key) {
			if (globalState.trackingDerivation && !hasProp(this.target_, key)) this.has_(key);
			return this.target_[key];
		};
		_proto.set_ = function set_(key, value, proxyTrap) {
			if (proxyTrap === void 0) proxyTrap = false;
			if (hasProp(this.target_, key)) if (this.values_.has(key)) return this.setObservablePropValue_(key, value);
			else if (proxyTrap) return Reflect.set(this.target_, key, value);
			else {
				this.target_[key] = value;
				return true;
			}
			else return this.extend_(key, {
				value,
				enumerable: true,
				writable: true,
				configurable: true
			}, this.defaultAnnotation_, proxyTrap);
		};
		_proto.has_ = function has_(key) {
			if (!globalState.trackingDerivation) return key in this.target_;
			this.pendingKeys_ || (this.pendingKeys_ = /* @__PURE__ */ new Map());
			var entry = this.pendingKeys_.get(key);
			if (!entry) {
				entry = new ObservableValue(key in this.target_, referenceEnhancer, this.name_ + "." + stringifyKey(key) + "?", false);
				this.pendingKeys_.set(key, entry);
			}
			return entry.get();
		};
		_proto.make_ = function make_(key, annotation) {
			if (annotation === true) annotation = this.defaultAnnotation_;
			if (annotation === false) return;
			assertAnnotable(this, annotation, key);
			if (!(key in this.target_)) {
				var _this$target_$storedA;
				if ((_this$target_$storedA = this.target_[storedAnnotationsSymbol]) != null && _this$target_$storedA[key]) return;
				else die(1, annotation.annotationType_, this.name_ + "." + key.toString());
			}
			var source = this.target_;
			while (source && source !== objectPrototype) {
				var descriptor = getDescriptor(source, key);
				if (descriptor) {
					var outcome = annotation.make_(this, key, descriptor, source);
					if (outcome === 0) return;
					if (outcome === 1) break;
				}
				source = Object.getPrototypeOf(source);
			}
			recordAnnotationApplied(this, annotation, key);
		};
		_proto.extend_ = function extend_(key, descriptor, annotation, proxyTrap) {
			if (proxyTrap === void 0) proxyTrap = false;
			if (annotation === true) annotation = this.defaultAnnotation_;
			if (annotation === false) return this.defineProperty_(key, descriptor, proxyTrap);
			assertAnnotable(this, annotation, key);
			var outcome = annotation.extend_(this, key, descriptor, proxyTrap);
			if (outcome) recordAnnotationApplied(this, annotation, key);
			return outcome;
		};
		_proto.defineProperty_ = function defineProperty_(key, descriptor, proxyTrap) {
			if (proxyTrap === void 0) proxyTrap = false;
			checkIfStateModificationsAreAllowed(this.keysAtom_);
			try {
				startBatch();
				var deleteOutcome = this.delete_(key);
				if (!deleteOutcome) return deleteOutcome;
				if (hasInterceptors(this)) {
					var change = interceptChange(this, {
						object: this.proxy_ || this.target_,
						name: key,
						type: ADD,
						newValue: descriptor.value
					});
					if (!change) return null;
					var newValue = change.newValue;
					if (descriptor.value !== newValue) descriptor = _extends({}, descriptor, { value: newValue });
				}
				if (proxyTrap) {
					if (!Reflect.defineProperty(this.target_, key, descriptor)) return false;
				} else defineProperty(this.target_, key, descriptor);
				this.notifyPropertyAddition_(key, descriptor.value);
			} finally {
				endBatch();
			}
			return true;
		};
		_proto.defineObservableProperty_ = function defineObservableProperty_(key, value, enhancer, proxyTrap) {
			if (proxyTrap === void 0) proxyTrap = false;
			checkIfStateModificationsAreAllowed(this.keysAtom_);
			try {
				startBatch();
				var deleteOutcome = this.delete_(key);
				if (!deleteOutcome) return deleteOutcome;
				if (hasInterceptors(this)) {
					var change = interceptChange(this, {
						object: this.proxy_ || this.target_,
						name: key,
						type: ADD,
						newValue: value
					});
					if (!change) return null;
					value = change.newValue;
				}
				var cachedDescriptor = getCachedObservablePropDescriptor(key);
				var descriptor = {
					configurable: globalState.safeDescriptors ? this.isPlainObject_ : true,
					enumerable: true,
					get: cachedDescriptor.get,
					set: cachedDescriptor.set
				};
				if (proxyTrap) {
					if (!Reflect.defineProperty(this.target_, key, descriptor)) return false;
				} else defineProperty(this.target_, key, descriptor);
				var observable = new ObservableValue(value, enhancer, this.name_ + "." + key.toString(), false);
				this.values_.set(key, observable);
				this.notifyPropertyAddition_(key, observable.value_);
			} finally {
				endBatch();
			}
			return true;
		};
		_proto.defineComputedProperty_ = function defineComputedProperty_(key, options, proxyTrap) {
			if (proxyTrap === void 0) proxyTrap = false;
			checkIfStateModificationsAreAllowed(this.keysAtom_);
			try {
				startBatch();
				var deleteOutcome = this.delete_(key);
				if (!deleteOutcome) return deleteOutcome;
				if (hasInterceptors(this)) {
					if (!interceptChange(this, {
						object: this.proxy_ || this.target_,
						name: key,
						type: ADD,
						newValue: void 0
					})) return null;
				}
				options.name || (options.name = this.name_ + "." + key.toString());
				options.context = this.proxy_ || this.target_;
				var cachedDescriptor = getCachedObservablePropDescriptor(key);
				var descriptor = {
					configurable: globalState.safeDescriptors ? this.isPlainObject_ : true,
					enumerable: false,
					get: cachedDescriptor.get,
					set: cachedDescriptor.set
				};
				if (proxyTrap) {
					if (!Reflect.defineProperty(this.target_, key, descriptor)) return false;
				} else defineProperty(this.target_, key, descriptor);
				this.values_.set(key, new ComputedValue(options));
				this.notifyPropertyAddition_(key, void 0);
			} finally {
				endBatch();
			}
			return true;
		};
		_proto.delete_ = function delete_(key, proxyTrap) {
			if (proxyTrap === void 0) proxyTrap = false;
			checkIfStateModificationsAreAllowed(this.keysAtom_);
			if (!hasProp(this.target_, key)) return true;
			if (hasInterceptors(this)) {
				if (!interceptChange(this, {
					object: this.proxy_ || this.target_,
					name: key,
					type: REMOVE
				})) return null;
			}
			try {
				var _this$pendingKeys_;
				startBatch();
				var notify = hasListeners(this);
				var notifySpy = isSpyEnabled();
				var observable = this.values_.get(key);
				var value = void 0;
				if (!observable && (notify || notifySpy)) {
					var _getDescriptor;
					value = (_getDescriptor = getDescriptor(this.target_, key)) == null ? void 0 : _getDescriptor.value;
				}
				if (proxyTrap) {
					if (!Reflect.deleteProperty(this.target_, key)) return false;
				} else delete this.target_[key];
				delete this.appliedAnnotations_[key];
				if (observable) {
					this.values_["delete"](key);
					if (observable instanceof ObservableValue) value = observable.value_;
					propagateChanged(observable);
				}
				this.keysAtom_.reportChanged();
				(_this$pendingKeys_ = this.pendingKeys_) == null || (_this$pendingKeys_ = _this$pendingKeys_.get(key)) == null || _this$pendingKeys_.set(key in this.target_);
				if (notify || notifySpy) {
					var _change2 = {
						type: REMOVE,
						observableKind: "object",
						object: this.proxy_ || this.target_,
						debugObjectName: this.name_,
						oldValue: value,
						name: key
					};
					if (notifySpy) spyReportStart(_change2);
					if (notify) notifyListeners(this, _change2);
					if (notifySpy) spyReportEnd();
				}
			} finally {
				endBatch();
			}
			return true;
		};
		_proto.observe_ = function observe_(callback, fireImmediately) {
			if (fireImmediately === true) die("`observe` doesn't support the fire immediately property for observable objects.");
			return registerListener(this, callback);
		};
		_proto.intercept_ = function intercept_(handler) {
			return registerInterceptor(this, handler);
		};
		_proto.notifyPropertyAddition_ = function notifyPropertyAddition_(key, value) {
			var _this$pendingKeys_2;
			var notify = hasListeners(this);
			var notifySpy = isSpyEnabled();
			if (notify || notifySpy) {
				var change = notify || notifySpy ? {
					type: ADD,
					observableKind: "object",
					debugObjectName: this.name_,
					object: this.proxy_ || this.target_,
					name: key,
					newValue: value
				} : null;
				if (notifySpy) spyReportStart(change);
				if (notify) notifyListeners(this, change);
				if (notifySpy) spyReportEnd();
			}
			(_this$pendingKeys_2 = this.pendingKeys_) == null || (_this$pendingKeys_2 = _this$pendingKeys_2.get(key)) == null || _this$pendingKeys_2.set(true);
			this.keysAtom_.reportChanged();
		};
		_proto.ownKeys_ = function ownKeys_() {
			this.keysAtom_.reportObserved();
			return ownKeys(this.target_);
		};
		_proto.keys_ = function keys_() {
			this.keysAtom_.reportObserved();
			return Object.keys(this.target_);
		};
		return ObservableObjectAdministration;
	}();
	isObservableObjectAdministration = /* @__PURE__ */ createInstanceofPredicate("ObservableObjectAdministration", ObservableObjectAdministration);
	ENTRY_0 = /* @__PURE__ */ createArrayEntryDescriptor(0);
	safariPrototypeSetterInheritanceBug = /* @__PURE__ */ function() {
		var v = false;
		var p = {};
		Object.defineProperty(p, "0", { set: function set() {
			v = true;
		} });
		Object.create(p)["0"] = 1;
		return v === false;
	}();
	OBSERVABLE_ARRAY_BUFFER_SIZE = 0;
	StubArray = function StubArray() {};
	inherit(StubArray, Array.prototype);
	LegacyObservableArray = /* @__PURE__ */ function(_StubArray) {
		function LegacyObservableArray(initialValues, enhancer, name, owned) {
			var _this;
			if (name === void 0) name = "ObservableArray@" + getNextId();
			if (owned === void 0) owned = false;
			_this = _StubArray.call(this) || this;
			initObservable(function() {
				var adm = new ObservableArrayAdministration(name, enhancer, owned, true);
				adm.proxy_ = _this;
				addHiddenFinalProp(_this, $mobx, adm);
				if (initialValues && initialValues.length) _this.spliceWithArray(0, 0, initialValues);
				if (safariPrototypeSetterInheritanceBug) Object.defineProperty(_this, "0", ENTRY_0);
			});
			return _this;
		}
		_inheritsLoose(LegacyObservableArray, _StubArray);
		var _proto = LegacyObservableArray.prototype;
		_proto.concat = function concat() {
			this[$mobx].atom_.reportObserved();
			for (var _len = arguments.length, arrays = new Array(_len), _key = 0; _key < _len; _key++) arrays[_key] = arguments[_key];
			return Array.prototype.concat.apply(this.slice(), arrays.map(function(a) {
				return isObservableArray(a) ? a.slice() : a;
			}));
		};
		_proto[Symbol.iterator] = function() {
			var self = this;
			var nextIndex = 0;
			return makeIterable({ next: function next() {
				return nextIndex < self.length ? {
					value: self[nextIndex++],
					done: false
				} : {
					done: true,
					value: void 0
				};
			} });
		};
		return _createClass(LegacyObservableArray, [{
			key: "length",
			get: function get() {
				return this[$mobx].getArrayLength_();
			},
			set: function set(newLength) {
				this[$mobx].setArrayLength_(newLength);
			}
		}, {
			key: Symbol.toStringTag,
			get: function get() {
				return "Array";
			}
		}]);
	}(StubArray);
	Object.entries(arrayExtensions).forEach(function(_ref) {
		var prop = _ref[0];
		var fn = _ref[1];
		if (prop !== "concat") addHiddenProp(LegacyObservableArray.prototype, prop, fn);
	});
	reserveArrayBuffer(1e3);
	toString = objectPrototype.toString;
	maybeIteratorPrototype = ((_getGlobal$Iterator = getGlobal().Iterator) == null ? void 0 : _getGlobal$Iterator.prototype) || {};
	/**
	* (c) Michel Weststrate 2015 - 2020
	* MIT Licensed
	*
	* Welcome to the mobx sources! To get a global overview of how MobX internally works,
	* this is a good place to start:
	* https://medium.com/@mweststrate/becoming-fully-reactive-an-in-depth-explanation-of-mobservable-55995262a254#.xvbh6qd74
	*
	* Source folders:
	* ===============
	*
	* - api/     Most of the public static methods exposed by the module can be found here.
	* - core/    Implementation of the MobX algorithm; atoms, derivations, reactions, dependency trees, optimizations. Cool stuff can be found here.
	* - types/   All the magic that is need to have observable objects, arrays and values is in this folder. Including the modifiers like `asFlat`.
	* - utils/   Utility stuff.
	*
	*/
	[
		"Symbol",
		"Map",
		"Set"
	].forEach(function(m) {
		if (typeof getGlobal()[m] === "undefined") die("MobX requires global '" + m + "' to be available or polyfilled");
	});
	if (typeof __MOBX_DEVTOOLS_GLOBAL_HOOK__ === "object") __MOBX_DEVTOOLS_GLOBAL_HOOK__.injectMobx({
		spy,
		extras: { getDebugName },
		$mobx
	});
}));
var create$5;
var copy;
var setIfUndefined;
var map;
var any;
var init_map = __esmMin((() => {
	create$5 = /* @__PURE__ */ __name(() => /* @__PURE__ */ new Map(), "create");
	copy = (m) => {
		const r = create$5();
		m.forEach((v, k) => {
			r.set(k, v);
		});
		return r;
	};
	setIfUndefined = (map, key, createT) => {
		let set = map.get(key);
		if (set === void 0) map.set(key, set = createT());
		return set;
	};
	map = (m, f) => {
		const res = [];
		for (const [key, value] of m) res.push(f(value, key));
		return res;
	};
	any = (m, f) => {
		for (const [key, value] of m) if (f(value, key)) return true;
		return false;
	};
}));
var create$4;
var init_set = __esmMin((() => {
	create$4 = /* @__PURE__ */ __name(() => /* @__PURE__ */ new Set(), "create");
}));
var last;
var appendTo;
var from;
var every$1;
var some;
var unfold;
var isArray$1;
var init_array = __esmMin((() => {
	last = (arr) => arr[arr.length - 1];
	appendTo = (dest, src) => {
		for (let i = 0; i < src.length; i++) dest.push(src[i]);
	};
	from = Array.from;
	every$1 = /* @__PURE__ */ __name((arr, f) => {
		for (let i = 0; i < arr.length; i++) if (!f(arr[i], i, arr)) return false;
		return true;
	}, "every");
	some = (arr, f) => {
		for (let i = 0; i < arr.length; i++) if (f(arr[i], i, arr)) return true;
		return false;
	};
	unfold = (len, f) => {
		const array = new Array(len);
		for (let i = 0; i < len; i++) array[i] = f(i, array);
		return array;
	};
	isArray$1 = Array.isArray;
}));
var ObservableV2;
var init_observable = __esmMin((() => {
	init_map();
	init_set();
	init_array();
	ObservableV2 = class {
		constructor() {
			/**
			* Some desc.
			* @type {Map<string, Set<any>>}
			*/
			this._observers = create$5();
		}
		/**
		* @template {keyof EVENTS & string} NAME
		* @param {NAME} name
		* @param {EVENTS[NAME]} f
		*/
		on(name, f) {
			setIfUndefined(this._observers, name, create$4).add(f);
			return f;
		}
		/**
		* @template {keyof EVENTS & string} NAME
		* @param {NAME} name
		* @param {EVENTS[NAME]} f
		*/
		once(name, f) {
			/**
			* @param  {...any} args
			*/
			const _f = (...args) => {
				this.off(name, _f);
				f(...args);
			};
			this.on(name, _f);
		}
		/**
		* @template {keyof EVENTS & string} NAME
		* @param {NAME} name
		* @param {EVENTS[NAME]} f
		*/
		off(name, f) {
			const observers = this._observers.get(name);
			if (observers !== void 0) {
				observers.delete(f);
				if (observers.size === 0) this._observers.delete(name);
			}
		}
		/**
		* Emit a named event. All registered event listeners that listen to the
		* specified name will receive the event.
		*
		* @todo This should catch exceptions
		*
		* @template {keyof EVENTS & string} NAME
		* @param {NAME} name The event name.
		* @param {Parameters<EVENTS[NAME]>} args The arguments that are applied to the event listener.
		*/
		emit(name, args) {
			return from((this._observers.get(name) || create$5()).values()).forEach((f) => f(...args));
		}
		destroy() {
			this._observers = create$5();
		}
	};
}));
var floor;
var abs;
var min;
var max;
var isNegativeZero;
var init_math = __esmMin((() => {
	floor = Math.floor;
	abs = Math.abs;
	min = (a, b) => a < b ? a : b;
	max = (a, b) => a > b ? a : b;
	Number.isNaN;
	isNegativeZero = (n) => n !== 0 ? n < 0 : 1 / n < 0;
}));
var BIT18;
var BIT19;
var BIT20;
var BIT21;
var BIT22;
var BIT23;
var BIT24;
var BIT25;
var BIT26;
var BIT27;
var BIT28;
var BIT29;
var BIT30;
var BIT31;
var init_binary = __esmMin((() => {
	BIT18 = 1 << 17;
	BIT19 = 1 << 18;
	BIT20 = 1 << 19;
	BIT21 = 1 << 20;
	BIT22 = 1 << 21;
	BIT23 = 1 << 22;
	BIT24 = 1 << 23;
	BIT25 = 1 << 24;
	BIT26 = 1 << 25;
	BIT27 = 1 << 26;
	BIT28 = 1 << 27;
	BIT29 = 1 << 28;
	BIT30 = 1 << 29;
	BIT31 = 1 << 30;
	BIT18 - 1;
	BIT19 - 1;
	BIT20 - 1;
	BIT21 - 1;
	BIT22 - 1;
	BIT23 - 1;
	BIT24 - 1;
	BIT25 - 1;
	BIT26 - 1;
	BIT27 - 1;
	BIT28 - 1;
	BIT29 - 1;
	BIT30 - 1;
	BIT31 - 1;
}));
var MAX_SAFE_INTEGER;
var MIN_SAFE_INTEGER;
var isInteger;
var init_number = __esmMin((() => {
	init_math();
	init_binary();
	MAX_SAFE_INTEGER = Number.MAX_SAFE_INTEGER;
	MIN_SAFE_INTEGER = Number.MIN_SAFE_INTEGER;
	isInteger = Number.isInteger || ((num) => typeof num === "number" && isFinite(num) && floor(num) === num);
	Number.isNaN;
	Number.parseInt;
}));
var fromCharCode;
var toLowerCase;
var trimLeftRegex;
var trimLeft;
var fromCamelCaseRegex;
var fromCamelCase;
var _encodeUtf8Polyfill;
var utf8TextEncoder;
var _encodeUtf8Native;
var encodeUtf8;
var utf8TextDecoder;
var repeat;
var init_string = __esmMin((() => {
	init_array();
	fromCharCode = String.fromCharCode;
	String.fromCodePoint;
	fromCharCode(65535);
	toLowerCase = (s) => s.toLowerCase();
	trimLeftRegex = /^\s*/g;
	trimLeft = (s) => s.replace(trimLeftRegex, "");
	fromCamelCaseRegex = /([A-Z])/g;
	fromCamelCase = (s, separator) => trimLeft(s.replace(fromCamelCaseRegex, (match) => `${separator}${toLowerCase(match)}`));
	_encodeUtf8Polyfill = (str) => {
		const encodedString = unescape(encodeURIComponent(str));
		const len = encodedString.length;
		const buf = new Uint8Array(len);
		for (let i = 0; i < len; i++) buf[i] = encodedString.codePointAt(i);
		return buf;
	};
	utf8TextEncoder = typeof TextEncoder !== "undefined" ? new TextEncoder() : null;
	_encodeUtf8Native = (str) => utf8TextEncoder.encode(str);
	encodeUtf8 = utf8TextEncoder ? _encodeUtf8Native : _encodeUtf8Polyfill;
	utf8TextDecoder = typeof TextDecoder === "undefined" ? null : new TextDecoder("utf-8", {
		fatal: true,
		ignoreBOM: true
	});
	/* c8 ignore start */
	if (utf8TextDecoder && utf8TextDecoder.decode(new Uint8Array()).length === 1)
 /* c8 ignore next */
	utf8TextDecoder = null;
	repeat = (source, n) => unfold(n, () => source).join("");
}));
var Encoder;
var createEncoder;
var length;
var toUint8Array;
var verifyLen;
var write;
var writeUint8;
var writeVarUint;
var writeVarInt;
var _strBuffer;
var _maxStrBSize;
var _writeVarStringNative;
var _writeVarStringPolyfill;
var writeVarString;
var writeBinaryEncoder;
var writeUint8Array;
var writeVarUint8Array;
var writeOnDataView;
var writeFloat32;
var writeFloat64;
var writeBigInt64;
var floatTestBed;
var isFloat32;
var writeAny;
var RleEncoder;
var flushUintOptRleEncoder;
var UintOptRleEncoder;
var flushIntDiffOptRleEncoder;
var IntDiffOptRleEncoder;
var StringEncoder;
var init_encoding = __esmMin((() => {
	init_math();
	init_number();
	init_binary();
	init_string();
	init_array();
	Encoder = class {
		constructor() {
			this.cpos = 0;
			this.cbuf = new Uint8Array(100);
			/**
			* @type {Array<Uint8Array>}
			*/
			this.bufs = [];
		}
	};
	createEncoder = () => new Encoder();
	length = (encoder) => {
		let len = encoder.cpos;
		for (let i = 0; i < encoder.bufs.length; i++) len += encoder.bufs[i].length;
		return len;
	};
	toUint8Array = (encoder) => {
		const uint8arr = new Uint8Array(length(encoder));
		let curPos = 0;
		for (let i = 0; i < encoder.bufs.length; i++) {
			const d = encoder.bufs[i];
			uint8arr.set(d, curPos);
			curPos += d.length;
		}
		uint8arr.set(new Uint8Array(encoder.cbuf.buffer, 0, encoder.cpos), curPos);
		return uint8arr;
	};
	verifyLen = (encoder, len) => {
		const bufferLen = encoder.cbuf.length;
		if (bufferLen - encoder.cpos < len) {
			encoder.bufs.push(new Uint8Array(encoder.cbuf.buffer, 0, encoder.cpos));
			encoder.cbuf = new Uint8Array(max(bufferLen, len) * 2);
			encoder.cpos = 0;
		}
	};
	write = (encoder, num) => {
		const bufferLen = encoder.cbuf.length;
		if (encoder.cpos === bufferLen) {
			encoder.bufs.push(encoder.cbuf);
			encoder.cbuf = new Uint8Array(bufferLen * 2);
			encoder.cpos = 0;
		}
		encoder.cbuf[encoder.cpos++] = num;
	};
	writeUint8 = write;
	writeVarUint = (encoder, num) => {
		while (num > 127) {
			write(encoder, 128 | 127 & num);
			num = floor(num / 128);
		}
		write(encoder, 127 & num);
	};
	writeVarInt = (encoder, num) => {
		const isNegative = isNegativeZero(num);
		if (isNegative) num = -num;
		write(encoder, (num > 63 ? 128 : 0) | (isNegative ? 64 : 0) | 63 & num);
		num = floor(num / 64);
		while (num > 0) {
			write(encoder, (num > 127 ? 128 : 0) | 127 & num);
			num = floor(num / 128);
		}
	};
	_strBuffer = new Uint8Array(3e4);
	_maxStrBSize = _strBuffer.length / 3;
	_writeVarStringNative = (encoder, str) => {
		if (str.length < _maxStrBSize) {
			/* c8 ignore next */
			const written = utf8TextEncoder.encodeInto(str, _strBuffer).written || 0;
			writeVarUint(encoder, written);
			for (let i = 0; i < written; i++) write(encoder, _strBuffer[i]);
		} else writeVarUint8Array(encoder, encodeUtf8(str));
	};
	_writeVarStringPolyfill = (encoder, str) => {
		const encodedString = unescape(encodeURIComponent(str));
		const len = encodedString.length;
		writeVarUint(encoder, len);
		for (let i = 0; i < len; i++) write(encoder, encodedString.codePointAt(i));
	};
	writeVarString = utf8TextEncoder && utf8TextEncoder.encodeInto ? _writeVarStringNative : _writeVarStringPolyfill;
	writeBinaryEncoder = (encoder, append) => writeUint8Array(encoder, toUint8Array(append));
	writeUint8Array = (encoder, uint8Array) => {
		const bufferLen = encoder.cbuf.length;
		const cpos = encoder.cpos;
		const leftCopyLen = min(bufferLen - cpos, uint8Array.length);
		const rightCopyLen = uint8Array.length - leftCopyLen;
		encoder.cbuf.set(uint8Array.subarray(0, leftCopyLen), cpos);
		encoder.cpos += leftCopyLen;
		if (rightCopyLen > 0) {
			encoder.bufs.push(encoder.cbuf);
			encoder.cbuf = new Uint8Array(max(bufferLen * 2, rightCopyLen));
			encoder.cbuf.set(uint8Array.subarray(leftCopyLen));
			encoder.cpos = rightCopyLen;
		}
	};
	writeVarUint8Array = (encoder, uint8Array) => {
		writeVarUint(encoder, uint8Array.byteLength);
		writeUint8Array(encoder, uint8Array);
	};
	writeOnDataView = (encoder, len) => {
		verifyLen(encoder, len);
		const dview = new DataView(encoder.cbuf.buffer, encoder.cpos, len);
		encoder.cpos += len;
		return dview;
	};
	writeFloat32 = (encoder, num) => writeOnDataView(encoder, 4).setFloat32(0, num, false);
	writeFloat64 = (encoder, num) => writeOnDataView(encoder, 8).setFloat64(0, num, false);
	writeBigInt64 = (encoder, num) => writeOnDataView(encoder, 8).setBigInt64(0, num, false);
	floatTestBed = /* @__PURE__ */ new DataView(/* @__PURE__ */ new ArrayBuffer(4));
	isFloat32 = (num) => {
		floatTestBed.setFloat32(0, num);
		return floatTestBed.getFloat32(0) === num;
	};
	writeAny = (encoder, data) => {
		switch (typeof data) {
			case "string":
				write(encoder, 119);
				writeVarString(encoder, data);
				break;
			case "number":
				if (isInteger(data) && abs(data) <= 2147483647) {
					write(encoder, 125);
					writeVarInt(encoder, data);
				} else if (isFloat32(data)) {
					write(encoder, 124);
					writeFloat32(encoder, data);
				} else {
					write(encoder, 123);
					writeFloat64(encoder, data);
				}
				break;
			case "bigint":
				write(encoder, 122);
				writeBigInt64(encoder, data);
				break;
			case "object":
				if (data === null) write(encoder, 126);
				else if (isArray$1(data)) {
					write(encoder, 117);
					writeVarUint(encoder, data.length);
					for (let i = 0; i < data.length; i++) writeAny(encoder, data[i]);
				} else if (data instanceof Uint8Array) {
					write(encoder, 116);
					writeVarUint8Array(encoder, data);
				} else {
					write(encoder, 118);
					const keys = Object.keys(data);
					writeVarUint(encoder, keys.length);
					for (let i = 0; i < keys.length; i++) {
						const key = keys[i];
						writeVarString(encoder, key);
						writeAny(encoder, data[key]);
					}
				}
				break;
			case "boolean":
				write(encoder, data ? 120 : 121);
				break;
			default: write(encoder, 127);
		}
	};
	RleEncoder = class extends Encoder {
		/**
		* @param {function(Encoder, T):void} writer
		*/
		constructor(writer) {
			super();
			/**
			* The writer
			*/
			this.w = writer;
			/**
			* Current state
			* @type {T|null}
			*/
			this.s = null;
			this.count = 0;
		}
		/**
		* @param {T} v
		*/
		write(v) {
			if (this.s === v) this.count++;
			else {
				if (this.count > 0) writeVarUint(this, this.count - 1);
				this.count = 1;
				this.w(this, v);
				this.s = v;
			}
		}
	};
	flushUintOptRleEncoder = (encoder) => {
		if (encoder.count > 0) {
			writeVarInt(encoder.encoder, encoder.count === 1 ? encoder.s : -encoder.s);
			if (encoder.count > 1) writeVarUint(encoder.encoder, encoder.count - 2);
		}
	};
	UintOptRleEncoder = class {
		constructor() {
			this.encoder = new Encoder();
			/**
			* @type {number}
			*/
			this.s = 0;
			this.count = 0;
		}
		/**
		* @param {number} v
		*/
		write(v) {
			if (this.s === v) this.count++;
			else {
				flushUintOptRleEncoder(this);
				this.count = 1;
				this.s = v;
			}
		}
		/**
		* Flush the encoded state and transform this to a Uint8Array.
		*
		* Note that this should only be called once.
		*/
		toUint8Array() {
			flushUintOptRleEncoder(this);
			return toUint8Array(this.encoder);
		}
	};
	flushIntDiffOptRleEncoder = (encoder) => {
		if (encoder.count > 0) {
			const encodedDiff = encoder.diff * 2 + (encoder.count === 1 ? 0 : 1);
			writeVarInt(encoder.encoder, encodedDiff);
			if (encoder.count > 1) writeVarUint(encoder.encoder, encoder.count - 2);
		}
	};
	IntDiffOptRleEncoder = class {
		constructor() {
			this.encoder = new Encoder();
			/**
			* @type {number}
			*/
			this.s = 0;
			this.count = 0;
			this.diff = 0;
		}
		/**
		* @param {number} v
		*/
		write(v) {
			if (this.diff === v - this.s) {
				this.s = v;
				this.count++;
			} else {
				flushIntDiffOptRleEncoder(this);
				this.count = 1;
				this.diff = v - this.s;
				this.s = v;
			}
		}
		/**
		* Flush the encoded state and transform this to a Uint8Array.
		*
		* Note that this should only be called once.
		*/
		toUint8Array() {
			flushIntDiffOptRleEncoder(this);
			return toUint8Array(this.encoder);
		}
	};
	StringEncoder = class {
		constructor() {
			/**
			* @type {Array<string>}
			*/
			this.sarr = [];
			this.s = "";
			this.lensE = new UintOptRleEncoder();
		}
		/**
		* @param {string} string
		*/
		write(string) {
			this.s += string;
			if (this.s.length > 19) {
				this.sarr.push(this.s);
				this.s = "";
			}
			this.lensE.write(string.length);
		}
		toUint8Array() {
			const encoder = new Encoder();
			this.sarr.push(this.s);
			this.s = "";
			writeVarString(encoder, this.sarr.join(""));
			writeUint8Array(encoder, this.lensE.toUint8Array());
			return toUint8Array(encoder);
		}
	};
}));
var create$3;
var methodUnimplemented;
var unexpectedCase;
var init_error = __esmMin((() => {
	create$3 = /* @__PURE__ */ __name((s) => new Error(s), "create");
	methodUnimplemented = () => {
		throw create$3("Method unimplemented");
	};
	unexpectedCase = () => {
		throw create$3("Unexpected case");
	};
}));
var errorUnexpectedEndOfArray;
var errorIntegerOutOfRange;
var Decoder;
var createDecoder;
var hasContent;
var readUint8Array;
var readVarUint8Array;
var readUint8;
var readVarUint;
var readVarInt;
var _readVarStringPolyfill;
var _readVarStringNative;
var readVarString;
var readFromDataView;
var readFloat32;
var readFloat64;
var readBigInt64;
var readAnyLookupTable;
var readAny;
var RleDecoder;
var UintOptRleDecoder;
var IntDiffOptRleDecoder;
var StringDecoder;
var init_decoding = __esmMin((() => {
	init_binary();
	init_math();
	init_number();
	init_string();
	init_error();
	errorUnexpectedEndOfArray = create$3("Unexpected end of array");
	errorIntegerOutOfRange = create$3("Integer out of Range");
	Decoder = class {
		/**
		* @param {Uint8Array<Buf>} uint8Array Binary data to decode
		*/
		constructor(uint8Array) {
			/**
			* Decoding target.
			*
			* @type {Uint8Array<Buf>}
			*/
			this.arr = uint8Array;
			/**
			* Current decoding position.
			*
			* @type {number}
			*/
			this.pos = 0;
		}
	};
	createDecoder = (uint8Array) => new Decoder(uint8Array);
	hasContent = (decoder) => decoder.pos !== decoder.arr.length;
	readUint8Array = (decoder, len) => {
		const view = new Uint8Array(decoder.arr.buffer, decoder.pos + decoder.arr.byteOffset, len);
		decoder.pos += len;
		return view;
	};
	readVarUint8Array = (decoder) => readUint8Array(decoder, readVarUint(decoder));
	readUint8 = (decoder) => decoder.arr[decoder.pos++];
	readVarUint = (decoder) => {
		let num = 0;
		let mult = 1;
		const len = decoder.arr.length;
		while (decoder.pos < len) {
			const r = decoder.arr[decoder.pos++];
			num = num + (r & 127) * mult;
			mult *= 128;
			if (r < 128) return num;
			/* c8 ignore start */
			if (num > MAX_SAFE_INTEGER) throw errorIntegerOutOfRange;
		}
		throw errorUnexpectedEndOfArray;
	};
	readVarInt = (decoder) => {
		let r = decoder.arr[decoder.pos++];
		let num = r & 63;
		let mult = 64;
		const sign = (r & 64) > 0 ? -1 : 1;
		if ((r & 128) === 0) return sign * num;
		const len = decoder.arr.length;
		while (decoder.pos < len) {
			r = decoder.arr[decoder.pos++];
			num = num + (r & 127) * mult;
			mult *= 128;
			if (r < 128) return sign * num;
			/* c8 ignore start */
			if (num > MAX_SAFE_INTEGER) throw errorIntegerOutOfRange;
		}
		throw errorUnexpectedEndOfArray;
	};
	_readVarStringPolyfill = (decoder) => {
		let remainingLen = readVarUint(decoder);
		if (remainingLen === 0) return "";
		else {
			let encodedString = String.fromCodePoint(readUint8(decoder));
			if (--remainingLen < 100) while (remainingLen--) encodedString += String.fromCodePoint(readUint8(decoder));
			else while (remainingLen > 0) {
				const nextLen = remainingLen < 1e4 ? remainingLen : 1e4;
				const bytes = decoder.arr.subarray(decoder.pos, decoder.pos + nextLen);
				decoder.pos += nextLen;
				encodedString += String.fromCodePoint.apply(null, bytes);
				remainingLen -= nextLen;
			}
			return decodeURIComponent(escape(encodedString));
		}
	};
	_readVarStringNative = (decoder) => utf8TextDecoder.decode(readVarUint8Array(decoder));
	readVarString = utf8TextDecoder ? _readVarStringNative : _readVarStringPolyfill;
	readFromDataView = (decoder, len) => {
		const dv = new DataView(decoder.arr.buffer, decoder.arr.byteOffset + decoder.pos, len);
		decoder.pos += len;
		return dv;
	};
	readFloat32 = (decoder) => readFromDataView(decoder, 4).getFloat32(0, false);
	readFloat64 = (decoder) => readFromDataView(decoder, 8).getFloat64(0, false);
	readBigInt64 = (decoder) => readFromDataView(decoder, 8).getBigInt64(0, false);
	readAnyLookupTable = [
		(decoder) => void 0,
		(decoder) => null,
		readVarInt,
		readFloat32,
		readFloat64,
		readBigInt64,
		(decoder) => false,
		(decoder) => true,
		readVarString,
		(decoder) => {
			const len = readVarUint(decoder);
			/**
			* @type {Object<string,any>}
			*/
			const obj = {};
			for (let i = 0; i < len; i++) {
				const key = readVarString(decoder);
				obj[key] = readAny(decoder);
			}
			return obj;
		},
		(decoder) => {
			const len = readVarUint(decoder);
			const arr = [];
			for (let i = 0; i < len; i++) arr.push(readAny(decoder));
			return arr;
		},
		readVarUint8Array
	];
	readAny = (decoder) => readAnyLookupTable[127 - readUint8(decoder)](decoder);
	RleDecoder = class extends Decoder {
		/**
		* @param {Uint8Array} uint8Array
		* @param {function(Decoder):T} reader
		*/
		constructor(uint8Array, reader) {
			super(uint8Array);
			/**
			* The reader
			*/
			this.reader = reader;
			/**
			* Current state
			* @type {T|null}
			*/
			this.s = null;
			this.count = 0;
		}
		read() {
			if (this.count === 0) {
				this.s = this.reader(this);
				if (hasContent(this)) this.count = readVarUint(this) + 1;
				else this.count = -1;
			}
			this.count--;
			return this.s;
		}
	};
	UintOptRleDecoder = class extends Decoder {
		/**
		* @param {Uint8Array} uint8Array
		*/
		constructor(uint8Array) {
			super(uint8Array);
			/**
			* @type {number}
			*/
			this.s = 0;
			this.count = 0;
		}
		read() {
			if (this.count === 0) {
				this.s = readVarInt(this);
				const isNegative = isNegativeZero(this.s);
				this.count = 1;
				if (isNegative) {
					this.s = -this.s;
					this.count = readVarUint(this) + 2;
				}
			}
			this.count--;
			return this.s;
		}
	};
	IntDiffOptRleDecoder = class extends Decoder {
		/**
		* @param {Uint8Array} uint8Array
		*/
		constructor(uint8Array) {
			super(uint8Array);
			/**
			* @type {number}
			*/
			this.s = 0;
			this.count = 0;
			this.diff = 0;
		}
		/**
		* @return {number}
		*/
		read() {
			if (this.count === 0) {
				const diff = readVarInt(this);
				const hasCount = diff & 1;
				this.diff = floor(diff / 2);
				this.count = 1;
				if (hasCount) this.count = readVarUint(this) + 2;
			}
			this.s += this.diff;
			this.count--;
			return this.s;
		}
	};
	StringDecoder = class {
		/**
		* @param {Uint8Array} uint8Array
		*/
		constructor(uint8Array) {
			this.decoder = new UintOptRleDecoder(uint8Array);
			this.str = readVarString(this.decoder);
			/**
			* @type {number}
			*/
			this.spos = 0;
		}
		/**
		* @return {string}
		*/
		read() {
			const end = this.spos + this.decoder.read();
			const res = this.str.slice(this.spos, end);
			this.spos = end;
			return res;
		}
	};
}));
var getRandomValues;
var init_webcrypto = __esmMin((() => {
	crypto.subtle;
	getRandomValues = crypto.getRandomValues.bind(crypto);
}));
var uint32;
var uuidv4Template;
var uuidv4;
var init_random = __esmMin((() => {
	init_webcrypto();
	uint32 = () => getRandomValues(new Uint32Array(1))[0];
	uuidv4Template = "10000000-1000-4000-8000-100000000000";
	uuidv4 = () => uuidv4Template.replace(
		/[018]/g,
		/** @param {number} c */
		(c) => (c ^ uint32() & 15 >> c / 4).toString(16)
	);
}));
var getUnixTime;
var init_time = __esmMin((() => {
	getUnixTime = Date.now;
}));
var create$2;
var init_promise = __esmMin((() => {
	create$2 = /* @__PURE__ */ __name((f) => new Promise(f), "create");
	Promise.all.bind(Promise);
}));
var undefinedToNull;
var init_conditions = __esmMin((() => {
	undefinedToNull = (v) => v === void 0 ? null : v;
}));
var VarStoragePolyfill;
var _localStorage;
var varStorage;
var init_storage = __esmMin((() => {
	VarStoragePolyfill = class {
		constructor() {
			this.map = /* @__PURE__ */ new Map();
		}
		/**
		* @param {string} key
		* @param {any} newValue
		*/
		setItem(key, newValue) {
			this.map.set(key, newValue);
		}
		/**
		* @param {string} key
		*/
		getItem(key) {
			return this.map.get(key);
		}
	};
	_localStorage = new VarStoragePolyfill();
	/* c8 ignore start */
	try {
		if (typeof localStorage !== "undefined" && localStorage) _localStorage = localStorage;
	} catch (e) {}
	varStorage = _localStorage;
}));
var EqualityTraitSymbol;
var equals;
var init_equality = __esmMin((() => {
	EqualityTraitSymbol = Symbol("Equality");
	equals = (a, b) => a === b || !!a?.[EqualityTraitSymbol]?.(b) || false;
}));
var isObject;
var assign;
var keys;
var forEach;
var size;
var isEmpty;
var every;
var hasProperty;
var equalFlat;
var freeze;
var deepFreeze;
var init_object = __esmMin((() => {
	init_equality();
	isObject = (o) => typeof o === "object";
	assign = Object.assign;
	keys = Object.keys;
	forEach = (obj, f) => {
		for (const key in obj) f(obj[key], key);
	};
	size = (obj) => keys(obj).length;
	isEmpty = (obj) => {
		for (const _k in obj) return false;
		return true;
	};
	every = (obj, f) => {
		for (const key in obj) if (!f(obj[key], key)) return false;
		return true;
	};
	hasProperty = (obj, key) => Object.prototype.hasOwnProperty.call(obj, key);
	equalFlat = (a, b) => a === b || size(a) === size(b) && every(a, (val, key) => (val !== void 0 || hasProperty(b, key)) && equals(b[key], val));
	freeze = Object.freeze;
	deepFreeze = (o) => {
		for (const key in o) {
			const c = o[key];
			if (typeof c === "object" || typeof c === "function") deepFreeze(o[key]);
		}
		return freeze(o);
	};
}));
var callAll;
var id;
var equalityDeep;
var isOneOf;
var init_function = __esmMin((() => {
	init_array();
	init_object();
	init_equality();
	callAll = (fs, args, i = 0) => {
		try {
			for (; i < fs.length; i++) fs[i](...args);
		} finally {
			if (i < fs.length) callAll(fs, args, i + 1);
		}
	};
	id = (a) => a;
	equalityDeep = (a, b) => {
		if (a === b) return true;
		if (a == null || b == null || a.constructor !== b.constructor && (a.constructor || Object) !== (b.constructor || Object)) return false;
		if (a[EqualityTraitSymbol] != null) return a[EqualityTraitSymbol](b);
		switch (a.constructor) {
			case ArrayBuffer:
				a = new Uint8Array(a);
				b = new Uint8Array(b);
			case Uint8Array:
				if (a.byteLength !== b.byteLength) return false;
				for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
				break;
			case Set:
				if (a.size !== b.size) return false;
				for (const value of a) if (!b.has(value)) return false;
				break;
			case Map:
				if (a.size !== b.size) return false;
				for (const key of a.keys()) if (!b.has(key) || !equalityDeep(a.get(key), b.get(key))) return false;
				break;
			case void 0:
			case Object:
				if (size(a) !== size(b)) return false;
				for (const key in a) if (!hasProperty(a, key) || !equalityDeep(a[key], b[key])) return false;
				break;
			case Array:
				if (a.length !== b.length) return false;
				for (let i = 0; i < a.length; i++) if (!equalityDeep(a[i], b[i])) return false;
				break;
			default: return false;
		}
		return true;
	};
	isOneOf = (value, options) => options.includes(value);
}));
var isNode;
var params;
var args;
var computeParams;
var hasParam;
var getVariable;
var hasConf;
var production;
var forceColor;
var supportsColor;
var init_environment = __esmMin((() => {
	init_map();
	init_string();
	init_conditions();
	init_storage();
	init_function();
	isNode = typeof process !== "undefined" && process.release && /node|io\.js/.test(process.release.name) && Object.prototype.toString.call(typeof process !== "undefined" ? process : 0) === "[object process]";
	typeof navigator !== "undefined" && /Mac/.test(navigator.platform);
	args = [];
	computeParams = () => {
		if (params === void 0) if (isNode) {
			params = create$5();
			const pargs = process.argv;
			let currParamName = null;
			for (let i = 0; i < pargs.length; i++) {
				const parg = pargs[i];
				if (parg[0] === "-") {
					if (currParamName !== null) params.set(currParamName, "");
					currParamName = parg;
				} else if (currParamName !== null) {
					params.set(currParamName, parg);
					currParamName = null;
				} else args.push(parg);
			}
			if (currParamName !== null) params.set(currParamName, "");
		} else if (typeof location === "object") {
			params = create$5();
			(location.search || "?").slice(1).split("&").forEach((kv) => {
				if (kv.length !== 0) {
					const [key, value] = kv.split("=");
					params.set(`--${fromCamelCase(key, "-")}`, value);
					params.set(`-${fromCamelCase(key, "-")}`, value);
				}
			});
		} else params = create$5();
		return params;
	};
	hasParam = (name) => computeParams().has(name);
	getVariable = (name) => isNode ? undefinedToNull({}[name.toUpperCase().replaceAll("-", "_")]) : undefinedToNull(varStorage.getItem(name));
	hasConf = (name) => hasParam("--" + name) || getVariable(name) !== null;
	production = hasConf("production");
	forceColor = isNode && isOneOf({}.FORCE_COLOR, [
		"true",
		"1",
		"2"
	]);
	supportsColor = forceColor || !hasParam("--no-colors") && !hasConf("no-color") && (!isNode || process.stdout.isTTY) && (!isNode || hasParam("--color") || getVariable("COLORTERM") !== null || (getVariable("TERM") || "").includes("color"));
}));
var createUint8ArrayFromLen;
var copyUint8Array;
var init_buffer = __esmMin((() => {
	init_string();
	init_environment();
	createUint8ArrayFromLen = (len) => new Uint8Array(len);
	copyUint8Array = (uint8Array) => {
		const newBuf = createUint8ArrayFromLen(uint8Array.byteLength);
		newBuf.set(uint8Array);
		return newBuf;
	};
}));
var Pair;
var create$1;
var init_pair = __esmMin((() => {
	Pair = class {
		/**
		* @param {L} left
		* @param {R} right
		*/
		constructor(left, right) {
			this.left = left;
			this.right = right;
		}
	};
	create$1 = /* @__PURE__ */ __name((left, right) => new Pair(left, right), "create");
}));
var bool;
var int53;
var int32;
var int31;
var letter;
var word;
var oneOf;
var init_prng = __esmMin((() => {
	init_string();
	init_math();
	bool = (gen) => gen.next() >= .5;
	int53 = (gen, min, max) => floor(gen.next() * (max + 1 - min) + min);
	int32 = (gen, min, max) => floor(gen.next() * (max + 1 - min) + min);
	int31 = (gen, min, max) => int32(gen, min, max);
	letter = (gen) => fromCharCode(int31(gen, 97, 122));
	word = (gen, minLen = 0, maxLen = 20) => {
		const len = int31(gen, minLen, maxLen);
		let str = "";
		for (let i = 0; i < len; i++) str += letter(gen);
		return str;
	};
	oneOf = (gen, array) => array[int31(gen, 0, array.length - 1)];
}));
var schemaSymbol;
var ValidationError;
var shapeExtends;
var Schema;
var $ConstructedBy;
var $constructedBy;
var $Custom;
var $custom;
var $Literal;
var $literal;
var $$literal;
var _regexEscape;
var _schemaStringTemplateToRegex;
var $StringTemplate;
var isOptionalSymbol;
var $Optional;
var $$optional;
var $Never;
var $Object;
var $object;
var $$object;
var $objectAny;
var $Record;
var $record;
var $$record;
var $Tuple;
var $tuple;
var $Array;
var $array;
var $$array;
var $arrayAny;
var $InstanceOf;
var $instanceOf;
var $$schema;
var $Lambda;
var $$lambda;
var $function;
var $Intersection;
var $Union;
var $union;
var $$union;
var _t;
var $any;
var $$any;
var $bigint;
var $$bigint;
var $symbol;
var $number;
var $$number;
var $string;
var $$string;
var $boolean;
var $$boolean;
var $undefined;
var $null;
var $$null;
var $primitive;
var $;
var assert;
var PatternMatcher;
var match;
var _random;
var random;
var init_schema = __esmMin((() => {
	init_object();
	init_array();
	init_error();
	init_environment();
	init_equality();
	init_function();
	init_string();
	init_prng();
	init_number();
	schemaSymbol = Symbol("0schema");
	ValidationError = class {
		constructor() {
			/**
			* Reverse errors
			* @type {Array<{ path: string?, expected: string, has: string, message: string? }>}
			*/
			this._rerrs = [];
		}
		/**
		* @param {string?} path
		* @param {string} expected
		* @param {string} has
		* @param {string?} message
		*/
		extend(path, expected, has, message = null) {
			this._rerrs.push({
				path,
				expected,
				has,
				message
			});
		}
		toString() {
			const s = [];
			for (let i = this._rerrs.length - 1; i > 0; i--) {
				const r = this._rerrs[i];
				/* c8 ignore next */
				s.push(repeat(" ", (this._rerrs.length - i) * 2) + `${r.path != null ? `[${r.path}] ` : ""}${r.has} doesn't match ${r.expected}. ${r.message}`);
			}
			return s.join("\n");
		}
	};
	shapeExtends = (a, b) => {
		if (a === b) return true;
		if (a == null || b == null || a.constructor !== b.constructor) return false;
		if (a[EqualityTraitSymbol]) return equals(a, b);
		if (isArray$1(a)) return every$1(a, (aitem) => some(b, (bitem) => shapeExtends(aitem, bitem)));
		else if (isObject(a)) return every(a, (aitem, akey) => shapeExtends(aitem, b[akey]));
		/* c8 ignore next */
		return false;
	};
	Schema = class {
		/**
		* If true, the more things are added to the shape the more objects this schema will accept (e.g.
		* union). By default, the more objects are added, the the fewer objects this schema will accept.
		* @protected
		*/
		static _dilutes = false;
		/**
		* @param {Schema<any>} other
		*/
		extends(other) {
			let [a, b] = [this.shape, other.shape];
			if (this.constructor._dilutes) [b, a] = [a, b];
			return shapeExtends(a, b);
		}
		/**
		* Overwrite this when necessary. By default, we only check the `shape` property which every shape
		* should have.
		* @param {Schema<any>} other
		*/
		equals(other) {
			return this.constructor === other.constructor && equalityDeep(this.shape, other.shape);
		}
		[schemaSymbol]() {
			return true;
		}
		/**
		* @param {object} other
		*/
		[EqualityTraitSymbol](other) {
			return this.equals(other);
		}
		/**
		* Use `schema.validate(obj)` with a typed parameter that is already of typed to be an instance of
		* Schema. Validate will check the structure of the parameter and return true iff the instance
		* really is an instance of Schema.
		*
		* @param {T} o
		* @return {boolean}
		*/
		validate(o) {
			return this.check(o);
		}
		/* c8 ignore start */
		/**
		* Similar to validate, but this method accepts untyped parameters.
		*
		* @param {any} _o
		* @param {ValidationError} [_err]
		* @return {_o is T}
		*/
		check(_o, _err) {
			methodUnimplemented();
		}
		/* c8 ignore stop */
		/**
		* @type {Schema<T?>}
		*/
		get nullable() {
			return $union(this, $null);
		}
		/**
		* @type {$Optional<Schema<T>>}
		*/
		get optional() {
			return new $Optional(this);
		}
		/**
		* Cast a variable to a specific type. Returns the casted value, or throws an exception otherwise.
		* Use this if you know that the type is of a specific type and you just want to convince the type
		* system.
		*
		* **Do not rely on these error messages!**
		* Performs an assertion check only if not in a production environment.
		*
		* @template OO
		* @param {OO} o
		* @return {Extract<OO, T> extends never ? T : (OO extends Array<never> ? T : Extract<OO,T>)}
		*/
		cast(o) {
			assert(o, this);
			return o;
		}
		/**
		* EXPECTO PATRONUM!! 🪄
		* This function protects against type errors. Though it may not work in the real world.
		*
		* "After all this time?"
		* "Always." - Snape, talking about type safety
		*
		* Ensures that a variable is a a specific type. Returns the value, or throws an exception if the assertion check failed.
		* Use this if you know that the type is of a specific type and you just want to convince the type
		* system.
		*
		* Can be useful when defining lambdas: `s.lambda(s.$number, s.$void).expect((n) => n + 1)`
		*
		* **Do not rely on these error messages!**
		* Performs an assertion check if not in a production environment.
		*
		* @param {T} o
		* @return {o extends T ? T : never}
		*/
		expect(o) {
			assert(o, this);
			return o;
		}
	};
	$ConstructedBy = class extends Schema {
		/**
		* @param {C} c
		* @param {((o:Instance<C>)=>boolean)|null} check
		*/
		constructor(c, check) {
			super();
			this.shape = c;
			this._c = check;
		}
		/**
		* @param {any} o
		* @param {ValidationError} [err]
		* @return {o is C extends ((...args:any[]) => infer T) ? T : (C extends (new (...args:any[]) => any) ? InstanceType<C> : never)} o
		*/
		check(o, err = void 0) {
			const c = o?.constructor === this.shape && (this._c == null || this._c(o));
			/* c8 ignore next */
			!c && err?.extend(null, this.shape.name, o?.constructor.name, o?.constructor !== this.shape ? "Constructor match failed" : "Check failed");
			return c;
		}
	};
	$constructedBy = (c, check = null) => new $ConstructedBy(c, check);
	$constructedBy($ConstructedBy);
	$Custom = class extends Schema {
		/**
		* @param {(o:any) => boolean} check
		*/
		constructor(check) {
			super();
			/**
			* @type {(o:any) => boolean}
			*/
			this.shape = check;
		}
		/**
		* @param {any} o
		* @param {ValidationError} err
		* @return {o is any}
		*/
		check(o, err) {
			const c = this.shape(o);
			/* c8 ignore next */
			!c && err?.extend(null, "custom prop", o?.constructor.name, "failed to check custom prop");
			return c;
		}
	};
	$custom = (check) => new $Custom(check);
	$constructedBy($Custom);
	$Literal = class extends Schema {
		/**
		* @param {Array<T>} literals
		*/
		constructor(literals) {
			super();
			this.shape = literals;
		}
		/**
		*
		* @param {any} o
		* @param {ValidationError} [err]
		* @return {o is T}
		*/
		check(o, err) {
			const c = this.shape.some((a) => a === o);
			/* c8 ignore next */
			!c && err?.extend(null, this.shape.join(" | "), o.toString());
			return c;
		}
	};
	$literal = (...literals) => new $Literal(literals);
	$$literal = $constructedBy($Literal);
	_regexEscape = RegExp.escape || ((str) => str.replace(/[().|&,$^[\]]/g, (s) => "\\" + s));
	_schemaStringTemplateToRegex = (s) => {
		if ($string.check(s)) return [_regexEscape(s)];
		if ($$literal.check(s)) return s.shape.map((v) => v + "");
		if ($$number.check(s)) return ["[+-]?\\d+.?\\d*"];
		if ($$string.check(s)) return [".*"];
		if ($$union.check(s)) return s.shape.map(_schemaStringTemplateToRegex).flat(1);
		/* c8 ignore next 2 */
		unexpectedCase();
	};
	$StringTemplate = class extends Schema {
		/**
		* @param {T} shape
		*/
		constructor(shape) {
			super();
			this.shape = shape;
			this._r = new RegExp("^" + shape.map(_schemaStringTemplateToRegex).map((opts) => `(${opts.join("|")})`).join("") + "$");
		}
		/**
		* @param {any} o
		* @param {ValidationError} [err]
		* @return {o is CastStringTemplateArgsToTemplate<T>}
		*/
		check(o, err) {
			const c = this._r.exec(o) != null;
			/* c8 ignore next */
			!c && err?.extend(null, this._r.toString(), o.toString(), "String doesn't match string template.");
			return c;
		}
	};
	$constructedBy($StringTemplate);
	isOptionalSymbol = Symbol("optional");
	$Optional = class extends Schema {
		/**
		* @param {S} shape
		*/
		constructor(shape) {
			super();
			this.shape = shape;
		}
		/**
		* @param {any} o
		* @param {ValidationError} [err]
		* @return {o is (Unwrap<S>|undefined)}
		*/
		check(o, err) {
			const c = o === void 0 || this.shape.check(o);
			/* c8 ignore next */
			!c && err?.extend(null, "undefined (optional)", "()");
			return c;
		}
		get [isOptionalSymbol]() {
			return true;
		}
	};
	$$optional = $constructedBy($Optional);
	$Never = class extends Schema {
		/**
		* @param {any} _o
		* @param {ValidationError} [err]
		* @return {_o is never}
		*/
		check(_o, err) {
			/* c8 ignore next */
			err?.extend(null, "never", typeof _o);
			return false;
		}
	};
	new $Never();
	$constructedBy($Never);
	$Object = class $Object extends Schema {
		/**
		* @param {S} shape
		* @param {boolean} partial
		*/
		constructor(shape, partial = false) {
			super();
			/**
			* @type {S}
			*/
			this.shape = shape;
			this._isPartial = partial;
		}
		static _dilutes = true;
		/**
		* @type {Schema<Partial<$ObjectToType<S>>>}
		*/
		get partial() {
			return new $Object(this.shape, true);
		}
		/**
		* @param {any} o
		* @param {ValidationError} err
		* @return {o is $ObjectToType<S>}
		*/
		check(o, err) {
			if (o == null) {
				/* c8 ignore next */
				err?.extend(null, "object", "null");
				return false;
			}
			return every(this.shape, (vv, vk) => {
				const c = this._isPartial && !hasProperty(o, vk) || vv.check(o[vk], err);
				!c && err?.extend(vk.toString(), vv.toString(), typeof o[vk], "Object property does not match");
				return c;
			});
		}
	};
	$object = (def) => new $Object(def);
	$$object = $constructedBy($Object);
	$objectAny = $custom((o) => o != null && (o.constructor === Object || o.constructor == null));
	$Record = class extends Schema {
		/**
		* @param {Keys} keys
		* @param {Values} values
		*/
		constructor(keys, values) {
			super();
			this.shape = {
				keys,
				values
			};
		}
		/**
		* @param {any} o
		* @param {ValidationError} err
		* @return {o is { [key in Unwrap<Keys>]: Unwrap<Values> }}
		*/
		check(o, err) {
			return o != null && every(o, (vv, vk) => {
				const ck = this.shape.keys.check(vk, err);
				/* c8 ignore next */
				!ck && err?.extend(vk + "", "Record", typeof o, ck ? "Key doesn't match schema" : "Value doesn't match value");
				return ck && this.shape.values.check(vv, err);
			});
		}
	};
	$record = (keys, values) => new $Record(keys, values);
	$$record = $constructedBy($Record);
	$Tuple = class extends Schema {
		/**
		* @param {S} shape
		*/
		constructor(shape) {
			super();
			this.shape = shape;
		}
		/**
		* @param {any} o
		* @param {ValidationError} err
		* @return {o is { [K in keyof S]: S[K] extends Schema<infer Type> ? Type : never }}
		*/
		check(o, err) {
			return o != null && every(this.shape, (vv, vk) => {
				const c = vv.check(o[vk], err);
				/* c8 ignore next */
				!c && err?.extend(vk.toString(), "Tuple", typeof vv);
				return c;
			});
		}
	};
	$tuple = (...def) => new $Tuple(def);
	$constructedBy($Tuple);
	$Array = class extends Schema {
		/**
		* @param {Array<S>} v
		*/
		constructor(v) {
			super();
			/**
			* @type {Schema<S extends Schema<infer T> ? T : never>}
			*/
			this.shape = v.length === 1 ? v[0] : new $Union(v);
		}
		/**
		* @param {any} o
		* @param {ValidationError} [err]
		* @return {o is Array<S extends Schema<infer T> ? T : never>} o
		*/
		check(o, err) {
			const c = isArray$1(o) && every$1(o, (oi) => this.shape.check(oi));
			/* c8 ignore next */
			!c && err?.extend(null, "Array", "");
			return c;
		}
	};
	$array = (...def) => new $Array(def);
	$$array = $constructedBy($Array);
	$arrayAny = $custom((o) => isArray$1(o));
	$InstanceOf = class extends Schema {
		/**
		* @param {new (...args:any) => T} constructor
		* @param {((o:T) => boolean)|null} check
		*/
		constructor(constructor, check) {
			super();
			this.shape = constructor;
			this._c = check;
		}
		/**
		* @param {any} o
		* @param {ValidationError} err
		* @return {o is T}
		*/
		check(o, err) {
			const c = o instanceof this.shape && (this._c == null || this._c(o));
			/* c8 ignore next */
			!c && err?.extend(null, this.shape.name, o?.constructor.name);
			return c;
		}
	};
	$instanceOf = (c, check = null) => new $InstanceOf(c, check);
	$constructedBy($InstanceOf);
	$$schema = $instanceOf(Schema);
	$Lambda = class extends Schema {
		/**
		* @param {Args} args
		*/
		constructor(args) {
			super();
			this.len = args.length - 1;
			this.args = $tuple(...args.slice(-1));
			this.res = args[this.len];
		}
		/**
		* @param {any} f
		* @param {ValidationError} err
		* @return {f is _LArgsToLambdaDef<Args>}
		*/
		check(f, err) {
			const c = f.constructor === Function && f.length <= this.len;
			/* c8 ignore next */
			!c && err?.extend(null, "function", typeof f);
			return c;
		}
	};
	$$lambda = $constructedBy($Lambda);
	$function = $custom((o) => typeof o === "function");
	$Intersection = class extends Schema {
		/**
		* @param {T} v
		*/
		constructor(v) {
			super();
			/**
			* @type {T}
			*/
			this.shape = v;
		}
		/**
		* @param {any} o
		* @param {ValidationError} [err]
		* @return {o is Intersect<UnwrapArray<T>>}
		*/
		check(o, err) {
			const c = every$1(this.shape, (check) => check.check(o, err));
			/* c8 ignore next */
			!c && err?.extend(null, "Intersectinon", typeof o);
			return c;
		}
	};
	$constructedBy($Intersection, (o) => o.shape.length > 0);
	$Union = class extends Schema {
		static _dilutes = true;
		/**
		* @param {Array<Schema<S>>} v
		*/
		constructor(v) {
			super();
			this.shape = v;
		}
		/**
		* @param {any} o
		* @param {ValidationError} [err]
		* @return {o is S}
		*/
		check(o, err) {
			const c = some(this.shape, (vv) => vv.check(o, err));
			err?.extend(null, "Union", typeof o);
			return c;
		}
	};
	$union = (...schemas) => schemas.findIndex(($s) => $$union.check($s)) >= 0 ? $union(...schemas.map(($s) => $($s)).map(($s) => $$union.check($s) ? $s.shape : [$s]).flat(1)) : schemas.length === 1 ? schemas[0] : new $Union(schemas);
	$$union = $constructedBy($Union);
	_t = () => true;
	$any = $custom(_t);
	$$any = $constructedBy($Custom, (o) => o.shape === _t);
	$bigint = $custom((o) => typeof o === "bigint");
	$$bigint = $custom((o) => o === $bigint);
	$symbol = $custom((o) => typeof o === "symbol");
	$custom((o) => o === $symbol);
	$number = $custom((o) => typeof o === "number");
	$$number = $custom((o) => o === $number);
	$string = $custom((o) => typeof o === "string");
	$$string = $custom((o) => o === $string);
	$boolean = $custom((o) => typeof o === "boolean");
	$$boolean = $custom((o) => o === $boolean);
	$undefined = $literal(void 0);
	$constructedBy($Literal, (o) => o.shape.length === 1 && o.shape[0] === void 0);
	$literal(void 0);
	$null = $literal(null);
	$$null = $constructedBy($Literal, (o) => o.shape.length === 1 && o.shape[0] === null);
	$constructedBy(Uint8Array);
	$constructedBy($ConstructedBy, (o) => o.shape === Uint8Array);
	$primitive = $union($number, $string, $null, $undefined, $bigint, $boolean, $symbol);
	(() => {
		const $jsonArr = $array($any);
		const $jsonRecord = $record($string, $any);
		const $json = $union($number, $string, $null, $boolean, $jsonArr, $jsonRecord);
		$jsonArr.shape = $json;
		$jsonRecord.shape.values = $json;
		return $json;
	})();
	$ = (o) => {
		if ($$schema.check(o)) return o;
		else if ($objectAny.check(o)) {
			/**
			* @type {any}
			*/
			const o2 = {};
			for (const k in o) o2[k] = $(o[k]);
			return $object(o2);
		} else if ($arrayAny.check(o)) return $union(...o.map($));
		else if ($primitive.check(o)) return $literal(o);
		else if ($function.check(o)) return $constructedBy(o);
		/* c8 ignore next */
		unexpectedCase();
	};
	assert = production ? () => {} : (o, schema) => {
		const err = new ValidationError();
		if (!schema.check(o, err)) throw create$3(`Expected value to be of type ${schema.constructor.name}.\n${err.toString()}`);
	};
	PatternMatcher = class {
		/**
		* @param {Schema<State>} [$state]
		*/
		constructor($state) {
			/**
			* @type {Array<Patterns>}
			*/
			this.patterns = [];
			this.$state = $state;
		}
		/**
		* @template P
		* @template R
		* @param {P} pattern
		* @param {(o:NoInfer<Unwrap<ReadSchema<P>>>,s:State)=>R} handler
		* @return {PatternMatcher<State,Patterns|Pattern<Unwrap<ReadSchema<P>>,R>>}
		*/
		if(pattern, handler) {
			this.patterns.push({
				if: $(pattern),
				h: handler
			});
			return this;
		}
		/**
		* @template R
		* @param {(o:any,s:State)=>R} h
		*/
		else(h) {
			return this.if($any, h);
		}
		/**
		* @return {State extends undefined
		*   ? <In extends Unwrap<Patterns['if']>>(o:In,state?:undefined)=>PatternMatchResult<Patterns,In>
		*   : <In extends Unwrap<Patterns['if']>>(o:In,state:State)=>PatternMatchResult<Patterns,In>}
		*/
		done() {
			return (o, s) => {
				for (let i = 0; i < this.patterns.length; i++) {
					const p = this.patterns[i];
					if (p.if.check(o)) return p.h(o, s);
				}
				throw create$3("Unhandled pattern");
			};
		}
	};
	match = (state) => new PatternMatcher(state);
	_random = match($any).if($$number, (_o, gen) => int53(gen, MIN_SAFE_INTEGER, MAX_SAFE_INTEGER)).if($$string, (_o, gen) => word(gen)).if($$boolean, (_o, gen) => bool(gen)).if($$bigint, (_o, gen) => BigInt(int53(gen, MIN_SAFE_INTEGER, MAX_SAFE_INTEGER))).if($$union, (o, gen) => random(gen, oneOf(gen, o.shape))).if($$object, (o, gen) => {
		/**
		* @type {any}
		*/
		const res = {};
		for (const k in o.shape) {
			let prop = o.shape[k];
			if ($$optional.check(prop)) {
				if (bool(gen)) continue;
				prop = prop.shape;
			}
			res[k] = _random(prop, gen);
		}
		return res;
	}).if($$array, (o, gen) => {
		const arr = [];
		const n = int32(gen, 0, 42);
		for (let i = 0; i < n; i++) arr.push(random(gen, o.shape));
		return arr;
	}).if($$literal, (o, gen) => {
		return oneOf(gen, o.shape);
	}).if($$null, (o, gen) => {
		return null;
	}).if($$lambda, (o, gen) => {
		const res = random(gen, o.res);
		return () => res;
	}).if($$any, (o, gen) => random(gen, oneOf(gen, [
		$number,
		$string,
		$null,
		$undefined,
		$bigint,
		$boolean,
		$array($number),
		$record($union("a", "b", "c"), $number)
	]))).if($$record, (o, gen) => {
		/**
		* @type {any}
		*/
		const res = {};
		const keysN = int53(gen, 0, 3);
		for (let i = 0; i < keysN; i++) {
			const key = random(gen, o.shape.keys);
			res[key] = random(gen, o.shape.values);
		}
		return res;
	}).done();
	random = (gen, schema) => _random($(schema), gen);
}));
var doc;
var mapToStyleString;
var ELEMENT_NODE;
var TEXT_NODE;
var DOCUMENT_NODE;
var DOCUMENT_FRAGMENT_NODE;
var init_dom = __esmMin((() => {
	init_map();
	init_schema();
	doc = typeof document !== "undefined" ? document : {};
	$custom((el) => el.nodeType === DOCUMENT_FRAGMENT_NODE);
	typeof DOMParser !== "undefined" && new DOMParser();
	$custom((el) => el.nodeType === ELEMENT_NODE);
	$custom((el) => el.nodeType === TEXT_NODE);
	mapToStyleString = (m) => map(m, (value, key) => `${key}:${value};`).join("");
	ELEMENT_NODE = doc.ELEMENT_NODE;
	TEXT_NODE = doc.TEXT_NODE;
	doc.CDATA_SECTION_NODE;
	doc.COMMENT_NODE;
	DOCUMENT_NODE = doc.DOCUMENT_NODE;
	doc.DOCUMENT_TYPE_NODE;
	DOCUMENT_FRAGMENT_NODE = doc.DOCUMENT_FRAGMENT_NODE;
	$custom((el) => el.nodeType === DOCUMENT_NODE);
}));
/* c8 ignore stop */
var create;
var init_symbol = __esmMin((() => {
	create = Symbol;
}));
var BOLD;
var UNBOLD;
var BLUE;
var GREY;
var GREEN;
var RED;
var PURPLE;
var ORANGE;
var UNCOLOR;
var computeNoColorLoggingArgs;
var init_logging_common = __esmMin((() => {
	init_symbol();
	init_time();
	BOLD = create();
	UNBOLD = create();
	BLUE = create();
	GREY = create();
	GREEN = create();
	RED = create();
	PURPLE = create();
	ORANGE = create();
	UNCOLOR = create();
	computeNoColorLoggingArgs = (args) => {
		if (args.length === 1 && args[0]?.constructor === Function) args = args[0]();
		const strBuilder = [];
		const logArgs = [];
		let i = 0;
		for (; i < args.length; i++) {
			const arg = args[i];
			if (arg === void 0) break;
			else if (arg.constructor === String || arg.constructor === Number) strBuilder.push(arg);
			else if (arg.constructor === Object) break;
		}
		if (i > 0) logArgs.push(strBuilder.join(""));
		for (; i < args.length; i++) {
			const arg = args[i];
			if (!(arg instanceof Symbol)) logArgs.push(arg);
		}
		return logArgs;
	};
	getUnixTime();
}));
var _browserStyleMap;
var computeBrowserLoggingArgs;
var computeLoggingArgs;
var print;
var warn;
var vconsoles;
var init_logging = __esmMin((() => {
	init_environment();
	init_set();
	init_pair();
	init_dom();
	init_map();
	init_logging_common();
	_browserStyleMap = {
		[BOLD]: create$1("font-weight", "bold"),
		[UNBOLD]: create$1("font-weight", "normal"),
		[BLUE]: create$1("color", "blue"),
		[GREEN]: create$1("color", "green"),
		[GREY]: create$1("color", "grey"),
		[RED]: create$1("color", "red"),
		[PURPLE]: create$1("color", "purple"),
		[ORANGE]: create$1("color", "orange"),
		[UNCOLOR]: create$1("color", "black")
	};
	computeBrowserLoggingArgs = (args) => {
		if (args.length === 1 && args[0]?.constructor === Function) args = args[0]();
		const strBuilder = [];
		const styles = [];
		const currentStyle = create$5();
		/**
		* @type {Array<string|Object|number>}
		*/
		let logArgs = [];
		let i = 0;
		for (; i < args.length; i++) {
			const arg = args[i];
			const style = _browserStyleMap[arg];
			if (style !== void 0) currentStyle.set(style.left, style.right);
			else {
				if (arg === void 0) break;
				if (arg.constructor === String || arg.constructor === Number) {
					const style = mapToStyleString(currentStyle);
					if (i > 0 || style.length > 0) {
						strBuilder.push("%c" + arg);
						styles.push(style);
					} else strBuilder.push(arg);
				} else break;
			}
		}
		if (i > 0) {
			logArgs = styles;
			logArgs.unshift(strBuilder.join(""));
		}
		for (; i < args.length; i++) {
			const arg = args[i];
			if (!(arg instanceof Symbol)) logArgs.push(arg);
		}
		return logArgs;
	};
	computeLoggingArgs = supportsColor ? computeBrowserLoggingArgs : computeNoColorLoggingArgs;
	print = (...args) => {
		console.log(...computeLoggingArgs(args));
		/* c8 ignore next */
		vconsoles.forEach((vc) => vc.print(args));
	};
	warn = (...args) => {
		console.warn(...computeLoggingArgs(args));
		args.unshift(ORANGE);
		vconsoles.forEach((vc) => vc.print(args));
	};
	vconsoles = create$4();
}));
var createIterator;
var iteratorFilter;
var iteratorMap;
var init_iterator = __esmMin((() => {
	createIterator = (next) => ({
		[Symbol.iterator]() {
			return this;
		},
		next
	});
	iteratorFilter = (iterator, filter) => createIterator(() => {
		let res;
		do
			res = iterator.next();
		while (!res.done && !filter(res.value));
		return res;
	});
	iteratorMap = (iterator, fmap) => createIterator(() => {
		const { done, value } = iterator.next();
		return {
			done,
			value: done ? void 0 : fmap(value)
		};
	});
}));
var yjs_exports = /* @__PURE__ */ __exportAll({
	AbsolutePosition: () => AbsolutePosition,
	AbstractConnector: () => AbstractConnector,
	AbstractStruct: () => AbstractStruct,
	AbstractType: () => AbstractType,
	Array: () => YArray,
	ContentAny: () => ContentAny,
	ContentBinary: () => ContentBinary,
	ContentDeleted: () => ContentDeleted,
	ContentDoc: () => ContentDoc,
	ContentEmbed: () => ContentEmbed,
	ContentFormat: () => ContentFormat,
	ContentJSON: () => ContentJSON,
	ContentString: () => ContentString,
	ContentType: () => ContentType,
	Doc: () => Doc,
	GC: () => GC,
	ID: () => ID,
	Item: () => Item,
	Map: () => YMap,
	PermanentUserData: () => PermanentUserData,
	RelativePosition: () => RelativePosition,
	Skip: () => Skip,
	Snapshot: () => Snapshot,
	Text: () => YText,
	Transaction: () => Transaction,
	UndoManager: () => UndoManager,
	UpdateDecoderV1: () => UpdateDecoderV1,
	UpdateDecoderV2: () => UpdateDecoderV2,
	UpdateEncoderV1: () => UpdateEncoderV1,
	UpdateEncoderV2: () => UpdateEncoderV2,
	XmlElement: () => YXmlElement,
	XmlFragment: () => YXmlFragment,
	XmlHook: () => YXmlHook,
	XmlText: () => YXmlText,
	YArrayEvent: () => YArrayEvent,
	YEvent: () => YEvent,
	YMapEvent: () => YMapEvent,
	YTextEvent: () => YTextEvent,
	YXmlEvent: () => YXmlEvent,
	applyUpdate: () => applyUpdate,
	applyUpdateV2: () => applyUpdateV2,
	cleanupYTextFormatting: () => cleanupYTextFormatting,
	compareIDs: () => compareIDs,
	compareRelativePositions: () => compareRelativePositions,
	convertUpdateFormatV1ToV2: () => convertUpdateFormatV1ToV2,
	convertUpdateFormatV2ToV1: () => convertUpdateFormatV2ToV1,
	createAbsolutePositionFromRelativePosition: () => createAbsolutePositionFromRelativePosition,
	createDeleteSet: () => createDeleteSet,
	createDeleteSetFromStructStore: () => createDeleteSetFromStructStore,
	createDocFromSnapshot: () => createDocFromSnapshot,
	createID: () => createID,
	createRelativePositionFromJSON: () => createRelativePositionFromJSON,
	createRelativePositionFromTypeIndex: () => createRelativePositionFromTypeIndex,
	createSnapshot: () => createSnapshot,
	decodeRelativePosition: () => decodeRelativePosition,
	decodeSnapshot: () => decodeSnapshot,
	decodeSnapshotV2: () => decodeSnapshotV2,
	decodeStateVector: () => decodeStateVector,
	decodeUpdate: () => decodeUpdate,
	decodeUpdateV2: () => decodeUpdateV2,
	diffUpdate: () => diffUpdate,
	diffUpdateV2: () => diffUpdateV2,
	emptySnapshot: () => emptySnapshot,
	encodeRelativePosition: () => encodeRelativePosition,
	encodeSnapshot: () => encodeSnapshot,
	encodeSnapshotV2: () => encodeSnapshotV2,
	encodeStateAsUpdate: () => encodeStateAsUpdate,
	encodeStateAsUpdateV2: () => encodeStateAsUpdateV2,
	encodeStateVector: () => encodeStateVector,
	encodeStateVectorFromUpdate: () => encodeStateVectorFromUpdate,
	encodeStateVectorFromUpdateV2: () => encodeStateVectorFromUpdateV2,
	equalDeleteSets: () => equalDeleteSets,
	equalSnapshots: () => equalSnapshots,
	findIndexSS: () => findIndexSS,
	findRootTypeKey: () => findRootTypeKey,
	getItem: () => getItem,
	getItemCleanEnd: () => getItemCleanEnd,
	getItemCleanStart: () => getItemCleanStart,
	getState: () => getState,
	getTypeChildren: () => getTypeChildren,
	isDeleted: () => isDeleted,
	isParentOf: () => isParentOf,
	iterateDeletedStructs: () => iterateDeletedStructs,
	logType: () => logType,
	logUpdate: () => logUpdate,
	logUpdateV2: () => logUpdateV2,
	mergeDeleteSets: () => mergeDeleteSets,
	mergeUpdates: () => mergeUpdates,
	mergeUpdatesV2: () => mergeUpdatesV2,
	obfuscateUpdate: () => obfuscateUpdate,
	obfuscateUpdateV2: () => obfuscateUpdateV2,
	parseUpdateMeta: () => parseUpdateMeta,
	parseUpdateMetaV2: () => parseUpdateMetaV2,
	readUpdate: () => readUpdate,
	readUpdateV2: () => readUpdateV2,
	relativePositionToJSON: () => relativePositionToJSON,
	snapshot: () => snapshot,
	snapshotContainsUpdate: () => snapshotContainsUpdate,
	transact: () => transact,
	tryGc: () => tryGc,
	typeListToArraySnapshot: () => typeListToArraySnapshot,
	typeMapGetAllSnapshot: () => typeMapGetAllSnapshot,
	typeMapGetSnapshot: () => typeMapGetSnapshot
});
/**
* @param {UpdateDecoderV1 | UpdateDecoderV2} decoder
*/
function* lazyStructReaderGenerator(decoder) {
	const numOfStateUpdates = readVarUint(decoder.restDecoder);
	for (let i = 0; i < numOfStateUpdates; i++) {
		const numberOfStructs = readVarUint(decoder.restDecoder);
		const client = decoder.readClient();
		let clock = readVarUint(decoder.restDecoder);
		for (let i = 0; i < numberOfStructs; i++) {
			const info = decoder.readInfo();
			if (info === 10) {
				const len = readVarUint(decoder.restDecoder);
				yield new Skip(createID(client, clock), len);
				clock += len;
			} else if ((31 & info) !== 0) {
				const cantCopyParentInfo = (info & 192) === 0;
				const struct = new Item(createID(client, clock), null, (info & 128) === 128 ? decoder.readLeftID() : null, null, (info & 64) === 64 ? decoder.readRightID() : null, cantCopyParentInfo ? decoder.readParentInfo() ? decoder.readString() : decoder.readLeftID() : null, cantCopyParentInfo && (info & 32) === 32 ? decoder.readString() : null, readItemContent(decoder, info));
				yield struct;
				clock += struct.length;
			} else {
				const len = decoder.readLen();
				yield new GC(createID(client, clock), len);
				clock += len;
			}
		}
	}
}
var AbstractConnector;
var DeleteItem;
var DeleteSet;
var iterateDeletedStructs;
var findIndexDS;
var isDeleted;
var sortAndMergeDeleteSet;
var mergeDeleteSets;
var addToDeleteSet;
var createDeleteSet;
var createDeleteSetFromStructStore;
var writeDeleteSet;
var readDeleteSet;
var readAndApplyDeleteSet;
var equalDeleteSets;
var generateNewClientId;
var Doc;
var DSDecoderV1;
var UpdateDecoderV1;
var DSDecoderV2;
var UpdateDecoderV2;
var DSEncoderV1;
var UpdateEncoderV1;
var DSEncoderV2;
var UpdateEncoderV2;
var writeStructs;
var writeClientsStructs;
var readClientsStructRefs;
var integrateStructs;
var writeStructsFromTransaction;
var readUpdateV2;
var readUpdate;
var applyUpdateV2;
var applyUpdate;
var writeStateAsUpdate;
var encodeStateAsUpdateV2;
var encodeStateAsUpdate;
var readStateVector;
var decodeStateVector;
var writeStateVector;
var writeDocumentStateVector;
var encodeStateVectorV2;
var encodeStateVector;
var EventHandler;
var createEventHandler;
var addEventHandlerListener;
var removeEventHandlerListener;
var callEventHandlerListeners;
var ID;
var compareIDs;
var createID;
var writeID;
var readID;
var findRootTypeKey;
var isParentOf;
var logType;
var PermanentUserData;
var RelativePosition;
var relativePositionToJSON;
var createRelativePositionFromJSON;
var AbsolutePosition;
var createAbsolutePosition;
var createRelativePosition;
var createRelativePositionFromTypeIndex;
var writeRelativePosition;
var encodeRelativePosition;
var readRelativePosition;
var decodeRelativePosition;
var getItemWithOffset;
var createAbsolutePositionFromRelativePosition;
var compareRelativePositions;
var Snapshot;
var equalSnapshots;
var encodeSnapshotV2;
var encodeSnapshot;
var decodeSnapshotV2;
var decodeSnapshot;
var createSnapshot;
var emptySnapshot;
var snapshot;
var isVisible;
var splitSnapshotAffectedStructs;
var createDocFromSnapshot;
var snapshotContainsUpdateV2;
var snapshotContainsUpdate;
var StructStore;
var getStateVector;
var getState;
var addStruct;
var findIndexSS;
var find;
var getItem;
var findIndexCleanStart;
var getItemCleanStart;
var getItemCleanEnd;
var replaceStruct;
var iterateStructs;
var Transaction;
var writeUpdateMessageFromTransaction;
var addChangedTypeToTransaction;
var tryToMergeWithLefts;
var tryGcDeleteSet;
var tryMergeDeleteSet;
var tryGc;
var cleanupTransactions;
var transact;
var StackItem;
var clearUndoManagerStackItem;
var popStackItem;
var UndoManager;
var LazyStructReader;
var logUpdate;
var logUpdateV2;
var decodeUpdate;
var decodeUpdateV2;
var LazyStructWriter;
var mergeUpdates;
var encodeStateVectorFromUpdateV2;
var encodeStateVectorFromUpdate;
var parseUpdateMetaV2;
var parseUpdateMeta;
var sliceStruct;
var mergeUpdatesV2;
var diffUpdateV2;
var diffUpdate;
var flushLazyStructWriter;
var writeStructToLazyStructWriter;
var finishLazyStructWriting;
var convertUpdateFormat;
var createObfuscator;
var obfuscateUpdate;
var obfuscateUpdateV2;
var convertUpdateFormatV1ToV2;
var convertUpdateFormatV2ToV1;
var errorComputeChanges;
var YEvent;
var getPathTo;
var warnPrematureAccess;
var maxSearchMarker;
var globalSearchMarkerTimestamp;
var ArraySearchMarker;
var refreshMarkerTimestamp;
var overwriteMarker;
var markPosition;
var findMarker;
var updateMarkerChanges;
var getTypeChildren;
var callTypeObservers;
var AbstractType;
var typeListSlice;
var typeListToArray;
var typeListToArraySnapshot;
var typeListForEach;
var typeListMap;
var typeListCreateIterator;
var typeListGet;
var typeListInsertGenericsAfter;
var lengthExceeded;
var typeListInsertGenerics;
var typeListPushGenerics;
var typeListDelete;
var typeMapDelete;
var typeMapSet;
var typeMapGet;
var typeMapGetAll;
var typeMapHas;
var typeMapGetSnapshot;
var typeMapGetAllSnapshot;
var createMapIterator;
var YArrayEvent;
var YArray;
var readYArray;
var YMapEvent;
var YMap;
var readYMap;
var equalAttrs;
var ItemTextListPosition;
var findNextPosition;
var findPosition;
var insertNegatedAttributes;
var updateCurrentAttributes;
var minimizeAttributeChanges;
var insertAttributes;
var insertText;
var formatText;
var cleanupFormattingGap;
var cleanupContextlessFormattingGap;
var cleanupYTextFormatting;
var cleanupYTextAfterTransaction;
var deleteText;
var YTextEvent;
var YText;
var readYText;
var YXmlTreeWalker;
var YXmlFragment;
var readYXmlFragment;
var YXmlElement;
var readYXmlElement;
var YXmlEvent;
var YXmlHook;
var readYXmlHook;
var YXmlText;
var readYXmlText;
var AbstractStruct;
var structGCRefNumber;
var GC;
var ContentBinary;
var readContentBinary;
var ContentDeleted;
var readContentDeleted;
var createDocFromOpts;
var ContentDoc;
var readContentDoc;
var ContentEmbed;
var readContentEmbed;
var ContentFormat;
var readContentFormat;
var ContentJSON;
var readContentJSON;
var isDevMode;
var ContentAny;
var readContentAny;
var ContentString;
var readContentString;
var typeRefs;
var YArrayRefID;
var YMapRefID;
var YTextRefID;
var YXmlElementRefID;
var YXmlFragmentRefID;
var YXmlHookRefID;
var YXmlTextRefID;
var ContentType;
var readContentType;
var followRedone;
var keepItem;
var splitItem;
var isDeletedByUndoStack;
var redoItem;
var Item;
var readItemContent;
var contentRefs;
var structSkipRefNumber;
var Skip;
var glo;
var importIdentifier;
var init_yjs = __esmMin((() => {
	init_observable();
	init_array();
	init_math();
	init_map();
	init_encoding();
	init_decoding();
	init_random();
	init_promise();
	init_buffer();
	init_error();
	init_binary();
	init_function();
	init_set();
	init_logging();
	init_time();
	init_string();
	init_iterator();
	init_object();
	init_environment();
	AbstractConnector = class extends ObservableV2 {
		/**
		* @param {Doc} ydoc
		* @param {any} awareness
		*/
		constructor(ydoc, awareness) {
			super();
			this.doc = ydoc;
			this.awareness = awareness;
		}
	};
	DeleteItem = class {
		/**
		* @param {number} clock
		* @param {number} len
		*/
		constructor(clock, len) {
			/**
			* @type {number}
			*/
			this.clock = clock;
			/**
			* @type {number}
			*/
			this.len = len;
		}
	};
	DeleteSet = class {
		constructor() {
			/**
			* @type {Map<number,Array<DeleteItem>>}
			*/
			this.clients = /* @__PURE__ */ new Map();
		}
	};
	iterateDeletedStructs = (transaction, ds, f) => ds.clients.forEach((deletes, clientid) => {
		const structs = transaction.doc.store.clients.get(clientid);
		if (structs != null) {
			const lastStruct = structs[structs.length - 1];
			const clockState = lastStruct.id.clock + lastStruct.length;
			for (let i = 0, del = deletes[i]; i < deletes.length && del.clock < clockState; del = deletes[++i]) iterateStructs(transaction, structs, del.clock, del.len, f);
		}
	});
	findIndexDS = (dis, clock) => {
		let left = 0;
		let right = dis.length - 1;
		while (left <= right) {
			const midindex = floor((left + right) / 2);
			const mid = dis[midindex];
			const midclock = mid.clock;
			if (midclock <= clock) {
				if (clock < midclock + mid.len) return midindex;
				left = midindex + 1;
			} else right = midindex - 1;
		}
		return null;
	};
	isDeleted = (ds, id) => {
		const dis = ds.clients.get(id.client);
		return dis !== void 0 && findIndexDS(dis, id.clock) !== null;
	};
	sortAndMergeDeleteSet = (ds) => {
		ds.clients.forEach((dels) => {
			dels.sort((a, b) => a.clock - b.clock);
			let i;
			let j;
			for (i = 1, j = 1; i < dels.length; i++) {
				const left = dels[j - 1];
				const right = dels[i];
				if (left.clock + left.len >= right.clock) dels[j - 1] = new DeleteItem(left.clock, max(left.len, right.clock + right.len - left.clock));
				else {
					if (j < i) dels[j] = right;
					j++;
				}
			}
			dels.length = j;
		});
	};
	mergeDeleteSets = (dss) => {
		const merged = new DeleteSet();
		for (let dssI = 0; dssI < dss.length; dssI++) dss[dssI].clients.forEach((delsLeft, client) => {
			if (!merged.clients.has(client)) {
				/**
				* @type {Array<DeleteItem>}
				*/
				const dels = delsLeft.slice();
				for (let i = dssI + 1; i < dss.length; i++) appendTo(dels, dss[i].clients.get(client) || []);
				merged.clients.set(client, dels);
			}
		});
		sortAndMergeDeleteSet(merged);
		return merged;
	};
	addToDeleteSet = (ds, client, clock, length) => {
		setIfUndefined(ds.clients, client, () => []).push(new DeleteItem(clock, length));
	};
	createDeleteSet = () => new DeleteSet();
	createDeleteSetFromStructStore = (ss) => {
		const ds = createDeleteSet();
		ss.clients.forEach((structs, client) => {
			/**
			* @type {Array<DeleteItem>}
			*/
			const dsitems = [];
			for (let i = 0; i < structs.length; i++) {
				const struct = structs[i];
				if (struct.deleted) {
					const clock = struct.id.clock;
					let len = struct.length;
					if (i + 1 < structs.length) for (let next = structs[i + 1]; i + 1 < structs.length && next.deleted; next = structs[++i + 1]) len += next.length;
					dsitems.push(new DeleteItem(clock, len));
				}
			}
			if (dsitems.length > 0) ds.clients.set(client, dsitems);
		});
		return ds;
	};
	writeDeleteSet = (encoder, ds) => {
		writeVarUint(encoder.restEncoder, ds.clients.size);
		from(ds.clients.entries()).sort((a, b) => b[0] - a[0]).forEach(([client, dsitems]) => {
			encoder.resetDsCurVal();
			writeVarUint(encoder.restEncoder, client);
			const len = dsitems.length;
			writeVarUint(encoder.restEncoder, len);
			for (let i = 0; i < len; i++) {
				const item = dsitems[i];
				encoder.writeDsClock(item.clock);
				encoder.writeDsLen(item.len);
			}
		});
	};
	readDeleteSet = (decoder) => {
		const ds = new DeleteSet();
		const numClients = readVarUint(decoder.restDecoder);
		for (let i = 0; i < numClients; i++) {
			decoder.resetDsCurVal();
			const client = readVarUint(decoder.restDecoder);
			const numberOfDeletes = readVarUint(decoder.restDecoder);
			if (numberOfDeletes > 0) {
				const dsField = setIfUndefined(ds.clients, client, () => []);
				for (let i = 0; i < numberOfDeletes; i++) dsField.push(new DeleteItem(decoder.readDsClock(), decoder.readDsLen()));
			}
		}
		return ds;
	};
	readAndApplyDeleteSet = (decoder, transaction, store) => {
		const unappliedDS = new DeleteSet();
		const numClients = readVarUint(decoder.restDecoder);
		for (let i = 0; i < numClients; i++) {
			decoder.resetDsCurVal();
			const client = readVarUint(decoder.restDecoder);
			const numberOfDeletes = readVarUint(decoder.restDecoder);
			const structs = store.clients.get(client) || [];
			const state = getState(store, client);
			for (let i = 0; i < numberOfDeletes; i++) {
				const clock = decoder.readDsClock();
				const clockEnd = clock + decoder.readDsLen();
				if (clock < state) {
					if (state < clockEnd) addToDeleteSet(unappliedDS, client, state, clockEnd - state);
					let index = findIndexSS(structs, clock);
					/**
					* We can ignore the case of GC and Delete structs, because we are going to skip them
					* @type {Item}
					*/
					let struct = structs[index];
					if (!struct.deleted && struct.id.clock < clock) {
						structs.splice(index + 1, 0, splitItem(transaction, struct, clock - struct.id.clock));
						index++;
					}
					while (index < structs.length) {
						struct = structs[index++];
						if (struct.id.clock < clockEnd) {
							if (!struct.deleted) {
								if (clockEnd < struct.id.clock + struct.length) structs.splice(index, 0, splitItem(transaction, struct, clockEnd - struct.id.clock));
								struct.delete(transaction);
							}
						} else break;
					}
				} else addToDeleteSet(unappliedDS, client, clock, clockEnd - clock);
			}
		}
		if (unappliedDS.clients.size > 0) {
			const ds = new UpdateEncoderV2();
			writeVarUint(ds.restEncoder, 0);
			writeDeleteSet(ds, unappliedDS);
			return ds.toUint8Array();
		}
		return null;
	};
	equalDeleteSets = (ds1, ds2) => {
		if (ds1.clients.size !== ds2.clients.size) return false;
		for (const [client, deleteItems1] of ds1.clients.entries()) {
			const deleteItems2 = ds2.clients.get(client);
			if (deleteItems2 === void 0 || deleteItems1.length !== deleteItems2.length) return false;
			for (let i = 0; i < deleteItems1.length; i++) {
				const di1 = deleteItems1[i];
				const di2 = deleteItems2[i];
				if (di1.clock !== di2.clock || di1.len !== di2.len) return false;
			}
		}
		return true;
	};
	generateNewClientId = uint32;
	Doc = class Doc extends ObservableV2 {
		/**
		* @param {DocOpts} opts configuration
		*/
		constructor({ guid = uuidv4(), collectionid = null, gc = true, gcFilter = () => true, meta = null, autoLoad = false, shouldLoad = true } = {}) {
			super();
			this.gc = gc;
			this.gcFilter = gcFilter;
			this.clientID = generateNewClientId();
			this.guid = guid;
			this.collectionid = collectionid;
			/**
			* @type {Map<string, AbstractType<YEvent<any>>>}
			*/
			this.share = /* @__PURE__ */ new Map();
			this.store = new StructStore();
			/**
			* @type {Transaction | null}
			*/
			this._transaction = null;
			/**
			* @type {Array<Transaction>}
			*/
			this._transactionCleanups = [];
			/**
			* @type {Set<Doc>}
			*/
			this.subdocs = /* @__PURE__ */ new Set();
			/**
			* If this document is a subdocument - a document integrated into another document - then _item is defined.
			* @type {Item?}
			*/
			this._item = null;
			this.shouldLoad = shouldLoad;
			this.autoLoad = autoLoad;
			this.meta = meta;
			/**
			* This is set to true when the persistence provider loaded the document from the database or when the `sync` event fires.
			* Note that not all providers implement this feature. Provider authors are encouraged to fire the `load` event when the doc content is loaded from the database.
			*
			* @type {boolean}
			*/
			this.isLoaded = false;
			/**
			* This is set to true when the connection provider has successfully synced with a backend.
			* Note that when using peer-to-peer providers this event may not provide very useful.
			* Also note that not all providers implement this feature. Provider authors are encouraged to fire
			* the `sync` event when the doc has been synced (with `true` as a parameter) or if connection is
			* lost (with false as a parameter).
			*/
			this.isSynced = false;
			this.isDestroyed = false;
			/**
			* Promise that resolves once the document has been loaded from a persistence provider.
			*/
			this.whenLoaded = create$2((resolve) => {
				this.on("load", () => {
					this.isLoaded = true;
					resolve(this);
				});
			});
			const provideSyncedPromise = () => create$2((resolve) => {
				/**
				* @param {boolean} isSynced
				*/
				const eventHandler = (isSynced) => {
					if (isSynced === void 0 || isSynced === true) {
						this.off("sync", eventHandler);
						resolve();
					}
				};
				this.on("sync", eventHandler);
			});
			this.on("sync", (isSynced) => {
				if (isSynced === false && this.isSynced) this.whenSynced = provideSyncedPromise();
				this.isSynced = isSynced === void 0 || isSynced === true;
				if (this.isSynced && !this.isLoaded) this.emit("load", [this]);
			});
			/**
			* Promise that resolves once the document has been synced with a backend.
			* This promise is recreated when the connection is lost.
			* Note the documentation about the `isSynced` property.
			*/
			this.whenSynced = provideSyncedPromise();
		}
		/**
		* Notify the parent document that you request to load data into this subdocument (if it is a subdocument).
		*
		* `load()` might be used in the future to request any provider to load the most current data.
		*
		* It is safe to call `load()` multiple times.
		*/
		load() {
			const item = this._item;
			if (item !== null && !this.shouldLoad) transact(
				/** @type {any} */
				item.parent.doc,
				(transaction) => {
					transaction.subdocsLoaded.add(this);
				},
				null,
				true
			);
			this.shouldLoad = true;
		}
		getSubdocs() {
			return this.subdocs;
		}
		getSubdocGuids() {
			return new Set(from(this.subdocs).map((doc) => doc.guid));
		}
		/**
		* Changes that happen inside of a transaction are bundled. This means that
		* the observer fires _after_ the transaction is finished and that all changes
		* that happened inside of the transaction are sent as one message to the
		* other peers.
		*
		* @template T
		* @param {function(Transaction):T} f The function that should be executed as a transaction
		* @param {any} [origin] Origin of who started the transaction. Will be stored on transaction.origin
		* @return T
		*
		* @public
		*/
		transact(f, origin = null) {
			return transact(this, f, origin);
		}
		/**
		* Define a shared data type.
		*
		* Multiple calls of `ydoc.get(name, TypeConstructor)` yield the same result
		* and do not overwrite each other. I.e.
		* `ydoc.get(name, Y.Array) === ydoc.get(name, Y.Array)`
		*
		* After this method is called, the type is also available on `ydoc.share.get(name)`.
		*
		* *Best Practices:*
		* Define all types right after the Y.Doc instance is created and store them in a separate object.
		* Also use the typed methods `getText(name)`, `getArray(name)`, ..
		*
		* @template {typeof AbstractType<any>} Type
		* @example
		*   const ydoc = new Y.Doc(..)
		*   const appState = {
		*     document: ydoc.getText('document')
		*     comments: ydoc.getArray('comments')
		*   }
		*
		* @param {string} name
		* @param {Type} TypeConstructor The constructor of the type definition. E.g. Y.Text, Y.Array, Y.Map, ...
		* @return {InstanceType<Type>} The created type. Constructed with TypeConstructor
		*
		* @public
		*/
		get(name, TypeConstructor = AbstractType) {
			const type = setIfUndefined(this.share, name, () => {
				const t = new TypeConstructor();
				t._integrate(this, null);
				return t;
			});
			const Constr = type.constructor;
			if (TypeConstructor !== AbstractType && Constr !== TypeConstructor) if (Constr === AbstractType) {
				const t = new TypeConstructor();
				t._map = type._map;
				type._map.forEach(
					/** @param {Item?} n */
					(n) => {
						for (; n !== null; n = n.left) n.parent = t;
					}
				);
				t._start = type._start;
				for (let n = t._start; n !== null; n = n.right) n.parent = t;
				t._length = type._length;
				this.share.set(name, t);
				t._integrate(this, null);
				return t;
			} else throw new Error(`Type with the name ${name} has already been defined with a different constructor`);
			return type;
		}
		/**
		* @template T
		* @param {string} [name]
		* @return {YArray<T>}
		*
		* @public
		*/
		getArray(name = "") {
			return this.get(name, YArray);
		}
		/**
		* @param {string} [name]
		* @return {YText}
		*
		* @public
		*/
		getText(name = "") {
			return this.get(name, YText);
		}
		/**
		* @template T
		* @param {string} [name]
		* @return {YMap<T>}
		*
		* @public
		*/
		getMap(name = "") {
			return this.get(name, YMap);
		}
		/**
		* @param {string} [name]
		* @return {YXmlElement}
		*
		* @public
		*/
		getXmlElement(name = "") {
			return this.get(name, YXmlElement);
		}
		/**
		* @param {string} [name]
		* @return {YXmlFragment}
		*
		* @public
		*/
		getXmlFragment(name = "") {
			return this.get(name, YXmlFragment);
		}
		/**
		* Converts the entire document into a js object, recursively traversing each yjs type
		* Doesn't log types that have not been defined (using ydoc.getType(..)).
		*
		* @deprecated Do not use this method and rather call toJSON directly on the shared types.
		*
		* @return {Object<string, any>}
		*/
		toJSON() {
			/**
			* @type {Object<string, any>}
			*/
			const doc = {};
			this.share.forEach((value, key) => {
				doc[key] = value.toJSON();
			});
			return doc;
		}
		/**
		* Emit `destroy` event and unregister all event handlers.
		*/
		destroy() {
			this.isDestroyed = true;
			from(this.subdocs).forEach((subdoc) => subdoc.destroy());
			const item = this._item;
			if (item !== null) {
				this._item = null;
				const content = item.content;
				content.doc = new Doc({
					guid: this.guid,
					...content.opts,
					shouldLoad: false
				});
				content.doc._item = item;
				transact(
					/** @type {any} */
					item.parent.doc,
					(transaction) => {
						const doc = content.doc;
						if (!item.deleted) transaction.subdocsAdded.add(doc);
						transaction.subdocsRemoved.add(this);
					},
					null,
					true
				);
			}
			this.emit("destroyed", [true]);
			this.emit("destroy", [this]);
			super.destroy();
		}
	};
	DSDecoderV1 = class {
		/**
		* @param {decoding.Decoder} decoder
		*/
		constructor(decoder) {
			this.restDecoder = decoder;
		}
		resetDsCurVal() {}
		/**
		* @return {number}
		*/
		readDsClock() {
			return readVarUint(this.restDecoder);
		}
		/**
		* @return {number}
		*/
		readDsLen() {
			return readVarUint(this.restDecoder);
		}
	};
	UpdateDecoderV1 = class extends DSDecoderV1 {
		/**
		* @return {ID}
		*/
		readLeftID() {
			return createID(readVarUint(this.restDecoder), readVarUint(this.restDecoder));
		}
		/**
		* @return {ID}
		*/
		readRightID() {
			return createID(readVarUint(this.restDecoder), readVarUint(this.restDecoder));
		}
		/**
		* Read the next client id.
		* Use this in favor of readID whenever possible to reduce the number of objects created.
		*/
		readClient() {
			return readVarUint(this.restDecoder);
		}
		/**
		* @return {number} info An unsigned 8-bit integer
		*/
		readInfo() {
			return readUint8(this.restDecoder);
		}
		/**
		* @return {string}
		*/
		readString() {
			return readVarString(this.restDecoder);
		}
		/**
		* @return {boolean} isKey
		*/
		readParentInfo() {
			return readVarUint(this.restDecoder) === 1;
		}
		/**
		* @return {number} info An unsigned 8-bit integer
		*/
		readTypeRef() {
			return readVarUint(this.restDecoder);
		}
		/**
		* Write len of a struct - well suited for Opt RLE encoder.
		*
		* @return {number} len
		*/
		readLen() {
			return readVarUint(this.restDecoder);
		}
		/**
		* @return {any}
		*/
		readAny() {
			return readAny(this.restDecoder);
		}
		/**
		* @return {Uint8Array}
		*/
		readBuf() {
			return copyUint8Array(readVarUint8Array(this.restDecoder));
		}
		/**
		* Legacy implementation uses JSON parse. We use any-decoding in v2.
		*
		* @return {any}
		*/
		readJSON() {
			return JSON.parse(readVarString(this.restDecoder));
		}
		/**
		* @return {string}
		*/
		readKey() {
			return readVarString(this.restDecoder);
		}
	};
	DSDecoderV2 = class {
		/**
		* @param {decoding.Decoder} decoder
		*/
		constructor(decoder) {
			/**
			* @private
			*/
			this.dsCurrVal = 0;
			this.restDecoder = decoder;
		}
		resetDsCurVal() {
			this.dsCurrVal = 0;
		}
		/**
		* @return {number}
		*/
		readDsClock() {
			this.dsCurrVal += readVarUint(this.restDecoder);
			return this.dsCurrVal;
		}
		/**
		* @return {number}
		*/
		readDsLen() {
			const diff = readVarUint(this.restDecoder) + 1;
			this.dsCurrVal += diff;
			return diff;
		}
	};
	UpdateDecoderV2 = class extends DSDecoderV2 {
		/**
		* @param {decoding.Decoder} decoder
		*/
		constructor(decoder) {
			super(decoder);
			/**
			* List of cached keys. If the keys[id] does not exist, we read a new key
			* from stringEncoder and push it to keys.
			*
			* @type {Array<string>}
			*/
			this.keys = [];
			readVarUint(decoder);
			this.keyClockDecoder = new IntDiffOptRleDecoder(readVarUint8Array(decoder));
			this.clientDecoder = new UintOptRleDecoder(readVarUint8Array(decoder));
			this.leftClockDecoder = new IntDiffOptRleDecoder(readVarUint8Array(decoder));
			this.rightClockDecoder = new IntDiffOptRleDecoder(readVarUint8Array(decoder));
			this.infoDecoder = new RleDecoder(readVarUint8Array(decoder), readUint8);
			this.stringDecoder = new StringDecoder(readVarUint8Array(decoder));
			this.parentInfoDecoder = new RleDecoder(readVarUint8Array(decoder), readUint8);
			this.typeRefDecoder = new UintOptRleDecoder(readVarUint8Array(decoder));
			this.lenDecoder = new UintOptRleDecoder(readVarUint8Array(decoder));
		}
		/**
		* @return {ID}
		*/
		readLeftID() {
			return new ID(this.clientDecoder.read(), this.leftClockDecoder.read());
		}
		/**
		* @return {ID}
		*/
		readRightID() {
			return new ID(this.clientDecoder.read(), this.rightClockDecoder.read());
		}
		/**
		* Read the next client id.
		* Use this in favor of readID whenever possible to reduce the number of objects created.
		*/
		readClient() {
			return this.clientDecoder.read();
		}
		/**
		* @return {number} info An unsigned 8-bit integer
		*/
		readInfo() {
			return this.infoDecoder.read();
		}
		/**
		* @return {string}
		*/
		readString() {
			return this.stringDecoder.read();
		}
		/**
		* @return {boolean}
		*/
		readParentInfo() {
			return this.parentInfoDecoder.read() === 1;
		}
		/**
		* @return {number} An unsigned 8-bit integer
		*/
		readTypeRef() {
			return this.typeRefDecoder.read();
		}
		/**
		* Write len of a struct - well suited for Opt RLE encoder.
		*
		* @return {number}
		*/
		readLen() {
			return this.lenDecoder.read();
		}
		/**
		* @return {any}
		*/
		readAny() {
			return readAny(this.restDecoder);
		}
		/**
		* @return {Uint8Array}
		*/
		readBuf() {
			return readVarUint8Array(this.restDecoder);
		}
		/**
		* This is mainly here for legacy purposes.
		*
		* Initial we incoded objects using JSON. Now we use the much faster lib0/any-encoder. This method mainly exists for legacy purposes for the v1 encoder.
		*
		* @return {any}
		*/
		readJSON() {
			return readAny(this.restDecoder);
		}
		/**
		* @return {string}
		*/
		readKey() {
			const keyClock = this.keyClockDecoder.read();
			if (keyClock < this.keys.length) return this.keys[keyClock];
			else {
				const key = this.stringDecoder.read();
				this.keys.push(key);
				return key;
			}
		}
	};
	DSEncoderV1 = class {
		constructor() {
			this.restEncoder = createEncoder();
		}
		toUint8Array() {
			return toUint8Array(this.restEncoder);
		}
		resetDsCurVal() {}
		/**
		* @param {number} clock
		*/
		writeDsClock(clock) {
			writeVarUint(this.restEncoder, clock);
		}
		/**
		* @param {number} len
		*/
		writeDsLen(len) {
			writeVarUint(this.restEncoder, len);
		}
	};
	UpdateEncoderV1 = class extends DSEncoderV1 {
		/**
		* @param {ID} id
		*/
		writeLeftID(id) {
			writeVarUint(this.restEncoder, id.client);
			writeVarUint(this.restEncoder, id.clock);
		}
		/**
		* @param {ID} id
		*/
		writeRightID(id) {
			writeVarUint(this.restEncoder, id.client);
			writeVarUint(this.restEncoder, id.clock);
		}
		/**
		* Use writeClient and writeClock instead of writeID if possible.
		* @param {number} client
		*/
		writeClient(client) {
			writeVarUint(this.restEncoder, client);
		}
		/**
		* @param {number} info An unsigned 8-bit integer
		*/
		writeInfo(info) {
			writeUint8(this.restEncoder, info);
		}
		/**
		* @param {string} s
		*/
		writeString(s) {
			writeVarString(this.restEncoder, s);
		}
		/**
		* @param {boolean} isYKey
		*/
		writeParentInfo(isYKey) {
			writeVarUint(this.restEncoder, isYKey ? 1 : 0);
		}
		/**
		* @param {number} info An unsigned 8-bit integer
		*/
		writeTypeRef(info) {
			writeVarUint(this.restEncoder, info);
		}
		/**
		* Write len of a struct - well suited for Opt RLE encoder.
		*
		* @param {number} len
		*/
		writeLen(len) {
			writeVarUint(this.restEncoder, len);
		}
		/**
		* @param {any} any
		*/
		writeAny(any) {
			writeAny(this.restEncoder, any);
		}
		/**
		* @param {Uint8Array} buf
		*/
		writeBuf(buf) {
			writeVarUint8Array(this.restEncoder, buf);
		}
		/**
		* @param {any} embed
		*/
		writeJSON(embed) {
			writeVarString(this.restEncoder, JSON.stringify(embed));
		}
		/**
		* @param {string} key
		*/
		writeKey(key) {
			writeVarString(this.restEncoder, key);
		}
	};
	DSEncoderV2 = class {
		constructor() {
			this.restEncoder = createEncoder();
			this.dsCurrVal = 0;
		}
		toUint8Array() {
			return toUint8Array(this.restEncoder);
		}
		resetDsCurVal() {
			this.dsCurrVal = 0;
		}
		/**
		* @param {number} clock
		*/
		writeDsClock(clock) {
			const diff = clock - this.dsCurrVal;
			this.dsCurrVal = clock;
			writeVarUint(this.restEncoder, diff);
		}
		/**
		* @param {number} len
		*/
		writeDsLen(len) {
			if (len === 0) unexpectedCase();
			writeVarUint(this.restEncoder, len - 1);
			this.dsCurrVal += len;
		}
	};
	UpdateEncoderV2 = class extends DSEncoderV2 {
		constructor() {
			super();
			/**
			* @type {Map<string,number>}
			*/
			this.keyMap = /* @__PURE__ */ new Map();
			/**
			* Refers to the next unique key-identifier to me used.
			* See writeKey method for more information.
			*
			* @type {number}
			*/
			this.keyClock = 0;
			this.keyClockEncoder = new IntDiffOptRleEncoder();
			this.clientEncoder = new UintOptRleEncoder();
			this.leftClockEncoder = new IntDiffOptRleEncoder();
			this.rightClockEncoder = new IntDiffOptRleEncoder();
			this.infoEncoder = new RleEncoder(writeUint8);
			this.stringEncoder = new StringEncoder();
			this.parentInfoEncoder = new RleEncoder(writeUint8);
			this.typeRefEncoder = new UintOptRleEncoder();
			this.lenEncoder = new UintOptRleEncoder();
		}
		toUint8Array() {
			const encoder = createEncoder();
			writeVarUint(encoder, 0);
			writeVarUint8Array(encoder, this.keyClockEncoder.toUint8Array());
			writeVarUint8Array(encoder, this.clientEncoder.toUint8Array());
			writeVarUint8Array(encoder, this.leftClockEncoder.toUint8Array());
			writeVarUint8Array(encoder, this.rightClockEncoder.toUint8Array());
			writeVarUint8Array(encoder, toUint8Array(this.infoEncoder));
			writeVarUint8Array(encoder, this.stringEncoder.toUint8Array());
			writeVarUint8Array(encoder, toUint8Array(this.parentInfoEncoder));
			writeVarUint8Array(encoder, this.typeRefEncoder.toUint8Array());
			writeVarUint8Array(encoder, this.lenEncoder.toUint8Array());
			writeUint8Array(encoder, toUint8Array(this.restEncoder));
			return toUint8Array(encoder);
		}
		/**
		* @param {ID} id
		*/
		writeLeftID(id) {
			this.clientEncoder.write(id.client);
			this.leftClockEncoder.write(id.clock);
		}
		/**
		* @param {ID} id
		*/
		writeRightID(id) {
			this.clientEncoder.write(id.client);
			this.rightClockEncoder.write(id.clock);
		}
		/**
		* @param {number} client
		*/
		writeClient(client) {
			this.clientEncoder.write(client);
		}
		/**
		* @param {number} info An unsigned 8-bit integer
		*/
		writeInfo(info) {
			this.infoEncoder.write(info);
		}
		/**
		* @param {string} s
		*/
		writeString(s) {
			this.stringEncoder.write(s);
		}
		/**
		* @param {boolean} isYKey
		*/
		writeParentInfo(isYKey) {
			this.parentInfoEncoder.write(isYKey ? 1 : 0);
		}
		/**
		* @param {number} info An unsigned 8-bit integer
		*/
		writeTypeRef(info) {
			this.typeRefEncoder.write(info);
		}
		/**
		* Write len of a struct - well suited for Opt RLE encoder.
		*
		* @param {number} len
		*/
		writeLen(len) {
			this.lenEncoder.write(len);
		}
		/**
		* @param {any} any
		*/
		writeAny(any) {
			writeAny(this.restEncoder, any);
		}
		/**
		* @param {Uint8Array} buf
		*/
		writeBuf(buf) {
			writeVarUint8Array(this.restEncoder, buf);
		}
		/**
		* This is mainly here for legacy purposes.
		*
		* Initial we incoded objects using JSON. Now we use the much faster lib0/any-encoder. This method mainly exists for legacy purposes for the v1 encoder.
		*
		* @param {any} embed
		*/
		writeJSON(embed) {
			writeAny(this.restEncoder, embed);
		}
		/**
		* Property keys are often reused. For example, in y-prosemirror the key `bold` might
		* occur very often. For a 3d application, the key `position` might occur very often.
		*
		* We cache these keys in a Map and refer to them via a unique number.
		*
		* @param {string} key
		*/
		writeKey(key) {
			const clock = this.keyMap.get(key);
			if (clock === void 0) {
				/**
				* @todo uncomment to introduce this feature finally
				*
				* Background. The ContentFormat object was always encoded using writeKey, but the decoder used to use readString.
				* Furthermore, I forgot to set the keyclock. So everything was working fine.
				*
				* However, this feature here is basically useless as it is not being used (it actually only consumes extra memory).
				*
				* I don't know yet how to reintroduce this feature..
				*
				* Older clients won't be able to read updates when we reintroduce this feature. So this should probably be done using a flag.
				*
				*/
				this.keyClockEncoder.write(this.keyClock++);
				this.stringEncoder.write(key);
			} else this.keyClockEncoder.write(clock);
		}
	};
	writeStructs = (encoder, structs, client, clock) => {
		clock = max(clock, structs[0].id.clock);
		const startNewStructs = findIndexSS(structs, clock);
		writeVarUint(encoder.restEncoder, structs.length - startNewStructs);
		encoder.writeClient(client);
		writeVarUint(encoder.restEncoder, clock);
		const firstStruct = structs[startNewStructs];
		firstStruct.write(encoder, clock - firstStruct.id.clock);
		for (let i = startNewStructs + 1; i < structs.length; i++) structs[i].write(encoder, 0);
	};
	writeClientsStructs = (encoder, store, _sm) => {
		const sm = /* @__PURE__ */ new Map();
		_sm.forEach((clock, client) => {
			if (getState(store, client) > clock) sm.set(client, clock);
		});
		getStateVector(store).forEach((_clock, client) => {
			if (!_sm.has(client)) sm.set(client, 0);
		});
		writeVarUint(encoder.restEncoder, sm.size);
		from(sm.entries()).sort((a, b) => b[0] - a[0]).forEach(([client, clock]) => {
			writeStructs(encoder, store.clients.get(client), client, clock);
		});
	};
	readClientsStructRefs = (decoder, doc) => {
		/**
		* @type {Map<number, { i: number, refs: Array<Item | GC> }>}
		*/
		const clientRefs = create$5();
		const numOfStateUpdates = readVarUint(decoder.restDecoder);
		for (let i = 0; i < numOfStateUpdates; i++) {
			const numberOfStructs = readVarUint(decoder.restDecoder);
			/**
			* @type {Array<GC|Item>}
			*/
			const refs = new Array(numberOfStructs);
			const client = decoder.readClient();
			let clock = readVarUint(decoder.restDecoder);
			clientRefs.set(client, {
				i: 0,
				refs
			});
			for (let i = 0; i < numberOfStructs; i++) {
				const info = decoder.readInfo();
				switch (31 & info) {
					case 0: {
						const len = decoder.readLen();
						refs[i] = new GC(createID(client, clock), len);
						clock += len;
						break;
					}
					case 10: {
						const len = readVarUint(decoder.restDecoder);
						refs[i] = new Skip(createID(client, clock), len);
						clock += len;
						break;
					}
					default: {
						/**
						* The optimized implementation doesn't use any variables because inlining variables is faster.
						* Below a non-optimized version is shown that implements the basic algorithm with
						* a few comments
						*/
						const cantCopyParentInfo = (info & 192) === 0;
						const struct = new Item(createID(client, clock), null, (info & 128) === 128 ? decoder.readLeftID() : null, null, (info & 64) === 64 ? decoder.readRightID() : null, cantCopyParentInfo ? decoder.readParentInfo() ? doc.get(decoder.readString()) : decoder.readLeftID() : null, cantCopyParentInfo && (info & 32) === 32 ? decoder.readString() : null, readItemContent(decoder, info));
						refs[i] = struct;
						clock += struct.length;
					}
				}
			}
		}
		return clientRefs;
	};
	integrateStructs = (transaction, store, clientsStructRefs) => {
		/**
		* @type {Array<Item | GC>}
		*/
		const stack = [];
		let clientsStructRefsIds = from(clientsStructRefs.keys()).sort((a, b) => a - b);
		if (clientsStructRefsIds.length === 0) return null;
		const getNextStructTarget = () => {
			if (clientsStructRefsIds.length === 0) return null;
			let nextStructsTarget = clientsStructRefs.get(clientsStructRefsIds[clientsStructRefsIds.length - 1]);
			while (nextStructsTarget.refs.length === nextStructsTarget.i) {
				clientsStructRefsIds.pop();
				if (clientsStructRefsIds.length > 0) nextStructsTarget = clientsStructRefs.get(clientsStructRefsIds[clientsStructRefsIds.length - 1]);
				else return null;
			}
			return nextStructsTarget;
		};
		let curStructsTarget = getNextStructTarget();
		if (curStructsTarget === null) return null;
		/**
		* @type {StructStore}
		*/
		const restStructs = new StructStore();
		const missingSV = /* @__PURE__ */ new Map();
		/**
		* @param {number} client
		* @param {number} clock
		*/
		const updateMissingSv = (client, clock) => {
			const mclock = missingSV.get(client);
			if (mclock == null || mclock > clock) missingSV.set(client, clock);
		};
		/**
		* @type {GC|Item}
		*/
		let stackHead = curStructsTarget.refs[curStructsTarget.i++];
		const state = /* @__PURE__ */ new Map();
		const addStackToRestSS = () => {
			for (const item of stack) {
				const client = item.id.client;
				const inapplicableItems = clientsStructRefs.get(client);
				if (inapplicableItems) {
					inapplicableItems.i--;
					restStructs.clients.set(client, inapplicableItems.refs.slice(inapplicableItems.i));
					clientsStructRefs.delete(client);
					inapplicableItems.i = 0;
					inapplicableItems.refs = [];
				} else restStructs.clients.set(client, [item]);
				clientsStructRefsIds = clientsStructRefsIds.filter((c) => c !== client);
			}
			stack.length = 0;
		};
		while (true) {
			if (stackHead.constructor !== Skip) {
				const offset = setIfUndefined(state, stackHead.id.client, () => getState(store, stackHead.id.client)) - stackHead.id.clock;
				if (offset < 0) {
					stack.push(stackHead);
					updateMissingSv(stackHead.id.client, stackHead.id.clock - 1);
					addStackToRestSS();
				} else {
					const missing = stackHead.getMissing(transaction, store);
					if (missing !== null) {
						stack.push(stackHead);
						/**
						* @type {{ refs: Array<GC|Item>, i: number }}
						*/
						const structRefs = clientsStructRefs.get(missing) || {
							refs: [],
							i: 0
						};
						if (structRefs.refs.length === structRefs.i) {
							updateMissingSv(missing, getState(store, missing));
							addStackToRestSS();
						} else {
							stackHead = structRefs.refs[structRefs.i++];
							continue;
						}
					} else if (offset === 0 || offset < stackHead.length) {
						stackHead.integrate(transaction, offset);
						state.set(stackHead.id.client, stackHead.id.clock + stackHead.length);
					}
				}
			}
			if (stack.length > 0) stackHead = stack.pop();
			else if (curStructsTarget !== null && curStructsTarget.i < curStructsTarget.refs.length) stackHead = curStructsTarget.refs[curStructsTarget.i++];
			else {
				curStructsTarget = getNextStructTarget();
				if (curStructsTarget === null) break;
				else stackHead = curStructsTarget.refs[curStructsTarget.i++];
			}
		}
		if (restStructs.clients.size > 0) {
			const encoder = new UpdateEncoderV2();
			writeClientsStructs(encoder, restStructs, /* @__PURE__ */ new Map());
			writeVarUint(encoder.restEncoder, 0);
			return {
				missing: missingSV,
				update: encoder.toUint8Array()
			};
		}
		return null;
	};
	writeStructsFromTransaction = (encoder, transaction) => writeClientsStructs(encoder, transaction.doc.store, transaction.beforeState);
	readUpdateV2 = (decoder, ydoc, transactionOrigin, structDecoder = new UpdateDecoderV2(decoder)) => transact(ydoc, (transaction) => {
		transaction.local = false;
		let retry = false;
		const doc = transaction.doc;
		const store = doc.store;
		const restStructs = integrateStructs(transaction, store, readClientsStructRefs(structDecoder, doc));
		const pending = store.pendingStructs;
		if (pending) {
			for (const [client, clock] of pending.missing) if (clock < getState(store, client)) {
				retry = true;
				break;
			}
			if (restStructs) {
				for (const [client, clock] of restStructs.missing) {
					const mclock = pending.missing.get(client);
					if (mclock == null || mclock > clock) pending.missing.set(client, clock);
				}
				pending.update = mergeUpdatesV2([pending.update, restStructs.update]);
			}
		} else store.pendingStructs = restStructs;
		const dsRest = readAndApplyDeleteSet(structDecoder, transaction, store);
		if (store.pendingDs) {
			const pendingDSUpdate = new UpdateDecoderV2(createDecoder(store.pendingDs));
			readVarUint(pendingDSUpdate.restDecoder);
			const dsRest2 = readAndApplyDeleteSet(pendingDSUpdate, transaction, store);
			if (dsRest && dsRest2) store.pendingDs = mergeUpdatesV2([dsRest, dsRest2]);
			else store.pendingDs = dsRest || dsRest2;
		} else store.pendingDs = dsRest;
		if (retry) {
			const update = store.pendingStructs.update;
			store.pendingStructs = null;
			applyUpdateV2(transaction.doc, update);
		}
	}, transactionOrigin, false);
	readUpdate = (decoder, ydoc, transactionOrigin) => readUpdateV2(decoder, ydoc, transactionOrigin, new UpdateDecoderV1(decoder));
	applyUpdateV2 = (ydoc, update, transactionOrigin, YDecoder = UpdateDecoderV2) => {
		const decoder = createDecoder(update);
		readUpdateV2(decoder, ydoc, transactionOrigin, new YDecoder(decoder));
	};
	applyUpdate = (ydoc, update, transactionOrigin) => applyUpdateV2(ydoc, update, transactionOrigin, UpdateDecoderV1);
	writeStateAsUpdate = (encoder, doc, targetStateVector = /* @__PURE__ */ new Map()) => {
		writeClientsStructs(encoder, doc.store, targetStateVector);
		writeDeleteSet(encoder, createDeleteSetFromStructStore(doc.store));
	};
	encodeStateAsUpdateV2 = (doc, encodedTargetStateVector = new Uint8Array([0]), encoder = new UpdateEncoderV2()) => {
		writeStateAsUpdate(encoder, doc, decodeStateVector(encodedTargetStateVector));
		const updates = [encoder.toUint8Array()];
		if (doc.store.pendingDs) updates.push(doc.store.pendingDs);
		if (doc.store.pendingStructs) updates.push(diffUpdateV2(doc.store.pendingStructs.update, encodedTargetStateVector));
		if (updates.length > 1) {
			if (encoder.constructor === UpdateEncoderV1) return mergeUpdates(updates.map((update, i) => i === 0 ? update : convertUpdateFormatV2ToV1(update)));
			else if (encoder.constructor === UpdateEncoderV2) return mergeUpdatesV2(updates);
		}
		return updates[0];
	};
	encodeStateAsUpdate = (doc, encodedTargetStateVector) => encodeStateAsUpdateV2(doc, encodedTargetStateVector, new UpdateEncoderV1());
	readStateVector = (decoder) => {
		const ss = /* @__PURE__ */ new Map();
		const ssLength = readVarUint(decoder.restDecoder);
		for (let i = 0; i < ssLength; i++) {
			const client = readVarUint(decoder.restDecoder);
			const clock = readVarUint(decoder.restDecoder);
			ss.set(client, clock);
		}
		return ss;
	};
	decodeStateVector = (decodedState) => readStateVector(new DSDecoderV1(createDecoder(decodedState)));
	writeStateVector = (encoder, sv) => {
		writeVarUint(encoder.restEncoder, sv.size);
		from(sv.entries()).sort((a, b) => b[0] - a[0]).forEach(([client, clock]) => {
			writeVarUint(encoder.restEncoder, client);
			writeVarUint(encoder.restEncoder, clock);
		});
		return encoder;
	};
	writeDocumentStateVector = (encoder, doc) => writeStateVector(encoder, getStateVector(doc.store));
	encodeStateVectorV2 = (doc, encoder = new DSEncoderV2()) => {
		if (doc instanceof Map) writeStateVector(encoder, doc);
		else writeDocumentStateVector(encoder, doc);
		return encoder.toUint8Array();
	};
	encodeStateVector = (doc) => encodeStateVectorV2(doc, new DSEncoderV1());
	EventHandler = class {
		constructor() {
			/**
			* @type {Array<function(ARG0, ARG1):void>}
			*/
			this.l = [];
		}
	};
	createEventHandler = () => new EventHandler();
	addEventHandlerListener = (eventHandler, f) => eventHandler.l.push(f);
	removeEventHandlerListener = (eventHandler, f) => {
		const l = eventHandler.l;
		const len = l.length;
		eventHandler.l = l.filter((g) => f !== g);
		if (len === eventHandler.l.length) console.error("[yjs] Tried to remove event handler that doesn't exist.");
	};
	callEventHandlerListeners = (eventHandler, arg0, arg1) => callAll(eventHandler.l, [arg0, arg1]);
	ID = class {
		/**
		* @param {number} client client id
		* @param {number} clock unique per client id, continuous number
		*/
		constructor(client, clock) {
			/**
			* Client id
			* @type {number}
			*/
			this.client = client;
			/**
			* unique per client id, continuous number
			* @type {number}
			*/
			this.clock = clock;
		}
	};
	compareIDs = (a, b) => a === b || a !== null && b !== null && a.client === b.client && a.clock === b.clock;
	createID = (client, clock) => new ID(client, clock);
	writeID = (encoder, id) => {
		writeVarUint(encoder, id.client);
		writeVarUint(encoder, id.clock);
	};
	readID = (decoder) => createID(readVarUint(decoder), readVarUint(decoder));
	findRootTypeKey = (type) => {
		for (const [key, value] of type.doc.share.entries()) if (value === type) return key;
		throw unexpectedCase();
	};
	isParentOf = (parent, child) => {
		while (child !== null) {
			if (child.parent === parent) return true;
			child = child.parent._item;
		}
		return false;
	};
	logType = (type) => {
		const res = [];
		let n = type._start;
		while (n) {
			res.push(n);
			n = n.right;
		}
		console.log("Children: ", res);
		console.log("Children content: ", res.filter((m) => !m.deleted).map((m) => m.content));
	};
	PermanentUserData = class {
		/**
		* @param {Doc} doc
		* @param {YMap<any>} [storeType]
		*/
		constructor(doc, storeType = doc.getMap("users")) {
			/**
			* @type {Map<string,DeleteSet>}
			*/
			const dss = /* @__PURE__ */ new Map();
			this.yusers = storeType;
			this.doc = doc;
			/**
			* Maps from clientid to userDescription
			*
			* @type {Map<number,string>}
			*/
			this.clients = /* @__PURE__ */ new Map();
			this.dss = dss;
			/**
			* @param {YMap<any>} user
			* @param {string} userDescription
			*/
			const initUser = (user, userDescription) => {
				/**
				* @type {YArray<Uint8Array>}
				*/
				const ds = user.get("ds");
				const ids = user.get("ids");
				const addClientId = (clientid) => this.clients.set(clientid, userDescription);
				ds.observe(
					/** @param {YArrayEvent<any>} event */
					(event) => {
						event.changes.added.forEach((item) => {
							item.content.getContent().forEach((encodedDs) => {
								if (encodedDs instanceof Uint8Array) this.dss.set(userDescription, mergeDeleteSets([this.dss.get(userDescription) || createDeleteSet(), readDeleteSet(new DSDecoderV1(createDecoder(encodedDs)))]));
							});
						});
					}
				);
				this.dss.set(userDescription, mergeDeleteSets(ds.map((encodedDs) => readDeleteSet(new DSDecoderV1(createDecoder(encodedDs))))));
				ids.observe(
					/** @param {YArrayEvent<any>} event */
					(event) => event.changes.added.forEach((item) => item.content.getContent().forEach(addClientId))
				);
				ids.forEach(addClientId);
			};
			storeType.observe((event) => {
				event.keysChanged.forEach((userDescription) => initUser(storeType.get(userDescription), userDescription));
			});
			storeType.forEach(initUser);
		}
		/**
		* @param {Doc} doc
		* @param {number} clientid
		* @param {string} userDescription
		* @param {Object} conf
		* @param {function(Transaction, DeleteSet):boolean} [conf.filter]
		*/
		setUserMapping(doc, clientid, userDescription, { filter = () => true } = {}) {
			const users = this.yusers;
			let user = users.get(userDescription);
			if (!user) {
				user = new YMap();
				user.set("ids", new YArray());
				user.set("ds", new YArray());
				users.set(userDescription, user);
			}
			user.get("ids").push([clientid]);
			users.observe((_event) => {
				setTimeout(() => {
					const userOverwrite = users.get(userDescription);
					if (userOverwrite !== user) {
						user = userOverwrite;
						this.clients.forEach((_userDescription, clientid) => {
							if (userDescription === _userDescription) user.get("ids").push([clientid]);
						});
						const encoder = new DSEncoderV1();
						const ds = this.dss.get(userDescription);
						if (ds) {
							writeDeleteSet(encoder, ds);
							user.get("ds").push([encoder.toUint8Array()]);
						}
					}
				}, 0);
			});
			doc.on(
				"afterTransaction",
				/** @param {Transaction} transaction */
				(transaction) => {
					setTimeout(() => {
						const yds = user.get("ds");
						const ds = transaction.deleteSet;
						if (transaction.local && ds.clients.size > 0 && filter(transaction, ds)) {
							const encoder = new DSEncoderV1();
							writeDeleteSet(encoder, ds);
							yds.push([encoder.toUint8Array()]);
						}
					});
				}
			);
		}
		/**
		* @param {number} clientid
		* @return {any}
		*/
		getUserByClientId(clientid) {
			return this.clients.get(clientid) || null;
		}
		/**
		* @param {ID} id
		* @return {string | null}
		*/
		getUserByDeletedId(id) {
			for (const [userDescription, ds] of this.dss.entries()) if (isDeleted(ds, id)) return userDescription;
			return null;
		}
	};
	RelativePosition = class {
		/**
		* @param {ID|null} type
		* @param {string|null} tname
		* @param {ID|null} item
		* @param {number} assoc
		*/
		constructor(type, tname, item, assoc = 0) {
			/**
			* @type {ID|null}
			*/
			this.type = type;
			/**
			* @type {string|null}
			*/
			this.tname = tname;
			/**
			* @type {ID | null}
			*/
			this.item = item;
			/**
			* A relative position is associated to a specific character. By default
			* assoc >= 0, the relative position is associated to the character
			* after the meant position.
			* I.e. position 1 in 'ab' is associated to character 'b'.
			*
			* If assoc < 0, then the relative position is associated to the character
			* before the meant position.
			*
			* @type {number}
			*/
			this.assoc = assoc;
		}
	};
	relativePositionToJSON = (rpos) => {
		const json = {};
		if (rpos.type) json.type = rpos.type;
		if (rpos.tname) json.tname = rpos.tname;
		if (rpos.item) json.item = rpos.item;
		if (rpos.assoc != null) json.assoc = rpos.assoc;
		return json;
	};
	createRelativePositionFromJSON = (json) => new RelativePosition(json.type == null ? null : createID(json.type.client, json.type.clock), json.tname ?? null, json.item == null ? null : createID(json.item.client, json.item.clock), json.assoc == null ? 0 : json.assoc);
	AbsolutePosition = class {
		/**
		* @param {AbstractType<any>} type
		* @param {number} index
		* @param {number} [assoc]
		*/
		constructor(type, index, assoc = 0) {
			/**
			* @type {AbstractType<any>}
			*/
			this.type = type;
			/**
			* @type {number}
			*/
			this.index = index;
			this.assoc = assoc;
		}
	};
	createAbsolutePosition = (type, index, assoc = 0) => new AbsolutePosition(type, index, assoc);
	createRelativePosition = (type, item, assoc) => {
		let typeid = null;
		let tname = null;
		if (type._item === null) tname = findRootTypeKey(type);
		else typeid = createID(type._item.id.client, type._item.id.clock);
		return new RelativePosition(typeid, tname, item, assoc);
	};
	createRelativePositionFromTypeIndex = (type, index, assoc = 0) => {
		let t = type._start;
		if (assoc < 0) {
			if (index === 0) return createRelativePosition(type, null, assoc);
			index--;
		}
		while (t !== null) {
			if (!t.deleted && t.countable) {
				if (t.length > index) return createRelativePosition(type, createID(t.id.client, t.id.clock + index), assoc);
				index -= t.length;
			}
			if (t.right === null && assoc < 0) return createRelativePosition(type, t.lastId, assoc);
			t = t.right;
		}
		return createRelativePosition(type, null, assoc);
	};
	writeRelativePosition = (encoder, rpos) => {
		const { type, tname, item, assoc } = rpos;
		if (item !== null) {
			writeVarUint(encoder, 0);
			writeID(encoder, item);
		} else if (tname !== null) {
			writeUint8(encoder, 1);
			writeVarString(encoder, tname);
		} else if (type !== null) {
			writeUint8(encoder, 2);
			writeID(encoder, type);
		} else throw unexpectedCase();
		writeVarInt(encoder, assoc);
		return encoder;
	};
	encodeRelativePosition = (rpos) => {
		const encoder = createEncoder();
		writeRelativePosition(encoder, rpos);
		return toUint8Array(encoder);
	};
	readRelativePosition = (decoder) => {
		let type = null;
		let tname = null;
		let itemID = null;
		switch (readVarUint(decoder)) {
			case 0:
				itemID = readID(decoder);
				break;
			case 1:
				tname = readVarString(decoder);
				break;
			case 2: type = readID(decoder);
		}
		const assoc = hasContent(decoder) ? readVarInt(decoder) : 0;
		return new RelativePosition(type, tname, itemID, assoc);
	};
	decodeRelativePosition = (uint8Array) => readRelativePosition(createDecoder(uint8Array));
	getItemWithOffset = (store, id) => {
		const item = getItem(store, id);
		return {
			item,
			diff: id.clock - item.id.clock
		};
	};
	createAbsolutePositionFromRelativePosition = (rpos, doc, followUndoneDeletions = true) => {
		const store = doc.store;
		const rightID = rpos.item;
		const typeID = rpos.type;
		const tname = rpos.tname;
		const assoc = rpos.assoc;
		let type = null;
		let index = 0;
		if (rightID !== null) {
			if (getState(store, rightID.client) <= rightID.clock) return null;
			const res = followUndoneDeletions ? followRedone(store, rightID) : getItemWithOffset(store, rightID);
			const right = res.item;
			if (!(right instanceof Item)) return null;
			type = right.parent;
			if (type._item === null || !type._item.deleted) {
				index = right.deleted || !right.countable ? 0 : res.diff + (assoc >= 0 ? 0 : 1);
				let n = right.left;
				while (n !== null) {
					if (!n.deleted && n.countable) index += n.length;
					n = n.left;
				}
			}
		} else {
			if (tname !== null) type = doc.get(tname);
			else if (typeID !== null) {
				if (getState(store, typeID.client) <= typeID.clock) return null;
				const { item } = followUndoneDeletions ? followRedone(store, typeID) : { item: getItem(store, typeID) };
				if (item instanceof Item && item.content instanceof ContentType) type = item.content.type;
				else return null;
			} else throw unexpectedCase();
			if (assoc >= 0) index = type._length;
			else index = 0;
		}
		return createAbsolutePosition(type, index, rpos.assoc);
	};
	compareRelativePositions = (a, b) => a === b || a !== null && b !== null && a.tname === b.tname && compareIDs(a.item, b.item) && compareIDs(a.type, b.type) && a.assoc === b.assoc;
	Snapshot = class {
		/**
		* @param {DeleteSet} ds
		* @param {Map<number,number>} sv state map
		*/
		constructor(ds, sv) {
			/**
			* @type {DeleteSet}
			*/
			this.ds = ds;
			/**
			* State Map
			* @type {Map<number,number>}
			*/
			this.sv = sv;
		}
	};
	equalSnapshots = (snap1, snap2) => {
		const ds1 = snap1.ds.clients;
		const ds2 = snap2.ds.clients;
		const sv1 = snap1.sv;
		const sv2 = snap2.sv;
		if (sv1.size !== sv2.size || ds1.size !== ds2.size) return false;
		for (const [key, value] of sv1.entries()) if (sv2.get(key) !== value) return false;
		for (const [client, dsitems1] of ds1.entries()) {
			const dsitems2 = ds2.get(client) || [];
			if (dsitems1.length !== dsitems2.length) return false;
			for (let i = 0; i < dsitems1.length; i++) {
				const dsitem1 = dsitems1[i];
				const dsitem2 = dsitems2[i];
				if (dsitem1.clock !== dsitem2.clock || dsitem1.len !== dsitem2.len) return false;
			}
		}
		return true;
	};
	encodeSnapshotV2 = (snapshot, encoder = new DSEncoderV2()) => {
		writeDeleteSet(encoder, snapshot.ds);
		writeStateVector(encoder, snapshot.sv);
		return encoder.toUint8Array();
	};
	encodeSnapshot = (snapshot) => encodeSnapshotV2(snapshot, new DSEncoderV1());
	decodeSnapshotV2 = (buf, decoder = new DSDecoderV2(createDecoder(buf))) => {
		return new Snapshot(readDeleteSet(decoder), readStateVector(decoder));
	};
	decodeSnapshot = (buf) => decodeSnapshotV2(buf, new DSDecoderV1(createDecoder(buf)));
	createSnapshot = (ds, sm) => new Snapshot(ds, sm);
	emptySnapshot = createSnapshot(createDeleteSet(), /* @__PURE__ */ new Map());
	snapshot = (doc) => createSnapshot(createDeleteSetFromStructStore(doc.store), getStateVector(doc.store));
	isVisible = (item, snapshot) => snapshot === void 0 ? !item.deleted : snapshot.sv.has(item.id.client) && (snapshot.sv.get(item.id.client) || 0) > item.id.clock && !isDeleted(snapshot.ds, item.id);
	splitSnapshotAffectedStructs = (transaction, snapshot) => {
		const meta = setIfUndefined(transaction.meta, splitSnapshotAffectedStructs, create$4);
		const store = transaction.doc.store;
		if (!meta.has(snapshot)) {
			snapshot.sv.forEach((clock, client) => {
				if (clock < getState(store, client)) getItemCleanStart(transaction, createID(client, clock));
			});
			iterateDeletedStructs(transaction, snapshot.ds, (_item) => {});
			meta.add(snapshot);
		}
	};
	createDocFromSnapshot = (originDoc, snapshot, newDoc = new Doc()) => {
		if (originDoc.gc) throw new Error("Garbage-collection must be disabled in `originDoc`!");
		const { sv, ds } = snapshot;
		const encoder = new UpdateEncoderV2();
		originDoc.transact((transaction) => {
			let size = 0;
			sv.forEach((clock) => {
				if (clock > 0) size++;
			});
			writeVarUint(encoder.restEncoder, size);
			for (const [client, clock] of sv) {
				if (clock === 0) continue;
				if (clock < getState(originDoc.store, client)) getItemCleanStart(transaction, createID(client, clock));
				const structs = originDoc.store.clients.get(client) || [];
				const lastStructIndex = findIndexSS(structs, clock - 1);
				writeVarUint(encoder.restEncoder, lastStructIndex + 1);
				encoder.writeClient(client);
				writeVarUint(encoder.restEncoder, 0);
				for (let i = 0; i <= lastStructIndex; i++) structs[i].write(encoder, 0);
			}
			writeDeleteSet(encoder, ds);
		});
		applyUpdateV2(newDoc, encoder.toUint8Array(), "snapshot");
		return newDoc;
	};
	snapshotContainsUpdateV2 = (snapshot, update, YDecoder = UpdateDecoderV2) => {
		const updateDecoder = new YDecoder(createDecoder(update));
		const lazyDecoder = new LazyStructReader(updateDecoder, false);
		for (let curr = lazyDecoder.curr; curr !== null; curr = lazyDecoder.next()) if ((snapshot.sv.get(curr.id.client) || 0) < curr.id.clock + curr.length) return false;
		const mergedDS = mergeDeleteSets([snapshot.ds, readDeleteSet(updateDecoder)]);
		return equalDeleteSets(snapshot.ds, mergedDS);
	};
	snapshotContainsUpdate = (snapshot, update) => snapshotContainsUpdateV2(snapshot, update, UpdateDecoderV1);
	StructStore = class {
		constructor() {
			/**
			* @type {Map<number,Array<GC|Item>>}
			*/
			this.clients = /* @__PURE__ */ new Map();
			/**
			* @type {null | { missing: Map<number, number>, update: Uint8Array }}
			*/
			this.pendingStructs = null;
			/**
			* @type {null | Uint8Array}
			*/
			this.pendingDs = null;
		}
	};
	getStateVector = (store) => {
		const sm = /* @__PURE__ */ new Map();
		store.clients.forEach((structs, client) => {
			const struct = structs[structs.length - 1];
			sm.set(client, struct.id.clock + struct.length);
		});
		return sm;
	};
	getState = (store, client) => {
		const structs = store.clients.get(client);
		if (structs === void 0) return 0;
		const lastStruct = structs[structs.length - 1];
		return lastStruct.id.clock + lastStruct.length;
	};
	addStruct = (store, struct) => {
		let structs = store.clients.get(struct.id.client);
		if (structs === void 0) {
			structs = [];
			store.clients.set(struct.id.client, structs);
		} else {
			const lastStruct = structs[structs.length - 1];
			if (lastStruct.id.clock + lastStruct.length !== struct.id.clock) throw unexpectedCase();
		}
		structs.push(struct);
	};
	findIndexSS = (structs, clock) => {
		let left = 0;
		let right = structs.length - 1;
		let mid = structs[right];
		let midclock = mid.id.clock;
		if (midclock === clock) return right;
		let midindex = floor(clock / (midclock + mid.length - 1) * right);
		while (left <= right) {
			mid = structs[midindex];
			midclock = mid.id.clock;
			if (midclock <= clock) {
				if (clock < midclock + mid.length) return midindex;
				left = midindex + 1;
			} else right = midindex - 1;
			midindex = floor((left + right) / 2);
		}
		throw unexpectedCase();
	};
	find = (store, id) => {
		/**
		* @type {Array<GC|Item>}
		*/
		const structs = store.clients.get(id.client);
		return structs[findIndexSS(structs, id.clock)];
	};
	getItem = find;
	findIndexCleanStart = (transaction, structs, clock) => {
		const index = findIndexSS(structs, clock);
		const struct = structs[index];
		if (struct.id.clock < clock && struct instanceof Item) {
			structs.splice(index + 1, 0, splitItem(transaction, struct, clock - struct.id.clock));
			return index + 1;
		}
		return index;
	};
	getItemCleanStart = (transaction, id) => {
		const structs = transaction.doc.store.clients.get(id.client);
		return structs[findIndexCleanStart(transaction, structs, id.clock)];
	};
	getItemCleanEnd = (transaction, store, id) => {
		/**
		* @type {Array<Item>}
		*/
		const structs = store.clients.get(id.client);
		const index = findIndexSS(structs, id.clock);
		const struct = structs[index];
		if (id.clock !== struct.id.clock + struct.length - 1 && struct.constructor !== GC) structs.splice(index + 1, 0, splitItem(transaction, struct, id.clock - struct.id.clock + 1));
		return struct;
	};
	replaceStruct = (store, struct, newStruct) => {
		const structs = store.clients.get(struct.id.client);
		structs[findIndexSS(structs, struct.id.clock)] = newStruct;
	};
	iterateStructs = (transaction, structs, clockStart, len, f) => {
		if (len === 0) return;
		const clockEnd = clockStart + len;
		let index = findIndexCleanStart(transaction, structs, clockStart);
		let struct;
		do {
			struct = structs[index++];
			if (clockEnd < struct.id.clock + struct.length) findIndexCleanStart(transaction, structs, clockEnd);
			f(struct);
		} while (index < structs.length && structs[index].id.clock < clockEnd);
	};
	Transaction = class {
		/**
		* @param {Doc} doc
		* @param {any} origin
		* @param {boolean} local
		*/
		constructor(doc, origin, local) {
			/**
			* The Yjs instance.
			* @type {Doc}
			*/
			this.doc = doc;
			/**
			* Describes the set of deleted items by ids
			* @type {DeleteSet}
			*/
			this.deleteSet = new DeleteSet();
			/**
			* Holds the state before the transaction started.
			* @type {Map<Number,Number>}
			*/
			this.beforeState = getStateVector(doc.store);
			/**
			* Holds the state after the transaction.
			* @type {Map<Number,Number>}
			*/
			this.afterState = /* @__PURE__ */ new Map();
			/**
			* All types that were directly modified (property added or child
			* inserted/deleted). New types are not included in this Set.
			* Maps from type to parentSubs (`item.parentSub = null` for YArray)
			* @type {Map<AbstractType<YEvent<any>>,Set<String|null>>}
			*/
			this.changed = /* @__PURE__ */ new Map();
			/**
			* Stores the events for the types that observe also child elements.
			* It is mainly used by `observeDeep`.
			* @type {Map<AbstractType<YEvent<any>>,Array<YEvent<any>>>}
			*/
			this.changedParentTypes = /* @__PURE__ */ new Map();
			/**
			* @type {Array<AbstractStruct>}
			*/
			this._mergeStructs = [];
			/**
			* @type {any}
			*/
			this.origin = origin;
			/**
			* Stores meta information on the transaction
			* @type {Map<any,any>}
			*/
			this.meta = /* @__PURE__ */ new Map();
			/**
			* Whether this change originates from this doc.
			* @type {boolean}
			*/
			this.local = local;
			/**
			* @type {Set<Doc>}
			*/
			this.subdocsAdded = /* @__PURE__ */ new Set();
			/**
			* @type {Set<Doc>}
			*/
			this.subdocsRemoved = /* @__PURE__ */ new Set();
			/**
			* @type {Set<Doc>}
			*/
			this.subdocsLoaded = /* @__PURE__ */ new Set();
			/**
			* @type {boolean}
			*/
			this._needFormattingCleanup = false;
		}
	};
	writeUpdateMessageFromTransaction = (encoder, transaction) => {
		if (transaction.deleteSet.clients.size === 0 && !any(transaction.afterState, (clock, client) => transaction.beforeState.get(client) !== clock)) return false;
		sortAndMergeDeleteSet(transaction.deleteSet);
		writeStructsFromTransaction(encoder, transaction);
		writeDeleteSet(encoder, transaction.deleteSet);
		return true;
	};
	addChangedTypeToTransaction = (transaction, type, parentSub) => {
		const item = type._item;
		if (item === null || item.id.clock < (transaction.beforeState.get(item.id.client) || 0) && !item.deleted) setIfUndefined(transaction.changed, type, create$4).add(parentSub);
	};
	tryToMergeWithLefts = (structs, pos) => {
		let right = structs[pos];
		let left = structs[pos - 1];
		let i = pos;
		for (; i > 0; right = left, left = structs[--i - 1]) {
			if (left.deleted === right.deleted && left.constructor === right.constructor) {
				if (left.mergeWith(right)) {
					if (right instanceof Item && right.parentSub !== null && right.parent._map.get(right.parentSub) === right)
 /** @type {AbstractType<any>} */ right.parent._map.set(right.parentSub, left);
					continue;
				}
			}
			break;
		}
		const merged = pos - i;
		if (merged) structs.splice(pos + 1 - merged, merged);
		return merged;
	};
	tryGcDeleteSet = (ds, store, gcFilter) => {
		for (const [client, deleteItems] of ds.clients.entries()) {
			const structs = store.clients.get(client);
			for (let di = deleteItems.length - 1; di >= 0; di--) {
				const deleteItem = deleteItems[di];
				const endDeleteItemClock = deleteItem.clock + deleteItem.len;
				for (let si = findIndexSS(structs, deleteItem.clock), struct = structs[si]; si < structs.length && struct.id.clock < endDeleteItemClock; struct = structs[++si]) {
					const struct = structs[si];
					if (deleteItem.clock + deleteItem.len <= struct.id.clock) break;
					if (struct instanceof Item && struct.deleted && !struct.keep && gcFilter(struct)) struct.gc(store, false);
				}
			}
		}
	};
	tryMergeDeleteSet = (ds, store) => {
		ds.clients.forEach((deleteItems, client) => {
			const structs = store.clients.get(client);
			for (let di = deleteItems.length - 1; di >= 0; di--) {
				const deleteItem = deleteItems[di];
				const mostRightIndexToCheck = min(structs.length - 1, 1 + findIndexSS(structs, deleteItem.clock + deleteItem.len - 1));
				for (let si = mostRightIndexToCheck, struct = structs[si]; si > 0 && struct.id.clock >= deleteItem.clock; struct = structs[si]) si -= 1 + tryToMergeWithLefts(structs, si);
			}
		});
	};
	tryGc = (ds, store, gcFilter) => {
		tryGcDeleteSet(ds, store, gcFilter);
		tryMergeDeleteSet(ds, store);
	};
	cleanupTransactions = (transactionCleanups, i) => {
		if (i < transactionCleanups.length) {
			const transaction = transactionCleanups[i];
			const doc = transaction.doc;
			const store = doc.store;
			const ds = transaction.deleteSet;
			const mergeStructs = transaction._mergeStructs;
			try {
				sortAndMergeDeleteSet(ds);
				transaction.afterState = getStateVector(transaction.doc.store);
				doc.emit("beforeObserverCalls", [transaction, doc]);
				/**
				* An array of event callbacks.
				*
				* Each callback is called even if the other ones throw errors.
				*
				* @type {Array<function():void>}
				*/
				const fs = [];
				transaction.changed.forEach((subs, itemtype) => fs.push(() => {
					if (itemtype._item === null || !itemtype._item.deleted) itemtype._callObserver(transaction, subs);
				}));
				fs.push(() => {
					transaction.changedParentTypes.forEach((events, type) => {
						if (type._dEH.l.length > 0 && (type._item === null || !type._item.deleted)) {
							events = events.filter((event) => event.target._item === null || !event.target._item.deleted);
							events.forEach((event) => {
								event.currentTarget = type;
								event._path = null;
							});
							events.sort((event1, event2) => event1.path.length - event2.path.length);
							fs.push(() => {
								callEventHandlerListeners(type._dEH, events, transaction);
							});
						}
					});
					fs.push(() => doc.emit("afterTransaction", [transaction, doc]));
					fs.push(() => {
						if (transaction._needFormattingCleanup) cleanupYTextAfterTransaction(transaction);
					});
				});
				callAll(fs, []);
			} finally {
				if (doc.gc) tryGcDeleteSet(ds, store, doc.gcFilter);
				tryMergeDeleteSet(ds, store);
				transaction.afterState.forEach((clock, client) => {
					const beforeClock = transaction.beforeState.get(client) || 0;
					if (beforeClock !== clock) {
						const structs = store.clients.get(client);
						const firstChangePos = max(findIndexSS(structs, beforeClock), 1);
						for (let i = structs.length - 1; i >= firstChangePos;) i -= 1 + tryToMergeWithLefts(structs, i);
					}
				});
				for (let i = mergeStructs.length - 1; i >= 0; i--) {
					const { client, clock } = mergeStructs[i].id;
					const structs = store.clients.get(client);
					const replacedStructPos = findIndexSS(structs, clock);
					if (replacedStructPos + 1 < structs.length) {
						if (tryToMergeWithLefts(structs, replacedStructPos + 1) > 1) continue;
					}
					if (replacedStructPos > 0) tryToMergeWithLefts(structs, replacedStructPos);
				}
				if (!transaction.local && transaction.afterState.get(doc.clientID) !== transaction.beforeState.get(doc.clientID)) {
					print(ORANGE, BOLD, "[yjs] ", UNBOLD, RED, "Changed the client-id because another client seems to be using it.");
					doc.clientID = generateNewClientId();
				}
				doc.emit("afterTransactionCleanup", [transaction, doc]);
				if (doc._observers.has("update")) {
					const encoder = new UpdateEncoderV1();
					if (writeUpdateMessageFromTransaction(encoder, transaction)) doc.emit("update", [
						encoder.toUint8Array(),
						transaction.origin,
						doc,
						transaction
					]);
				}
				if (doc._observers.has("updateV2")) {
					const encoder = new UpdateEncoderV2();
					if (writeUpdateMessageFromTransaction(encoder, transaction)) doc.emit("updateV2", [
						encoder.toUint8Array(),
						transaction.origin,
						doc,
						transaction
					]);
				}
				const { subdocsAdded, subdocsLoaded, subdocsRemoved } = transaction;
				if (subdocsAdded.size > 0 || subdocsRemoved.size > 0 || subdocsLoaded.size > 0) {
					subdocsAdded.forEach((subdoc) => {
						subdoc.clientID = doc.clientID;
						if (subdoc.collectionid == null) subdoc.collectionid = doc.collectionid;
						doc.subdocs.add(subdoc);
					});
					subdocsRemoved.forEach((subdoc) => doc.subdocs.delete(subdoc));
					doc.emit("subdocs", [
						{
							loaded: subdocsLoaded,
							added: subdocsAdded,
							removed: subdocsRemoved
						},
						doc,
						transaction
					]);
					subdocsRemoved.forEach((subdoc) => subdoc.destroy());
				}
				if (transactionCleanups.length <= i + 1) {
					doc._transactionCleanups = [];
					doc.emit("afterAllTransactions", [doc, transactionCleanups]);
				} else cleanupTransactions(transactionCleanups, i + 1);
			}
		}
	};
	transact = (doc, f, origin = null, local = true) => {
		const transactionCleanups = doc._transactionCleanups;
		let initialCall = false;
		/**
		* @type {any}
		*/
		let result = null;
		if (doc._transaction === null) {
			initialCall = true;
			doc._transaction = new Transaction(doc, origin, local);
			transactionCleanups.push(doc._transaction);
			if (transactionCleanups.length === 1) doc.emit("beforeAllTransactions", [doc]);
			doc.emit("beforeTransaction", [doc._transaction, doc]);
		}
		try {
			result = f(doc._transaction);
		} finally {
			if (initialCall) {
				const finishCleanup = doc._transaction === transactionCleanups[0];
				doc._transaction = null;
				if (finishCleanup) cleanupTransactions(transactionCleanups, 0);
			}
		}
		return result;
	};
	StackItem = class {
		/**
		* @param {DeleteSet} deletions
		* @param {DeleteSet} insertions
		*/
		constructor(deletions, insertions) {
			this.insertions = insertions;
			this.deletions = deletions;
			/**
			* Use this to save and restore metadata like selection range
			*/
			this.meta = /* @__PURE__ */ new Map();
		}
	};
	clearUndoManagerStackItem = (tr, um, stackItem) => {
		iterateDeletedStructs(tr, stackItem.deletions, (item) => {
			if (item instanceof Item && um.scope.some((type) => type === tr.doc || isParentOf(type, item))) keepItem(item, false);
		});
	};
	popStackItem = (undoManager, stack, eventType) => {
		/**
		* Keep a reference to the transaction so we can fire the event with the changedParentTypes
		* @type {any}
		*/
		let _tr = null;
		const doc = undoManager.doc;
		const scope = undoManager.scope;
		transact(doc, (transaction) => {
			while (stack.length > 0 && undoManager.currStackItem === null) {
				const store = doc.store;
				const stackItem = stack.pop();
				/**
				* @type {Set<Item>}
				*/
				const itemsToRedo = /* @__PURE__ */ new Set();
				/**
				* @type {Array<Item>}
				*/
				const itemsToDelete = [];
				let performedChange = false;
				iterateDeletedStructs(transaction, stackItem.insertions, (struct) => {
					if (struct instanceof Item) {
						if (struct.redone !== null) {
							let { item, diff } = followRedone(store, struct.id);
							if (diff > 0) item = getItemCleanStart(transaction, createID(item.id.client, item.id.clock + diff));
							struct = item;
						}
						if (!struct.deleted && scope.some((type) => type === transaction.doc || isParentOf(type, struct))) itemsToDelete.push(struct);
					}
				});
				iterateDeletedStructs(transaction, stackItem.deletions, (struct) => {
					if (struct instanceof Item && scope.some((type) => type === transaction.doc || isParentOf(type, struct)) && !isDeleted(stackItem.insertions, struct.id)) itemsToRedo.add(struct);
				});
				itemsToRedo.forEach((struct) => {
					performedChange = redoItem(transaction, struct, itemsToRedo, stackItem.insertions, undoManager.ignoreRemoteMapChanges, undoManager) !== null || performedChange;
				});
				for (let i = itemsToDelete.length - 1; i >= 0; i--) {
					const item = itemsToDelete[i];
					if (undoManager.deleteFilter(item)) {
						item.delete(transaction);
						performedChange = true;
					}
				}
				undoManager.currStackItem = performedChange ? stackItem : null;
			}
			transaction.changed.forEach((subProps, type) => {
				if (subProps.has(null) && type._searchMarker) type._searchMarker.length = 0;
			});
			_tr = transaction;
		}, undoManager);
		const res = undoManager.currStackItem;
		if (res != null) {
			const changedParentTypes = _tr.changedParentTypes;
			undoManager.emit("stack-item-popped", [{
				stackItem: res,
				type: eventType,
				changedParentTypes,
				origin: undoManager
			}, undoManager]);
			undoManager.currStackItem = null;
		}
		return res;
	};
	UndoManager = class extends ObservableV2 {
		/**
		* @param {Doc|AbstractType<any>|Array<AbstractType<any>>} typeScope Limits the scope of the UndoManager. If this is set to a ydoc instance, all changes on that ydoc will be undone. If set to a specific type, only changes on that type or its children will be undone. Also accepts an array of types.
		* @param {UndoManagerOptions} options
		*/
		constructor(typeScope, { captureTimeout = 500, captureTransaction = (_tr) => true, deleteFilter = () => true, trackedOrigins = new Set([null]), ignoreRemoteMapChanges = false, doc = isArray$1(typeScope) ? typeScope[0].doc : typeScope instanceof Doc ? typeScope : typeScope.doc } = {}) {
			super();
			/**
			* @type {Array<AbstractType<any> | Doc>}
			*/
			this.scope = [];
			this.doc = doc;
			this.addToScope(typeScope);
			this.deleteFilter = deleteFilter;
			trackedOrigins.add(this);
			this.trackedOrigins = trackedOrigins;
			this.captureTransaction = captureTransaction;
			/**
			* @type {Array<StackItem>}
			*/
			this.undoStack = [];
			/**
			* @type {Array<StackItem>}
			*/
			this.redoStack = [];
			/**
			* Whether the client is currently undoing (calling UndoManager.undo)
			*
			* @type {boolean}
			*/
			this.undoing = false;
			this.redoing = false;
			/**
			* The currently popped stack item if UndoManager.undoing or UndoManager.redoing
			*
			* @type {StackItem|null}
			*/
			this.currStackItem = null;
			this.lastChange = 0;
			this.ignoreRemoteMapChanges = ignoreRemoteMapChanges;
			this.captureTimeout = captureTimeout;
			/**
			* @param {Transaction} transaction
			*/
			this.afterTransactionHandler = (transaction) => {
				if (!this.captureTransaction(transaction) || !this.scope.some((type) => transaction.changedParentTypes.has(type) || type === this.doc) || !this.trackedOrigins.has(transaction.origin) && (!transaction.origin || !this.trackedOrigins.has(transaction.origin.constructor))) return;
				const undoing = this.undoing;
				const redoing = this.redoing;
				const stack = undoing ? this.redoStack : this.undoStack;
				if (undoing) this.stopCapturing();
				else if (!redoing) this.clear(false, true);
				const insertions = new DeleteSet();
				transaction.afterState.forEach((endClock, client) => {
					const startClock = transaction.beforeState.get(client) || 0;
					const len = endClock - startClock;
					if (len > 0) addToDeleteSet(insertions, client, startClock, len);
				});
				const now = getUnixTime();
				let didAdd = false;
				if (this.lastChange > 0 && now - this.lastChange < this.captureTimeout && stack.length > 0 && !undoing && !redoing) {
					const lastOp = stack[stack.length - 1];
					lastOp.deletions = mergeDeleteSets([lastOp.deletions, transaction.deleteSet]);
					lastOp.insertions = mergeDeleteSets([lastOp.insertions, insertions]);
				} else {
					stack.push(new StackItem(transaction.deleteSet, insertions));
					didAdd = true;
				}
				if (!undoing && !redoing) this.lastChange = now;
				iterateDeletedStructs(
					transaction,
					transaction.deleteSet,
					/** @param {Item|GC} item */
					(item) => {
						if (item instanceof Item && this.scope.some((type) => type === transaction.doc || isParentOf(type, item))) keepItem(item, true);
					}
				);
				/**
				* @type {[StackItemEvent, UndoManager]}
				*/
				const changeEvent = [{
					stackItem: stack[stack.length - 1],
					origin: transaction.origin,
					type: undoing ? "redo" : "undo",
					changedParentTypes: transaction.changedParentTypes
				}, this];
				if (didAdd) this.emit("stack-item-added", changeEvent);
				else this.emit("stack-item-updated", changeEvent);
			};
			this.doc.on("afterTransaction", this.afterTransactionHandler);
			this.doc.on("destroy", () => {
				this.destroy();
			});
		}
		/**
		* Extend the scope.
		*
		* @param {Array<AbstractType<any> | Doc> | AbstractType<any> | Doc} ytypes
		*/
		addToScope(ytypes) {
			const tmpSet = new Set(this.scope);
			ytypes = isArray$1(ytypes) ? ytypes : [ytypes];
			ytypes.forEach((ytype) => {
				if (!tmpSet.has(ytype)) {
					tmpSet.add(ytype);
					if (ytype instanceof AbstractType ? ytype.doc !== this.doc : ytype !== this.doc) warn("[yjs#509] Not same Y.Doc");
					this.scope.push(ytype);
				}
			});
		}
		/**
		* @param {any} origin
		*/
		addTrackedOrigin(origin) {
			this.trackedOrigins.add(origin);
		}
		/**
		* @param {any} origin
		*/
		removeTrackedOrigin(origin) {
			this.trackedOrigins.delete(origin);
		}
		clear(clearUndoStack = true, clearRedoStack = true) {
			if (clearUndoStack && this.canUndo() || clearRedoStack && this.canRedo()) this.doc.transact((tr) => {
				if (clearUndoStack) {
					this.undoStack.forEach((item) => clearUndoManagerStackItem(tr, this, item));
					this.undoStack = [];
				}
				if (clearRedoStack) {
					this.redoStack.forEach((item) => clearUndoManagerStackItem(tr, this, item));
					this.redoStack = [];
				}
				this.emit("stack-cleared", [{
					undoStackCleared: clearUndoStack,
					redoStackCleared: clearRedoStack
				}]);
			});
		}
		/**
		* UndoManager merges Undo-StackItem if they are created within time-gap
		* smaller than `options.captureTimeout`. Call `um.stopCapturing()` so that the next
		* StackItem won't be merged.
		*
		*
		* @example
		*     // without stopCapturing
		*     ytext.insert(0, 'a')
		*     ytext.insert(1, 'b')
		*     um.undo()
		*     ytext.toString() // => '' (note that 'ab' was removed)
		*     // with stopCapturing
		*     ytext.insert(0, 'a')
		*     um.stopCapturing()
		*     ytext.insert(0, 'b')
		*     um.undo()
		*     ytext.toString() // => 'a' (note that only 'b' was removed)
		*
		*/
		stopCapturing() {
			this.lastChange = 0;
		}
		/**
		* Undo last changes on type.
		*
		* @return {StackItem?} Returns StackItem if a change was applied
		*/
		undo() {
			this.undoing = true;
			let res;
			try {
				res = popStackItem(this, this.undoStack, "undo");
			} finally {
				this.undoing = false;
			}
			return res;
		}
		/**
		* Redo last undo operation.
		*
		* @return {StackItem?} Returns StackItem if a change was applied
		*/
		redo() {
			this.redoing = true;
			let res;
			try {
				res = popStackItem(this, this.redoStack, "redo");
			} finally {
				this.redoing = false;
			}
			return res;
		}
		/**
		* Are undo steps available?
		*
		* @return {boolean} `true` if undo is possible
		*/
		canUndo() {
			return this.undoStack.length > 0;
		}
		/**
		* Are redo steps available?
		*
		* @return {boolean} `true` if redo is possible
		*/
		canRedo() {
			return this.redoStack.length > 0;
		}
		destroy() {
			this.trackedOrigins.delete(this);
			this.doc.off("afterTransaction", this.afterTransactionHandler);
			super.destroy();
		}
	};
	LazyStructReader = class {
		/**
		* @param {UpdateDecoderV1 | UpdateDecoderV2} decoder
		* @param {boolean} filterSkips
		*/
		constructor(decoder, filterSkips) {
			this.gen = lazyStructReaderGenerator(decoder);
			/**
			* @type {null | Item | Skip | GC}
			*/
			this.curr = null;
			this.done = false;
			this.filterSkips = filterSkips;
			this.next();
		}
		/**
		* @return {Item | GC | Skip |null}
		*/
		next() {
			do
				this.curr = this.gen.next().value || null;
			while (this.filterSkips && this.curr !== null && this.curr.constructor === Skip);
			return this.curr;
		}
	};
	logUpdate = (update) => logUpdateV2(update, UpdateDecoderV1);
	logUpdateV2 = (update, YDecoder = UpdateDecoderV2) => {
		const structs = [];
		const updateDecoder = new YDecoder(createDecoder(update));
		const lazyDecoder = new LazyStructReader(updateDecoder, false);
		for (let curr = lazyDecoder.curr; curr !== null; curr = lazyDecoder.next()) structs.push(curr);
		print("Structs: ", structs);
		const ds = readDeleteSet(updateDecoder);
		print("DeleteSet: ", ds);
	};
	decodeUpdate = (update) => decodeUpdateV2(update, UpdateDecoderV1);
	decodeUpdateV2 = (update, YDecoder = UpdateDecoderV2) => {
		const structs = [];
		const updateDecoder = new YDecoder(createDecoder(update));
		const lazyDecoder = new LazyStructReader(updateDecoder, false);
		for (let curr = lazyDecoder.curr; curr !== null; curr = lazyDecoder.next()) structs.push(curr);
		return {
			structs,
			ds: readDeleteSet(updateDecoder)
		};
	};
	LazyStructWriter = class {
		/**
		* @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
		*/
		constructor(encoder) {
			this.currClient = 0;
			this.startClock = 0;
			this.written = 0;
			this.encoder = encoder;
			/**
			* We want to write operations lazily, but also we need to know beforehand how many operations we want to write for each client.
			*
			* This kind of meta-information (#clients, #structs-per-client-written) is written to the restEncoder.
			*
			* We fragment the restEncoder and store a slice of it per-client until we know how many clients there are.
			* When we flush (toUint8Array) we write the restEncoder using the fragments and the meta-information.
			*
			* @type {Array<{ written: number, restEncoder: Uint8Array }>}
			*/
			this.clientStructs = [];
		}
	};
	mergeUpdates = (updates) => mergeUpdatesV2(updates, UpdateDecoderV1, UpdateEncoderV1);
	encodeStateVectorFromUpdateV2 = (update, YEncoder = DSEncoderV2, YDecoder = UpdateDecoderV2) => {
		const encoder = new YEncoder();
		const updateDecoder = new LazyStructReader(new YDecoder(createDecoder(update)), false);
		let curr = updateDecoder.curr;
		if (curr !== null) {
			let size = 0;
			let currClient = curr.id.client;
			let stopCounting = curr.id.clock !== 0;
			let currClock = stopCounting ? 0 : curr.id.clock + curr.length;
			for (; curr !== null; curr = updateDecoder.next()) {
				if (currClient !== curr.id.client) {
					if (currClock !== 0) {
						size++;
						writeVarUint(encoder.restEncoder, currClient);
						writeVarUint(encoder.restEncoder, currClock);
					}
					currClient = curr.id.client;
					currClock = 0;
					stopCounting = curr.id.clock !== 0;
				}
				if (curr.constructor === Skip) stopCounting = true;
				if (!stopCounting) currClock = curr.id.clock + curr.length;
			}
			if (currClock !== 0) {
				size++;
				writeVarUint(encoder.restEncoder, currClient);
				writeVarUint(encoder.restEncoder, currClock);
			}
			const enc = createEncoder();
			writeVarUint(enc, size);
			writeBinaryEncoder(enc, encoder.restEncoder);
			encoder.restEncoder = enc;
			return encoder.toUint8Array();
		} else {
			writeVarUint(encoder.restEncoder, 0);
			return encoder.toUint8Array();
		}
	};
	encodeStateVectorFromUpdate = (update) => encodeStateVectorFromUpdateV2(update, DSEncoderV1, UpdateDecoderV1);
	parseUpdateMetaV2 = (update, YDecoder = UpdateDecoderV2) => {
		/**
		* @type {Map<number, number>}
		*/
		const from = /* @__PURE__ */ new Map();
		/**
		* @type {Map<number, number>}
		*/
		const to = /* @__PURE__ */ new Map();
		const updateDecoder = new LazyStructReader(new YDecoder(createDecoder(update)), false);
		let curr = updateDecoder.curr;
		if (curr !== null) {
			let currClient = curr.id.client;
			let currClock = curr.id.clock;
			from.set(currClient, currClock);
			for (; curr !== null; curr = updateDecoder.next()) {
				if (currClient !== curr.id.client) {
					to.set(currClient, currClock);
					from.set(curr.id.client, curr.id.clock);
					currClient = curr.id.client;
				}
				currClock = curr.id.clock + curr.length;
			}
			to.set(currClient, currClock);
		}
		return {
			from,
			to
		};
	};
	parseUpdateMeta = (update) => parseUpdateMetaV2(update, UpdateDecoderV1);
	sliceStruct = (left, diff) => {
		if (left.constructor === GC) {
			const { client, clock } = left.id;
			return new GC(createID(client, clock + diff), left.length - diff);
		} else if (left.constructor === Skip) {
			const { client, clock } = left.id;
			return new Skip(createID(client, clock + diff), left.length - diff);
		} else {
			const leftItem = left;
			const { client, clock } = leftItem.id;
			return new Item(createID(client, clock + diff), null, createID(client, clock + diff - 1), null, leftItem.rightOrigin, leftItem.parent, leftItem.parentSub, leftItem.content.splice(diff));
		}
	};
	mergeUpdatesV2 = (updates, YDecoder = UpdateDecoderV2, YEncoder = UpdateEncoderV2) => {
		if (updates.length === 1) return updates[0];
		const updateDecoders = updates.map((update) => new YDecoder(createDecoder(update)));
		let lazyStructDecoders = updateDecoders.map((decoder) => new LazyStructReader(decoder, true));
		/**
		* @todo we don't need offset because we always slice before
		* @type {null | { struct: Item | GC | Skip, offset: number }}
		*/
		let currWrite = null;
		const updateEncoder = new YEncoder();
		const lazyStructEncoder = new LazyStructWriter(updateEncoder);
		while (true) {
			lazyStructDecoders = lazyStructDecoders.filter((dec) => dec.curr !== null);
			lazyStructDecoders.sort(
				/** @type {function(any,any):number} */
				(dec1, dec2) => {
					if (dec1.curr.id.client === dec2.curr.id.client) {
						const clockDiff = dec1.curr.id.clock - dec2.curr.id.clock;
						if (clockDiff === 0) return dec1.curr.constructor === dec2.curr.constructor ? 0 : dec1.curr.constructor === Skip ? 1 : -1;
						else return clockDiff;
					} else return dec2.curr.id.client - dec1.curr.id.client;
				}
			);
			if (lazyStructDecoders.length === 0) break;
			const currDecoder = lazyStructDecoders[0];
			const firstClient = currDecoder.curr.id.client;
			if (currWrite !== null) {
				let curr = currDecoder.curr;
				let iterated = false;
				while (curr !== null && curr.id.clock + curr.length <= currWrite.struct.id.clock + currWrite.struct.length && curr.id.client >= currWrite.struct.id.client) {
					curr = currDecoder.next();
					iterated = true;
				}
				if (curr === null || curr.id.client !== firstClient || iterated && curr.id.clock > currWrite.struct.id.clock + currWrite.struct.length) continue;
				if (firstClient !== currWrite.struct.id.client) {
					writeStructToLazyStructWriter(lazyStructEncoder, currWrite.struct, currWrite.offset);
					currWrite = {
						struct: curr,
						offset: 0
					};
					currDecoder.next();
				} else if (currWrite.struct.id.clock + currWrite.struct.length < curr.id.clock) if (currWrite.struct.constructor === Skip) currWrite.struct.length = curr.id.clock + curr.length - currWrite.struct.id.clock;
				else {
					writeStructToLazyStructWriter(lazyStructEncoder, currWrite.struct, currWrite.offset);
					const diff = curr.id.clock - currWrite.struct.id.clock - currWrite.struct.length;
					currWrite = {
						struct: new Skip(createID(firstClient, currWrite.struct.id.clock + currWrite.struct.length), diff),
						offset: 0
					};
				}
				else {
					const diff = currWrite.struct.id.clock + currWrite.struct.length - curr.id.clock;
					if (diff > 0) if (currWrite.struct.constructor === Skip) currWrite.struct.length -= diff;
					else curr = sliceStruct(curr, diff);
					if (!currWrite.struct.mergeWith(curr)) {
						writeStructToLazyStructWriter(lazyStructEncoder, currWrite.struct, currWrite.offset);
						currWrite = {
							struct: curr,
							offset: 0
						};
						currDecoder.next();
					}
				}
			} else {
				currWrite = {
					struct: currDecoder.curr,
					offset: 0
				};
				currDecoder.next();
			}
			for (let next = currDecoder.curr; next !== null && next.id.client === firstClient && next.id.clock === currWrite.struct.id.clock + currWrite.struct.length && next.constructor !== Skip; next = currDecoder.next()) {
				writeStructToLazyStructWriter(lazyStructEncoder, currWrite.struct, currWrite.offset);
				currWrite = {
					struct: next,
					offset: 0
				};
			}
		}
		if (currWrite !== null) {
			writeStructToLazyStructWriter(lazyStructEncoder, currWrite.struct, currWrite.offset);
			currWrite = null;
		}
		finishLazyStructWriting(lazyStructEncoder);
		writeDeleteSet(updateEncoder, mergeDeleteSets(updateDecoders.map((decoder) => readDeleteSet(decoder))));
		return updateEncoder.toUint8Array();
	};
	diffUpdateV2 = (update, sv, YDecoder = UpdateDecoderV2, YEncoder = UpdateEncoderV2) => {
		const state = decodeStateVector(sv);
		const encoder = new YEncoder();
		const lazyStructWriter = new LazyStructWriter(encoder);
		const decoder = new YDecoder(createDecoder(update));
		const reader = new LazyStructReader(decoder, false);
		while (reader.curr) {
			const curr = reader.curr;
			const currClient = curr.id.client;
			const svClock = state.get(currClient) || 0;
			if (reader.curr.constructor === Skip) {
				reader.next();
				continue;
			}
			if (curr.id.clock + curr.length > svClock) {
				writeStructToLazyStructWriter(lazyStructWriter, curr, max(svClock - curr.id.clock, 0));
				reader.next();
				while (reader.curr && reader.curr.id.client === currClient) {
					writeStructToLazyStructWriter(lazyStructWriter, reader.curr, 0);
					reader.next();
				}
			} else while (reader.curr && reader.curr.id.client === currClient && reader.curr.id.clock + reader.curr.length <= svClock) reader.next();
		}
		finishLazyStructWriting(lazyStructWriter);
		writeDeleteSet(encoder, readDeleteSet(decoder));
		return encoder.toUint8Array();
	};
	diffUpdate = (update, sv) => diffUpdateV2(update, sv, UpdateDecoderV1, UpdateEncoderV1);
	flushLazyStructWriter = (lazyWriter) => {
		if (lazyWriter.written > 0) {
			lazyWriter.clientStructs.push({
				written: lazyWriter.written,
				restEncoder: toUint8Array(lazyWriter.encoder.restEncoder)
			});
			lazyWriter.encoder.restEncoder = createEncoder();
			lazyWriter.written = 0;
		}
	};
	writeStructToLazyStructWriter = (lazyWriter, struct, offset) => {
		if (lazyWriter.written > 0 && lazyWriter.currClient !== struct.id.client) flushLazyStructWriter(lazyWriter);
		if (lazyWriter.written === 0) {
			lazyWriter.currClient = struct.id.client;
			lazyWriter.encoder.writeClient(struct.id.client);
			writeVarUint(lazyWriter.encoder.restEncoder, struct.id.clock + offset);
		}
		struct.write(lazyWriter.encoder, offset);
		lazyWriter.written++;
	};
	finishLazyStructWriting = (lazyWriter) => {
		flushLazyStructWriter(lazyWriter);
		const restEncoder = lazyWriter.encoder.restEncoder;
		/**
		* Now we put all the fragments together.
		* This works similarly to `writeClientsStructs`
		*/
		writeVarUint(restEncoder, lazyWriter.clientStructs.length);
		for (let i = 0; i < lazyWriter.clientStructs.length; i++) {
			const partStructs = lazyWriter.clientStructs[i];
			/**
			* Works similarly to `writeStructs`
			*/
			writeVarUint(restEncoder, partStructs.written);
			writeUint8Array(restEncoder, partStructs.restEncoder);
		}
	};
	convertUpdateFormat = (update, blockTransformer, YDecoder, YEncoder) => {
		const updateDecoder = new YDecoder(createDecoder(update));
		const lazyDecoder = new LazyStructReader(updateDecoder, false);
		const updateEncoder = new YEncoder();
		const lazyWriter = new LazyStructWriter(updateEncoder);
		for (let curr = lazyDecoder.curr; curr !== null; curr = lazyDecoder.next()) writeStructToLazyStructWriter(lazyWriter, blockTransformer(curr), 0);
		finishLazyStructWriting(lazyWriter);
		writeDeleteSet(updateEncoder, readDeleteSet(updateDecoder));
		return updateEncoder.toUint8Array();
	};
	createObfuscator = ({ formatting = true, subdocs = true, yxml = true } = {}) => {
		let i = 0;
		const mapKeyCache = create$5();
		const nodeNameCache = create$5();
		const formattingKeyCache = create$5();
		const formattingValueCache = create$5();
		formattingValueCache.set(null, null);
		/**
		* @param {Item|GC|Skip} block
		* @return {Item|GC|Skip}
		*/
		return (block) => {
			switch (block.constructor) {
				case GC:
				case Skip: return block;
				case Item: {
					const item = block;
					const content = item.content;
					switch (content.constructor) {
						case ContentDeleted: break;
						case ContentType:
							if (yxml) {
								const type = content.type;
								if (type instanceof YXmlElement) type.nodeName = setIfUndefined(nodeNameCache, type.nodeName, () => "node-" + i);
								if (type instanceof YXmlHook) type.hookName = setIfUndefined(nodeNameCache, type.hookName, () => "hook-" + i);
							}
							break;
						case ContentAny: {
							const c = content;
							c.arr = c.arr.map(() => i);
							break;
						}
						case ContentBinary: {
							const c = content;
							c.content = new Uint8Array([i]);
							break;
						}
						case ContentDoc: {
							const c = content;
							if (subdocs) {
								c.opts = {};
								c.doc.guid = i + "";
							}
							break;
						}
						case ContentEmbed: {
							const c = content;
							c.embed = {};
							break;
						}
						case ContentFormat: {
							const c = content;
							if (formatting) {
								c.key = setIfUndefined(formattingKeyCache, c.key, () => i + "");
								c.value = setIfUndefined(formattingValueCache, c.value, () => ({ i }));
							}
							break;
						}
						case ContentJSON: {
							const c = content;
							c.arr = c.arr.map(() => i);
							break;
						}
						case ContentString: {
							const c = content;
							c.str = repeat(i % 10 + "", c.str.length);
							break;
						}
						default: unexpectedCase();
					}
					if (item.parentSub) item.parentSub = setIfUndefined(mapKeyCache, item.parentSub, () => i + "");
					i++;
					return block;
				}
				default: unexpectedCase();
			}
		};
	};
	obfuscateUpdate = (update, opts) => convertUpdateFormat(update, createObfuscator(opts), UpdateDecoderV1, UpdateEncoderV1);
	obfuscateUpdateV2 = (update, opts) => convertUpdateFormat(update, createObfuscator(opts), UpdateDecoderV2, UpdateEncoderV2);
	convertUpdateFormatV1ToV2 = (update) => convertUpdateFormat(update, id, UpdateDecoderV1, UpdateEncoderV2);
	convertUpdateFormatV2ToV1 = (update) => convertUpdateFormat(update, id, UpdateDecoderV2, UpdateEncoderV1);
	errorComputeChanges = "You must not compute changes after the event-handler fired.";
	YEvent = class {
		/**
		* @param {T} target The changed type.
		* @param {Transaction} transaction
		*/
		constructor(target, transaction) {
			/**
			* The type on which this event was created on.
			* @type {T}
			*/
			this.target = target;
			/**
			* The current target on which the observe callback is called.
			* @type {AbstractType<any>}
			*/
			this.currentTarget = target;
			/**
			* The transaction that triggered this event.
			* @type {Transaction}
			*/
			this.transaction = transaction;
			/**
			* @type {Object|null}
			*/
			this._changes = null;
			/**
			* @type {null | Map<string, { action: 'add' | 'update' | 'delete', oldValue: any }>}
			*/
			this._keys = null;
			/**
			* @type {null | Array<{ insert?: string | Array<any> | object | AbstractType<any>, retain?: number, delete?: number, attributes?: Object<string, any> }>}
			*/
			this._delta = null;
			/**
			* @type {Array<string|number>|null}
			*/
			this._path = null;
		}
		/**
		* Computes the path from `y` to the changed type.
		*
		* @todo v14 should standardize on path: Array<{parent, index}> because that is easier to work with.
		*
		* The following property holds:
		* @example
		*   let type = y
		*   event.path.forEach(dir => {
		*     type = type.get(dir)
		*   })
		*   type === event.target // => true
		*/
		get path() {
			return this._path || (this._path = getPathTo(this.currentTarget, this.target));
		}
		/**
		* Check if a struct is deleted by this event.
		*
		* In contrast to change.deleted, this method also returns true if the struct was added and then deleted.
		*
		* @param {AbstractStruct} struct
		* @return {boolean}
		*/
		deletes(struct) {
			return isDeleted(this.transaction.deleteSet, struct.id);
		}
		/**
		* @type {Map<string, { action: 'add' | 'update' | 'delete', oldValue: any }>}
		*/
		get keys() {
			if (this._keys === null) {
				if (this.transaction.doc._transactionCleanups.length === 0) throw create$3(errorComputeChanges);
				const keys = /* @__PURE__ */ new Map();
				const target = this.target;
				this.transaction.changed.get(target).forEach((key) => {
					if (key !== null) {
						const item = target._map.get(key);
						/**
						* @type {'delete' | 'add' | 'update'}
						*/
						let action;
						let oldValue;
						if (this.adds(item)) {
							let prev = item.left;
							while (prev !== null && this.adds(prev)) prev = prev.left;
							if (this.deletes(item)) if (prev !== null && this.deletes(prev)) {
								action = "delete";
								oldValue = last(prev.content.getContent());
							} else return;
							else if (prev !== null && this.deletes(prev)) {
								action = "update";
								oldValue = last(prev.content.getContent());
							} else {
								action = "add";
								oldValue = void 0;
							}
						} else if (this.deletes(item)) {
							action = "delete";
							oldValue = last(
								/** @type {Item} */
								item.content.getContent()
							);
						} else return;
						keys.set(key, {
							action,
							oldValue
						});
					}
				});
				this._keys = keys;
			}
			return this._keys;
		}
		/**
		* This is a computed property. Note that this can only be safely computed during the
		* event call. Computing this property after other changes happened might result in
		* unexpected behavior (incorrect computation of deltas). A safe way to collect changes
		* is to store the `changes` or the `delta` object. Avoid storing the `transaction` object.
		*
		* @type {Array<{insert?: string | Array<any> | object | AbstractType<any>, retain?: number, delete?: number, attributes?: Object<string, any>}>}
		*/
		get delta() {
			return this.changes.delta;
		}
		/**
		* Check if a struct is added by this event.
		*
		* In contrast to change.deleted, this method also returns true if the struct was added and then deleted.
		*
		* @param {AbstractStruct} struct
		* @return {boolean}
		*/
		adds(struct) {
			return struct.id.clock >= (this.transaction.beforeState.get(struct.id.client) || 0);
		}
		/**
		* This is a computed property. Note that this can only be safely computed during the
		* event call. Computing this property after other changes happened might result in
		* unexpected behavior (incorrect computation of deltas). A safe way to collect changes
		* is to store the `changes` or the `delta` object. Avoid storing the `transaction` object.
		*
		* @type {{added:Set<Item>,deleted:Set<Item>,keys:Map<string,{action:'add'|'update'|'delete',oldValue:any}>,delta:Array<{insert?:Array<any>|string, delete?:number, retain?:number}>}}
		*/
		get changes() {
			let changes = this._changes;
			if (changes === null) {
				if (this.transaction.doc._transactionCleanups.length === 0) throw create$3(errorComputeChanges);
				const target = this.target;
				const added = create$4();
				const deleted = create$4();
				/**
				* @type {Array<{insert:Array<any>}|{delete:number}|{retain:number}>}
				*/
				const delta = [];
				changes = {
					added,
					deleted,
					delta,
					keys: this.keys
				};
				if (this.transaction.changed.get(target).has(null)) {
					/**
					* @type {any}
					*/
					let lastOp = null;
					const packOp = () => {
						if (lastOp) delta.push(lastOp);
					};
					for (let item = target._start; item !== null; item = item.right) if (item.deleted) {
						if (this.deletes(item) && !this.adds(item)) {
							if (lastOp === null || lastOp.delete === void 0) {
								packOp();
								lastOp = { delete: 0 };
							}
							lastOp.delete += item.length;
							deleted.add(item);
						}
					} else if (this.adds(item)) {
						if (lastOp === null || lastOp.insert === void 0) {
							packOp();
							lastOp = { insert: [] };
						}
						lastOp.insert = lastOp.insert.concat(item.content.getContent());
						added.add(item);
					} else {
						if (lastOp === null || lastOp.retain === void 0) {
							packOp();
							lastOp = { retain: 0 };
						}
						lastOp.retain += item.length;
					}
					if (lastOp !== null && lastOp.retain === void 0) packOp();
				}
				this._changes = changes;
			}
			return changes;
		}
	};
	getPathTo = (parent, child) => {
		const path = [];
		while (child._item !== null && child !== parent) {
			if (child._item.parentSub !== null) path.unshift(child._item.parentSub);
			else {
				let i = 0;
				let c = child._item.parent._start;
				while (c !== child._item && c !== null) {
					if (!c.deleted && c.countable) i += c.length;
					c = c.right;
				}
				path.unshift(i);
			}
			child = child._item.parent;
		}
		return path;
	};
	warnPrematureAccess = () => {
		warn("Invalid access: Add Yjs type to a document before reading data.");
	};
	maxSearchMarker = 80;
	globalSearchMarkerTimestamp = 0;
	ArraySearchMarker = class {
		/**
		* @param {Item} p
		* @param {number} index
		*/
		constructor(p, index) {
			p.marker = true;
			this.p = p;
			this.index = index;
			this.timestamp = globalSearchMarkerTimestamp++;
		}
	};
	refreshMarkerTimestamp = (marker) => {
		marker.timestamp = globalSearchMarkerTimestamp++;
	};
	overwriteMarker = (marker, p, index) => {
		marker.p.marker = false;
		marker.p = p;
		p.marker = true;
		marker.index = index;
		marker.timestamp = globalSearchMarkerTimestamp++;
	};
	markPosition = (searchMarker, p, index) => {
		if (searchMarker.length >= maxSearchMarker) {
			const marker = searchMarker.reduce((a, b) => a.timestamp < b.timestamp ? a : b);
			overwriteMarker(marker, p, index);
			return marker;
		} else {
			const pm = new ArraySearchMarker(p, index);
			searchMarker.push(pm);
			return pm;
		}
	};
	findMarker = (yarray, index) => {
		if (yarray._start === null || index === 0 || yarray._searchMarker === null) return null;
		const marker = yarray._searchMarker.length === 0 ? null : yarray._searchMarker.reduce((a, b) => abs(index - a.index) < abs(index - b.index) ? a : b);
		let p = yarray._start;
		let pindex = 0;
		if (marker !== null) {
			p = marker.p;
			pindex = marker.index;
			refreshMarkerTimestamp(marker);
		}
		while (p.right !== null && pindex < index) {
			if (!p.deleted && p.countable) {
				if (index < pindex + p.length) break;
				pindex += p.length;
			}
			p = p.right;
		}
		while (p.left !== null && pindex > index) {
			p = p.left;
			if (!p.deleted && p.countable) pindex -= p.length;
		}
		while (p.left !== null && p.left.id.client === p.id.client && p.left.id.clock + p.left.length === p.id.clock) {
			p = p.left;
			if (!p.deleted && p.countable) pindex -= p.length;
		}
		if (marker !== null && abs(marker.index - pindex) < p.parent.length / maxSearchMarker) {
			overwriteMarker(marker, p, pindex);
			return marker;
		} else return markPosition(yarray._searchMarker, p, pindex);
	};
	updateMarkerChanges = (searchMarker, index, len) => {
		for (let i = searchMarker.length - 1; i >= 0; i--) {
			const m = searchMarker[i];
			if (len > 0) {
				/**
				* @type {Item|null}
				*/
				let p = m.p;
				p.marker = false;
				while (p && (p.deleted || !p.countable)) {
					p = p.left;
					if (p && !p.deleted && p.countable) m.index -= p.length;
				}
				if (p === null || p.marker === true) {
					searchMarker.splice(i, 1);
					continue;
				}
				m.p = p;
				p.marker = true;
			}
			if (index < m.index || len > 0 && index === m.index) m.index = max(index, m.index + len);
		}
	};
	getTypeChildren = (t) => {
		t.doc ?? warnPrematureAccess();
		let s = t._start;
		const arr = [];
		while (s) {
			arr.push(s);
			s = s.right;
		}
		return arr;
	};
	callTypeObservers = (type, transaction, event) => {
		const changedType = type;
		const changedParentTypes = transaction.changedParentTypes;
		while (true) {
			setIfUndefined(changedParentTypes, type, () => []).push(event);
			if (type._item === null) break;
			type = type._item.parent;
		}
		callEventHandlerListeners(changedType._eH, event, transaction);
	};
	AbstractType = class {
		constructor() {
			/**
			* @type {Item|null}
			*/
			this._item = null;
			/**
			* @type {Map<string,Item>}
			*/
			this._map = /* @__PURE__ */ new Map();
			/**
			* @type {Item|null}
			*/
			this._start = null;
			/**
			* @type {Doc|null}
			*/
			this.doc = null;
			this._length = 0;
			/**
			* Event handlers
			* @type {EventHandler<EventType,Transaction>}
			*/
			this._eH = createEventHandler();
			/**
			* Deep event handlers
			* @type {EventHandler<Array<YEvent<any>>,Transaction>}
			*/
			this._dEH = createEventHandler();
			/**
			* @type {null | Array<ArraySearchMarker>}
			*/
			this._searchMarker = null;
		}
		/**
		* @return {AbstractType<any>|null}
		*/
		get parent() {
			return this._item ? this._item.parent : null;
		}
		/**
		* Integrate this type into the Yjs instance.
		*
		* * Save this struct in the os
		* * This type is sent to other client
		* * Observer functions are fired
		*
		* @param {Doc} y The Yjs instance
		* @param {Item|null} item
		*/
		_integrate(y, item) {
			this.doc = y;
			this._item = item;
		}
		/**
		* @return {AbstractType<EventType>}
		*/
		_copy() {
			throw methodUnimplemented();
		}
		/**
		* Makes a copy of this data type that can be included somewhere else.
		*
		* Note that the content is only readable _after_ it has been included somewhere in the Ydoc.
		*
		* @return {AbstractType<EventType>}
		*/
		clone() {
			throw methodUnimplemented();
		}
		/**
		* @param {UpdateEncoderV1 | UpdateEncoderV2} _encoder
		*/
		_write(_encoder) {}
		/**
		* The first non-deleted item
		*/
		get _first() {
			let n = this._start;
			while (n !== null && n.deleted) n = n.right;
			return n;
		}
		/**
		* Creates YEvent and calls all type observers.
		* Must be implemented by each type.
		*
		* @param {Transaction} transaction
		* @param {Set<null|string>} _parentSubs Keys changed on this type. `null` if list was modified.
		*/
		_callObserver(transaction, _parentSubs) {
			if (!transaction.local && this._searchMarker) this._searchMarker.length = 0;
		}
		/**
		* Observe all events that are created on this type.
		*
		* @param {function(EventType, Transaction):void} f Observer function
		*/
		observe(f) {
			addEventHandlerListener(this._eH, f);
		}
		/**
		* Observe all events that are created by this type and its children.
		*
		* @param {function(Array<YEvent<any>>,Transaction):void} f Observer function
		*/
		observeDeep(f) {
			addEventHandlerListener(this._dEH, f);
		}
		/**
		* Unregister an observer function.
		*
		* @param {function(EventType,Transaction):void} f Observer function
		*/
		unobserve(f) {
			removeEventHandlerListener(this._eH, f);
		}
		/**
		* Unregister an observer function.
		*
		* @param {function(Array<YEvent<any>>,Transaction):void} f Observer function
		*/
		unobserveDeep(f) {
			removeEventHandlerListener(this._dEH, f);
		}
		/**
		* @abstract
		* @return {any}
		*/
		toJSON() {}
	};
	typeListSlice = (type, start, end) => {
		type.doc ?? warnPrematureAccess();
		if (start < 0) start = type._length + start;
		if (end < 0) end = type._length + end;
		let len = end - start;
		const cs = [];
		let n = type._start;
		while (n !== null && len > 0) {
			if (n.countable && !n.deleted) {
				const c = n.content.getContent();
				if (c.length <= start) start -= c.length;
				else {
					for (let i = start; i < c.length && len > 0; i++) {
						cs.push(c[i]);
						len--;
					}
					start = 0;
				}
			}
			n = n.right;
		}
		return cs;
	};
	typeListToArray = (type) => {
		type.doc ?? warnPrematureAccess();
		const cs = [];
		let n = type._start;
		while (n !== null) {
			if (n.countable && !n.deleted) {
				const c = n.content.getContent();
				for (let i = 0; i < c.length; i++) cs.push(c[i]);
			}
			n = n.right;
		}
		return cs;
	};
	typeListToArraySnapshot = (type, snapshot) => {
		const cs = [];
		let n = type._start;
		while (n !== null) {
			if (n.countable && isVisible(n, snapshot)) {
				const c = n.content.getContent();
				for (let i = 0; i < c.length; i++) cs.push(c[i]);
			}
			n = n.right;
		}
		return cs;
	};
	typeListForEach = (type, f) => {
		let index = 0;
		let n = type._start;
		type.doc ?? warnPrematureAccess();
		while (n !== null) {
			if (n.countable && !n.deleted) {
				const c = n.content.getContent();
				for (let i = 0; i < c.length; i++) f(c[i], index++, type);
			}
			n = n.right;
		}
	};
	typeListMap = (type, f) => {
		/**
		* @type {Array<any>}
		*/
		const result = [];
		typeListForEach(type, (c, i) => {
			result.push(f(c, i, type));
		});
		return result;
	};
	typeListCreateIterator = (type) => {
		let n = type._start;
		/**
		* @type {Array<any>|null}
		*/
		let currentContent = null;
		let currentContentIndex = 0;
		return {
			[Symbol.iterator]() {
				return this;
			},
			next: () => {
				if (currentContent === null) {
					while (n !== null && n.deleted) n = n.right;
					if (n === null) return {
						done: true,
						value: void 0
					};
					currentContent = n.content.getContent();
					currentContentIndex = 0;
					n = n.right;
				}
				const value = currentContent[currentContentIndex++];
				if (currentContent.length <= currentContentIndex) currentContent = null;
				return {
					done: false,
					value
				};
			}
		};
	};
	typeListGet = (type, index) => {
		type.doc ?? warnPrematureAccess();
		const marker = findMarker(type, index);
		let n = type._start;
		if (marker !== null) {
			n = marker.p;
			index -= marker.index;
		}
		for (; n !== null; n = n.right) if (!n.deleted && n.countable) {
			if (index < n.length) return n.content.getContent()[index];
			index -= n.length;
		}
	};
	typeListInsertGenericsAfter = (transaction, parent, referenceItem, content) => {
		let left = referenceItem;
		const doc = transaction.doc;
		const ownClientId = doc.clientID;
		const store = doc.store;
		const right = referenceItem === null ? parent._start : referenceItem.right;
		/**
		* @type {Array<Object|Array<any>|number|null>}
		*/
		let jsonContent = [];
		const packJsonContent = () => {
			if (jsonContent.length > 0) {
				left = new Item(createID(ownClientId, getState(store, ownClientId)), left, left && left.lastId, right, right && right.id, parent, null, new ContentAny(jsonContent));
				left.integrate(transaction, 0);
				jsonContent = [];
			}
		};
		content.forEach((c) => {
			if (c === null) jsonContent.push(c);
			else switch (c.constructor) {
				case Number:
				case Object:
				case Boolean:
				case Array:
				case String:
					jsonContent.push(c);
					break;
				default:
					packJsonContent();
					switch (c.constructor) {
						case Uint8Array:
						case ArrayBuffer:
							left = new Item(createID(ownClientId, getState(store, ownClientId)), left, left && left.lastId, right, right && right.id, parent, null, new ContentBinary(new Uint8Array(c)));
							left.integrate(transaction, 0);
							break;
						case Doc:
							left = new Item(createID(ownClientId, getState(store, ownClientId)), left, left && left.lastId, right, right && right.id, parent, null, new ContentDoc(c));
							left.integrate(transaction, 0);
							break;
						default: if (c instanceof AbstractType) {
							left = new Item(createID(ownClientId, getState(store, ownClientId)), left, left && left.lastId, right, right && right.id, parent, null, new ContentType(c));
							left.integrate(transaction, 0);
						} else throw new Error("Unexpected content type in insert operation");
					}
			}
		});
		packJsonContent();
	};
	lengthExceeded = () => create$3("Length exceeded!");
	typeListInsertGenerics = (transaction, parent, index, content) => {
		if (index > parent._length) throw lengthExceeded();
		if (index === 0) {
			if (parent._searchMarker) updateMarkerChanges(parent._searchMarker, index, content.length);
			return typeListInsertGenericsAfter(transaction, parent, null, content);
		}
		const startIndex = index;
		const marker = findMarker(parent, index);
		let n = parent._start;
		if (marker !== null) {
			n = marker.p;
			index -= marker.index;
			if (index === 0) {
				n = n.prev;
				index += n && n.countable && !n.deleted ? n.length : 0;
			}
		}
		for (; n !== null; n = n.right) if (!n.deleted && n.countable) {
			if (index <= n.length) {
				if (index < n.length) getItemCleanStart(transaction, createID(n.id.client, n.id.clock + index));
				break;
			}
			index -= n.length;
		}
		if (parent._searchMarker) updateMarkerChanges(parent._searchMarker, startIndex, content.length);
		return typeListInsertGenericsAfter(transaction, parent, n, content);
	};
	typeListPushGenerics = (transaction, parent, content) => {
		let n = (parent._searchMarker || []).reduce((maxMarker, currMarker) => currMarker.index > maxMarker.index ? currMarker : maxMarker, {
			index: 0,
			p: parent._start
		}).p;
		if (n) while (n.right) n = n.right;
		return typeListInsertGenericsAfter(transaction, parent, n, content);
	};
	typeListDelete = (transaction, parent, index, length) => {
		if (length === 0) return;
		const startIndex = index;
		const startLength = length;
		const marker = findMarker(parent, index);
		let n = parent._start;
		if (marker !== null) {
			n = marker.p;
			index -= marker.index;
		}
		for (; n !== null && index > 0; n = n.right) if (!n.deleted && n.countable) {
			if (index < n.length) getItemCleanStart(transaction, createID(n.id.client, n.id.clock + index));
			index -= n.length;
		}
		while (length > 0 && n !== null) {
			if (!n.deleted) {
				if (length < n.length) getItemCleanStart(transaction, createID(n.id.client, n.id.clock + length));
				n.delete(transaction);
				length -= n.length;
			}
			n = n.right;
		}
		if (length > 0) throw lengthExceeded();
		if (parent._searchMarker) updateMarkerChanges(parent._searchMarker, startIndex, -startLength + length);
	};
	typeMapDelete = (transaction, parent, key) => {
		const c = parent._map.get(key);
		if (c !== void 0) c.delete(transaction);
	};
	typeMapSet = (transaction, parent, key, value) => {
		const left = parent._map.get(key) || null;
		const doc = transaction.doc;
		const ownClientId = doc.clientID;
		let content;
		if (value == null) content = new ContentAny([value]);
		else switch (value.constructor) {
			case Number:
			case Object:
			case Boolean:
			case Array:
			case String:
			case Date:
			case BigInt:
				content = new ContentAny([value]);
				break;
			case Uint8Array:
				content = new ContentBinary(value);
				break;
			case Doc:
				content = new ContentDoc(value);
				break;
			default: if (value instanceof AbstractType) content = new ContentType(value);
			else throw new Error("Unexpected content type");
		}
		new Item(createID(ownClientId, getState(doc.store, ownClientId)), left, left && left.lastId, null, null, parent, key, content).integrate(transaction, 0);
	};
	typeMapGet = (parent, key) => {
		parent.doc ?? warnPrematureAccess();
		const val = parent._map.get(key);
		return val !== void 0 && !val.deleted ? val.content.getContent()[val.length - 1] : void 0;
	};
	typeMapGetAll = (parent) => {
		/**
		* @type {Object<string,any>}
		*/
		const res = {};
		parent.doc ?? warnPrematureAccess();
		parent._map.forEach((value, key) => {
			if (!value.deleted) res[key] = value.content.getContent()[value.length - 1];
		});
		return res;
	};
	typeMapHas = (parent, key) => {
		parent.doc ?? warnPrematureAccess();
		const val = parent._map.get(key);
		return val !== void 0 && !val.deleted;
	};
	typeMapGetSnapshot = (parent, key, snapshot) => {
		let v = parent._map.get(key) || null;
		while (v !== null && (!snapshot.sv.has(v.id.client) || v.id.clock >= (snapshot.sv.get(v.id.client) || 0))) v = v.left;
		return v !== null && isVisible(v, snapshot) ? v.content.getContent()[v.length - 1] : void 0;
	};
	typeMapGetAllSnapshot = (parent, snapshot) => {
		/**
		* @type {Object<string,any>}
		*/
		const res = {};
		parent._map.forEach((value, key) => {
			/**
			* @type {Item|null}
			*/
			let v = value;
			while (v !== null && (!snapshot.sv.has(v.id.client) || v.id.clock >= (snapshot.sv.get(v.id.client) || 0))) v = v.left;
			if (v !== null && isVisible(v, snapshot)) res[key] = v.content.getContent()[v.length - 1];
		});
		return res;
	};
	createMapIterator = (type) => {
		type.doc ?? warnPrematureAccess();
		return iteratorFilter(
			type._map.entries(),
			/** @param {any} entry */
			(entry) => !entry[1].deleted
		);
	};
	YArrayEvent = class extends YEvent {};
	YArray = class YArray extends AbstractType {
		constructor() {
			super();
			/**
			* @type {Array<any>?}
			* @private
			*/
			this._prelimContent = [];
			/**
			* @type {Array<ArraySearchMarker>}
			*/
			this._searchMarker = [];
		}
		/**
		* Construct a new YArray containing the specified items.
		* @template {Object<string,any>|Array<any>|number|null|string|Uint8Array} T
		* @param {Array<T>} items
		* @return {YArray<T>}
		*/
		static from(items) {
			/**
			* @type {YArray<T>}
			*/
			const a = new YArray();
			a.push(items);
			return a;
		}
		/**
		* Integrate this type into the Yjs instance.
		*
		* * Save this struct in the os
		* * This type is sent to other client
		* * Observer functions are fired
		*
		* @param {Doc} y The Yjs instance
		* @param {Item} item
		*/
		_integrate(y, item) {
			super._integrate(y, item);
			this.insert(0, this._prelimContent);
			this._prelimContent = null;
		}
		/**
		* @return {YArray<T>}
		*/
		_copy() {
			return new YArray();
		}
		/**
		* Makes a copy of this data type that can be included somewhere else.
		*
		* Note that the content is only readable _after_ it has been included somewhere in the Ydoc.
		*
		* @return {YArray<T>}
		*/
		clone() {
			/**
			* @type {YArray<T>}
			*/
			const arr = new YArray();
			arr.insert(0, this.toArray().map((el) => el instanceof AbstractType ? el.clone() : el));
			return arr;
		}
		get length() {
			this.doc ?? warnPrematureAccess();
			return this._length;
		}
		/**
		* Creates YArrayEvent and calls observers.
		*
		* @param {Transaction} transaction
		* @param {Set<null|string>} parentSubs Keys changed on this type. `null` if list was modified.
		*/
		_callObserver(transaction, parentSubs) {
			super._callObserver(transaction, parentSubs);
			callTypeObservers(this, transaction, new YArrayEvent(this, transaction));
		}
		/**
		* Inserts new content at an index.
		*
		* Important: This function expects an array of content. Not just a content
		* object. The reason for this "weirdness" is that inserting several elements
		* is very efficient when it is done as a single operation.
		*
		* @example
		*  // Insert character 'a' at position 0
		*  yarray.insert(0, ['a'])
		*  // Insert numbers 1, 2 at position 1
		*  yarray.insert(1, [1, 2])
		*
		* @param {number} index The index to insert content at.
		* @param {Array<T>} content The array of content
		*/
		insert(index, content) {
			if (this.doc !== null) transact(this.doc, (transaction) => {
				typeListInsertGenerics(transaction, this, index, content);
			});
			else
 /** @type {Array<any>} */ this._prelimContent.splice(index, 0, ...content);
		}
		/**
		* Appends content to this YArray.
		*
		* @param {Array<T>} content Array of content to append.
		*
		* @todo Use the following implementation in all types.
		*/
		push(content) {
			if (this.doc !== null) transact(this.doc, (transaction) => {
				typeListPushGenerics(transaction, this, content);
			});
			else
 /** @type {Array<any>} */ this._prelimContent.push(...content);
		}
		/**
		* Prepends content to this YArray.
		*
		* @param {Array<T>} content Array of content to prepend.
		*/
		unshift(content) {
			this.insert(0, content);
		}
		/**
		* Deletes elements starting from an index.
		*
		* @param {number} index Index at which to start deleting elements
		* @param {number} length The number of elements to remove. Defaults to 1.
		*/
		delete(index, length = 1) {
			if (this.doc !== null) transact(this.doc, (transaction) => {
				typeListDelete(transaction, this, index, length);
			});
			else
 /** @type {Array<any>} */ this._prelimContent.splice(index, length);
		}
		/**
		* Returns the i-th element from a YArray.
		*
		* @param {number} index The index of the element to return from the YArray
		* @return {T}
		*/
		get(index) {
			return typeListGet(this, index);
		}
		/**
		* Transforms this YArray to a JavaScript Array.
		*
		* @return {Array<T>}
		*/
		toArray() {
			return typeListToArray(this);
		}
		/**
		* Returns a portion of this YArray into a JavaScript Array selected
		* from start to end (end not included).
		*
		* @param {number} [start]
		* @param {number} [end]
		* @return {Array<T>}
		*/
		slice(start = 0, end = this.length) {
			return typeListSlice(this, start, end);
		}
		/**
		* Transforms this Shared Type to a JSON object.
		*
		* @return {Array<any>}
		*/
		toJSON() {
			return this.map((c) => c instanceof AbstractType ? c.toJSON() : c);
		}
		/**
		* Returns an Array with the result of calling a provided function on every
		* element of this YArray.
		*
		* @template M
		* @param {function(T,number,YArray<T>):M} f Function that produces an element of the new Array
		* @return {Array<M>} A new array with each element being the result of the
		*                 callback function
		*/
		map(f) {
			return typeListMap(this, f);
		}
		/**
		* Executes a provided function once on every element of this YArray.
		*
		* @param {function(T,number,YArray<T>):void} f A function to execute on every element of this YArray.
		*/
		forEach(f) {
			typeListForEach(this, f);
		}
		/**
		* @return {IterableIterator<T>}
		*/
		[Symbol.iterator]() {
			return typeListCreateIterator(this);
		}
		/**
		* @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
		*/
		_write(encoder) {
			encoder.writeTypeRef(YArrayRefID);
		}
	};
	readYArray = (_decoder) => new YArray();
	YMapEvent = class extends YEvent {
		/**
		* @param {YMap<T>} ymap The YArray that changed.
		* @param {Transaction} transaction
		* @param {Set<any>} subs The keys that changed.
		*/
		constructor(ymap, transaction, subs) {
			super(ymap, transaction);
			this.keysChanged = subs;
		}
	};
	YMap = class YMap extends AbstractType {
		/**
		*
		* @param {Iterable<readonly [string, any]>=} entries - an optional iterable to initialize the YMap
		*/
		constructor(entries) {
			super();
			/**
			* @type {Map<string,any>?}
			* @private
			*/
			this._prelimContent = null;
			if (entries === void 0) this._prelimContent = /* @__PURE__ */ new Map();
			else this._prelimContent = new Map(entries);
		}
		/**
		* Integrate this type into the Yjs instance.
		*
		* * Save this struct in the os
		* * This type is sent to other client
		* * Observer functions are fired
		*
		* @param {Doc} y The Yjs instance
		* @param {Item} item
		*/
		_integrate(y, item) {
			super._integrate(y, item);
			/** @type {Map<string, any>} */ this._prelimContent.forEach((value, key) => {
				this.set(key, value);
			});
			this._prelimContent = null;
		}
		/**
		* @return {YMap<MapType>}
		*/
		_copy() {
			return new YMap();
		}
		/**
		* Makes a copy of this data type that can be included somewhere else.
		*
		* Note that the content is only readable _after_ it has been included somewhere in the Ydoc.
		*
		* @return {YMap<MapType>}
		*/
		clone() {
			/**
			* @type {YMap<MapType>}
			*/
			const map = new YMap();
			this.forEach((value, key) => {
				map.set(key, value instanceof AbstractType ? value.clone() : value);
			});
			return map;
		}
		/**
		* Creates YMapEvent and calls observers.
		*
		* @param {Transaction} transaction
		* @param {Set<null|string>} parentSubs Keys changed on this type. `null` if list was modified.
		*/
		_callObserver(transaction, parentSubs) {
			callTypeObservers(this, transaction, new YMapEvent(this, transaction, parentSubs));
		}
		/**
		* Transforms this Shared Type to a JSON object.
		*
		* @return {Object<string,any>}
		*/
		toJSON() {
			this.doc ?? warnPrematureAccess();
			/**
			* @type {Object<string,MapType>}
			*/
			const map = {};
			this._map.forEach((item, key) => {
				if (!item.deleted) {
					const v = item.content.getContent()[item.length - 1];
					map[key] = v instanceof AbstractType ? v.toJSON() : v;
				}
			});
			return map;
		}
		/**
		* Returns the size of the YMap (count of key/value pairs)
		*
		* @return {number}
		*/
		get size() {
			return [...createMapIterator(this)].length;
		}
		/**
		* Returns the keys for each element in the YMap Type.
		*
		* @return {IterableIterator<string>}
		*/
		keys() {
			return iteratorMap(
				createMapIterator(this),
				/** @param {any} v */
				(v) => v[0]
			);
		}
		/**
		* Returns the values for each element in the YMap Type.
		*
		* @return {IterableIterator<MapType>}
		*/
		values() {
			return iteratorMap(
				createMapIterator(this),
				/** @param {any} v */
				(v) => v[1].content.getContent()[v[1].length - 1]
			);
		}
		/**
		* Returns an Iterator of [key, value] pairs
		*
		* @return {IterableIterator<[string, MapType]>}
		*/
		entries() {
			return iteratorMap(
				createMapIterator(this),
				/** @param {any} v */
				(v) => [v[0], v[1].content.getContent()[v[1].length - 1]]
			);
		}
		/**
		* Executes a provided function on once on every key-value pair.
		*
		* @param {function(MapType,string,YMap<MapType>):void} f A function to execute on every element of this YArray.
		*/
		forEach(f) {
			this.doc ?? warnPrematureAccess();
			this._map.forEach((item, key) => {
				if (!item.deleted) f(item.content.getContent()[item.length - 1], key, this);
			});
		}
		/**
		* Returns an Iterator of [key, value] pairs
		*
		* @return {IterableIterator<[string, MapType]>}
		*/
		[Symbol.iterator]() {
			return this.entries();
		}
		/**
		* Remove a specified element from this YMap.
		*
		* @param {string} key The key of the element to remove.
		*/
		delete(key) {
			if (this.doc !== null) transact(this.doc, (transaction) => {
				typeMapDelete(transaction, this, key);
			});
			else
 /** @type {Map<string, any>} */ this._prelimContent.delete(key);
		}
		/**
		* Adds or updates an element with a specified key and value.
		* @template {MapType} VAL
		*
		* @param {string} key The key of the element to add to this YMap
		* @param {VAL} value The value of the element to add
		* @return {VAL}
		*/
		set(key, value) {
			if (this.doc !== null) transact(this.doc, (transaction) => {
				typeMapSet(transaction, this, key, value);
			});
			else
 /** @type {Map<string, any>} */ this._prelimContent.set(key, value);
			return value;
		}
		/**
		* Returns a specified element from this YMap.
		*
		* @param {string} key
		* @return {MapType|undefined}
		*/
		get(key) {
			return typeMapGet(this, key);
		}
		/**
		* Returns a boolean indicating whether the specified key exists or not.
		*
		* @param {string} key The key to test.
		* @return {boolean}
		*/
		has(key) {
			return typeMapHas(this, key);
		}
		/**
		* Removes all elements from this YMap.
		*/
		clear() {
			if (this.doc !== null) transact(this.doc, (transaction) => {
				this.forEach(function(_value, key, map) {
					typeMapDelete(transaction, map, key);
				});
			});
			else
 /** @type {Map<string, any>} */ this._prelimContent.clear();
		}
		/**
		* @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
		*/
		_write(encoder) {
			encoder.writeTypeRef(YMapRefID);
		}
	};
	readYMap = (_decoder) => new YMap();
	equalAttrs = (a, b) => a === b || typeof a === "object" && typeof b === "object" && a && b && equalFlat(a, b);
	ItemTextListPosition = class {
		/**
		* @param {Item|null} left
		* @param {Item|null} right
		* @param {number} index
		* @param {Map<string,any>} currentAttributes
		*/
		constructor(left, right, index, currentAttributes) {
			this.left = left;
			this.right = right;
			this.index = index;
			this.currentAttributes = currentAttributes;
		}
		/**
		* Only call this if you know that this.right is defined
		*/
		forward() {
			if (this.right === null) unexpectedCase();
			switch (this.right.content.constructor) {
				case ContentFormat:
					if (!this.right.deleted) updateCurrentAttributes(this.currentAttributes, this.right.content);
					break;
				default:
					if (!this.right.deleted) this.index += this.right.length;
					break;
			}
			this.left = this.right;
			this.right = this.right.right;
		}
	};
	findNextPosition = (transaction, pos, count) => {
		while (pos.right !== null && count > 0) {
			switch (pos.right.content.constructor) {
				case ContentFormat:
					if (!pos.right.deleted) updateCurrentAttributes(pos.currentAttributes, pos.right.content);
					break;
				default:
					if (!pos.right.deleted) {
						if (count < pos.right.length) getItemCleanStart(transaction, createID(pos.right.id.client, pos.right.id.clock + count));
						pos.index += pos.right.length;
						count -= pos.right.length;
					}
					break;
			}
			pos.left = pos.right;
			pos.right = pos.right.right;
		}
		return pos;
	};
	findPosition = (transaction, parent, index, useSearchMarker) => {
		const currentAttributes = /* @__PURE__ */ new Map();
		const marker = useSearchMarker ? findMarker(parent, index) : null;
		if (marker) return findNextPosition(transaction, new ItemTextListPosition(marker.p.left, marker.p, marker.index, currentAttributes), index - marker.index);
		else return findNextPosition(transaction, new ItemTextListPosition(null, parent._start, 0, currentAttributes), index);
	};
	insertNegatedAttributes = (transaction, parent, currPos, negatedAttributes) => {
		while (currPos.right !== null && (currPos.right.deleted === true || currPos.right.content.constructor === ContentFormat && equalAttrs(
			negatedAttributes.get(
				/** @type {ContentFormat} */
				currPos.right.content.key
			),
			/** @type {ContentFormat} */
			currPos.right.content.value
		))) {
			if (!currPos.right.deleted) negatedAttributes.delete(
				/** @type {ContentFormat} */
				currPos.right.content.key
			);
			currPos.forward();
		}
		const doc = transaction.doc;
		const ownClientId = doc.clientID;
		negatedAttributes.forEach((val, key) => {
			const left = currPos.left;
			const right = currPos.right;
			const nextFormat = new Item(createID(ownClientId, getState(doc.store, ownClientId)), left, left && left.lastId, right, right && right.id, parent, null, new ContentFormat(key, val));
			nextFormat.integrate(transaction, 0);
			currPos.right = nextFormat;
			currPos.forward();
		});
	};
	updateCurrentAttributes = (currentAttributes, format) => {
		const { key, value } = format;
		if (value === null) currentAttributes.delete(key);
		else currentAttributes.set(key, value);
	};
	minimizeAttributeChanges = (currPos, attributes) => {
		while (true) {
			if (currPos.right === null) break;
			else if (currPos.right.deleted || currPos.right.content.constructor === ContentFormat && equalAttrs(
				attributes[currPos.right.content.key] ?? null,
				/** @type {ContentFormat} */
				currPos.right.content.value
			));
			else break;
			currPos.forward();
		}
	};
	insertAttributes = (transaction, parent, currPos, attributes) => {
		const doc = transaction.doc;
		const ownClientId = doc.clientID;
		const negatedAttributes = /* @__PURE__ */ new Map();
		for (const key in attributes) {
			const val = attributes[key];
			const currentVal = currPos.currentAttributes.get(key) ?? null;
			if (!equalAttrs(currentVal, val)) {
				negatedAttributes.set(key, currentVal);
				const { left, right } = currPos;
				currPos.right = new Item(createID(ownClientId, getState(doc.store, ownClientId)), left, left && left.lastId, right, right && right.id, parent, null, new ContentFormat(key, val));
				currPos.right.integrate(transaction, 0);
				currPos.forward();
			}
		}
		return negatedAttributes;
	};
	insertText = (transaction, parent, currPos, text, attributes) => {
		currPos.currentAttributes.forEach((_val, key) => {
			if (attributes[key] === void 0) attributes[key] = null;
		});
		const doc = transaction.doc;
		const ownClientId = doc.clientID;
		minimizeAttributeChanges(currPos, attributes);
		const negatedAttributes = insertAttributes(transaction, parent, currPos, attributes);
		const content = text.constructor === String ? new ContentString(text) : text instanceof AbstractType ? new ContentType(text) : new ContentEmbed(text);
		let { left, right, index } = currPos;
		if (parent._searchMarker) updateMarkerChanges(parent._searchMarker, currPos.index, content.getLength());
		right = new Item(createID(ownClientId, getState(doc.store, ownClientId)), left, left && left.lastId, right, right && right.id, parent, null, content);
		right.integrate(transaction, 0);
		currPos.right = right;
		currPos.index = index;
		currPos.forward();
		insertNegatedAttributes(transaction, parent, currPos, negatedAttributes);
	};
	formatText = (transaction, parent, currPos, length, attributes) => {
		const doc = transaction.doc;
		const ownClientId = doc.clientID;
		minimizeAttributeChanges(currPos, attributes);
		const negatedAttributes = insertAttributes(transaction, parent, currPos, attributes);
		iterationLoop: while (currPos.right !== null && (length > 0 || negatedAttributes.size > 0 && (currPos.right.deleted || currPos.right.content.constructor === ContentFormat))) {
			if (!currPos.right.deleted) switch (currPos.right.content.constructor) {
				case ContentFormat: {
					const { key, value } = currPos.right.content;
					const attr = attributes[key];
					if (attr !== void 0) {
						if (equalAttrs(attr, value)) negatedAttributes.delete(key);
						else {
							if (length === 0) break iterationLoop;
							negatedAttributes.set(key, value);
						}
						currPos.right.delete(transaction);
					} else currPos.currentAttributes.set(key, value);
					break;
				}
				default:
					if (length < currPos.right.length) getItemCleanStart(transaction, createID(currPos.right.id.client, currPos.right.id.clock + length));
					length -= currPos.right.length;
					break;
			}
			currPos.forward();
		}
		if (length > 0) {
			let newlines = "";
			for (; length > 0; length--) newlines += "\n";
			currPos.right = new Item(createID(ownClientId, getState(doc.store, ownClientId)), currPos.left, currPos.left && currPos.left.lastId, currPos.right, currPos.right && currPos.right.id, parent, null, new ContentString(newlines));
			currPos.right.integrate(transaction, 0);
			currPos.forward();
		}
		insertNegatedAttributes(transaction, parent, currPos, negatedAttributes);
	};
	cleanupFormattingGap = (transaction, start, curr, startAttributes, currAttributes) => {
		/**
		* @type {Item|null}
		*/
		let end = start;
		/**
		* @type {Map<string,ContentFormat>}
		*/
		const endFormats = create$5();
		while (end && (!end.countable || end.deleted)) {
			if (!end.deleted && end.content.constructor === ContentFormat) {
				const cf = end.content;
				endFormats.set(cf.key, cf);
			}
			end = end.right;
		}
		let cleanups = 0;
		let reachedCurr = false;
		while (start !== end) {
			if (curr === start) reachedCurr = true;
			if (!start.deleted) {
				const content = start.content;
				switch (content.constructor) {
					case ContentFormat: {
						const { key, value } = content;
						const startAttrValue = startAttributes.get(key) ?? null;
						if (endFormats.get(key) !== content || startAttrValue === value) {
							start.delete(transaction);
							cleanups++;
							if (!reachedCurr && (currAttributes.get(key) ?? null) === value && startAttrValue !== value) if (startAttrValue === null) currAttributes.delete(key);
							else currAttributes.set(key, startAttrValue);
						}
						if (!reachedCurr && !start.deleted) updateCurrentAttributes(currAttributes, content);
						break;
					}
				}
			}
			start = start.right;
		}
		return cleanups;
	};
	cleanupContextlessFormattingGap = (transaction, item) => {
		while (item && item.right && (item.right.deleted || !item.right.countable)) item = item.right;
		const attrs = /* @__PURE__ */ new Set();
		while (item && (item.deleted || !item.countable)) {
			if (!item.deleted && item.content.constructor === ContentFormat) {
				const key = item.content.key;
				if (attrs.has(key)) item.delete(transaction);
				else attrs.add(key);
			}
			item = item.left;
		}
	};
	cleanupYTextFormatting = (type) => {
		let res = 0;
		transact(type.doc, (transaction) => {
			let start = type._start;
			let end = type._start;
			let startAttributes = create$5();
			const currentAttributes = copy(startAttributes);
			while (end) {
				if (end.deleted === false) switch (end.content.constructor) {
					case ContentFormat:
						updateCurrentAttributes(currentAttributes, end.content);
						break;
					default:
						res += cleanupFormattingGap(transaction, start, end, startAttributes, currentAttributes);
						startAttributes = copy(currentAttributes);
						start = end;
						break;
				}
				end = end.right;
			}
		});
		return res;
	};
	cleanupYTextAfterTransaction = (transaction) => {
		/**
		* @type {Set<YText>}
		*/
		const needFullCleanup = /* @__PURE__ */ new Set();
		const doc = transaction.doc;
		for (const [client, afterClock] of transaction.afterState.entries()) {
			const clock = transaction.beforeState.get(client) || 0;
			if (afterClock === clock) continue;
			iterateStructs(transaction, doc.store.clients.get(client), clock, afterClock, (item) => {
				if (!item.deleted && item.content.constructor === ContentFormat && item.constructor !== GC) needFullCleanup.add(
					/** @type {any} */
					item.parent
				);
			});
		}
		transact(doc, (t) => {
			iterateDeletedStructs(transaction, transaction.deleteSet, (item) => {
				if (item instanceof GC || !item.parent._hasFormatting || needFullCleanup.has(item.parent)) return;
				const parent = item.parent;
				if (item.content.constructor === ContentFormat) needFullCleanup.add(parent);
				else cleanupContextlessFormattingGap(t, item);
			});
			for (const yText of needFullCleanup) cleanupYTextFormatting(yText);
		});
	};
	deleteText = (transaction, currPos, length) => {
		const startLength = length;
		const startAttrs = copy(currPos.currentAttributes);
		const start = currPos.right;
		while (length > 0 && currPos.right !== null) {
			if (currPos.right.deleted === false) switch (currPos.right.content.constructor) {
				case ContentType:
				case ContentEmbed:
				case ContentString:
					if (length < currPos.right.length) getItemCleanStart(transaction, createID(currPos.right.id.client, currPos.right.id.clock + length));
					length -= currPos.right.length;
					currPos.right.delete(transaction);
					break;
			}
			currPos.forward();
		}
		if (start) cleanupFormattingGap(transaction, start, currPos.right, startAttrs, currPos.currentAttributes);
		const parent = (currPos.left || currPos.right).parent;
		if (parent._searchMarker) updateMarkerChanges(parent._searchMarker, currPos.index, -startLength + length);
		return currPos;
	};
	YTextEvent = class extends YEvent {
		/**
		* @param {YText} ytext
		* @param {Transaction} transaction
		* @param {Set<any>} subs The keys that changed
		*/
		constructor(ytext, transaction, subs) {
			super(ytext, transaction);
			/**
			* Whether the children changed.
			* @type {Boolean}
			* @private
			*/
			this.childListChanged = false;
			/**
			* Set of all changed attributes.
			* @type {Set<string>}
			*/
			this.keysChanged = /* @__PURE__ */ new Set();
			subs.forEach((sub) => {
				if (sub === null) this.childListChanged = true;
				else this.keysChanged.add(sub);
			});
		}
		/**
		* @type {{added:Set<Item>,deleted:Set<Item>,keys:Map<string,{action:'add'|'update'|'delete',oldValue:any}>,delta:Array<{insert?:Array<any>|string, delete?:number, retain?:number}>}}
		*/
		get changes() {
			if (this._changes === null) this._changes = {
				keys: this.keys,
				delta: this.delta,
				added: /* @__PURE__ */ new Set(),
				deleted: /* @__PURE__ */ new Set()
			};
			return this._changes;
		}
		/**
		* Compute the changes in the delta format.
		* A {@link https://quilljs.com/docs/delta/|Quill Delta}) that represents the changes on the document.
		*
		* @type {Array<{insert?:string|object|AbstractType<any>, delete?:number, retain?:number, attributes?: Object<string,any>}>}
		*
		* @public
		*/
		get delta() {
			if (this._delta === null) {
				const y = this.target.doc;
				/**
				* @type {Array<{insert?:string|object|AbstractType<any>, delete?:number, retain?:number, attributes?: Object<string,any>}>}
				*/
				const delta = [];
				transact(y, (transaction) => {
					const currentAttributes = /* @__PURE__ */ new Map();
					const oldAttributes = /* @__PURE__ */ new Map();
					let item = this.target._start;
					/**
					* @type {string?}
					*/
					let action = null;
					/**
					* @type {Object<string,any>}
					*/
					const attributes = {};
					/**
					* @type {string|object}
					*/
					let insert = "";
					let retain = 0;
					let deleteLen = 0;
					const addOp = () => {
						if (action !== null) {
							/**
							* @type {any}
							*/
							let op = null;
							switch (action) {
								case "delete":
									if (deleteLen > 0) op = { delete: deleteLen };
									deleteLen = 0;
									break;
								case "insert":
									if (typeof insert === "object" || insert.length > 0) {
										op = { insert };
										if (currentAttributes.size > 0) {
											op.attributes = {};
											currentAttributes.forEach((value, key) => {
												if (value !== null) op.attributes[key] = value;
											});
										}
									}
									insert = "";
									break;
								case "retain":
									if (retain > 0) {
										op = { retain };
										if (!isEmpty(attributes)) op.attributes = assign({}, attributes);
									}
									retain = 0;
									break;
							}
							if (op) delta.push(op);
							action = null;
						}
					};
					while (item !== null) {
						switch (item.content.constructor) {
							case ContentType:
							case ContentEmbed:
								if (this.adds(item)) {
									if (!this.deletes(item)) {
										addOp();
										action = "insert";
										insert = item.content.getContent()[0];
										addOp();
									}
								} else if (this.deletes(item)) {
									if (action !== "delete") {
										addOp();
										action = "delete";
									}
									deleteLen += 1;
								} else if (!item.deleted) {
									if (action !== "retain") {
										addOp();
										action = "retain";
									}
									retain += 1;
								}
								break;
							case ContentString:
								if (this.adds(item)) {
									if (!this.deletes(item)) {
										if (action !== "insert") {
											addOp();
											action = "insert";
										}
										insert += item.content.str;
									}
								} else if (this.deletes(item)) {
									if (action !== "delete") {
										addOp();
										action = "delete";
									}
									deleteLen += item.length;
								} else if (!item.deleted) {
									if (action !== "retain") {
										addOp();
										action = "retain";
									}
									retain += item.length;
								}
								break;
							case ContentFormat: {
								const { key, value } = item.content;
								if (this.adds(item)) {
									if (!this.deletes(item)) {
										if (!equalAttrs(currentAttributes.get(key) ?? null, value)) {
											if (action === "retain") addOp();
											if (equalAttrs(value, oldAttributes.get(key) ?? null)) delete attributes[key];
											else attributes[key] = value;
										} else if (value !== null) item.delete(transaction);
									}
								} else if (this.deletes(item)) {
									oldAttributes.set(key, value);
									const curVal = currentAttributes.get(key) ?? null;
									if (!equalAttrs(curVal, value)) {
										if (action === "retain") addOp();
										attributes[key] = curVal;
									}
								} else if (!item.deleted) {
									oldAttributes.set(key, value);
									const attr = attributes[key];
									if (attr !== void 0) {
										if (!equalAttrs(attr, value)) {
											if (action === "retain") addOp();
											if (value === null) delete attributes[key];
											else attributes[key] = value;
										} else if (attr !== null) item.delete(transaction);
									}
								}
								if (!item.deleted) {
									if (action === "insert") addOp();
									updateCurrentAttributes(currentAttributes, item.content);
								}
								break;
							}
						}
						item = item.right;
					}
					addOp();
					while (delta.length > 0) {
						const lastOp = delta[delta.length - 1];
						if (lastOp.retain !== void 0 && lastOp.attributes === void 0) delta.pop();
						else break;
					}
				});
				this._delta = delta;
			}
			return this._delta;
		}
	};
	YText = class YText extends AbstractType {
		/**
		* @param {String} [string] The initial value of the YText.
		*/
		constructor(string) {
			super();
			/**
			* Array of pending operations on this type
			* @type {Array<function():void>?}
			*/
			this._pending = string !== void 0 ? [() => this.insert(0, string)] : [];
			/**
			* @type {Array<ArraySearchMarker>|null}
			*/
			this._searchMarker = [];
			/**
			* Whether this YText contains formatting attributes.
			* This flag is updated when a formatting item is integrated (see ContentFormat.integrate)
			*/
			this._hasFormatting = false;
		}
		/**
		* Number of characters of this text type.
		*
		* @type {number}
		*/
		get length() {
			this.doc ?? warnPrematureAccess();
			return this._length;
		}
		/**
		* @param {Doc} y
		* @param {Item} item
		*/
		_integrate(y, item) {
			super._integrate(y, item);
			try {
				/** @type {Array<function>} */ this._pending.forEach((f) => f());
			} catch (e) {
				console.error(e);
			}
			this._pending = null;
		}
		_copy() {
			return new YText();
		}
		/**
		* Makes a copy of this data type that can be included somewhere else.
		*
		* Note that the content is only readable _after_ it has been included somewhere in the Ydoc.
		*
		* @return {YText}
		*/
		clone() {
			const text = new YText();
			text.applyDelta(this.toDelta());
			return text;
		}
		/**
		* Creates YTextEvent and calls observers.
		*
		* @param {Transaction} transaction
		* @param {Set<null|string>} parentSubs Keys changed on this type. `null` if list was modified.
		*/
		_callObserver(transaction, parentSubs) {
			super._callObserver(transaction, parentSubs);
			const event = new YTextEvent(this, transaction, parentSubs);
			callTypeObservers(this, transaction, event);
			if (!transaction.local && this._hasFormatting) transaction._needFormattingCleanup = true;
		}
		/**
		* Returns the unformatted string representation of this YText type.
		*
		* @public
		*/
		toString() {
			this.doc ?? warnPrematureAccess();
			let str = "";
			/**
			* @type {Item|null}
			*/
			let n = this._start;
			while (n !== null) {
				if (!n.deleted && n.countable && n.content.constructor === ContentString) str += n.content.str;
				n = n.right;
			}
			return str;
		}
		/**
		* Returns the unformatted string representation of this YText type.
		*
		* @return {string}
		* @public
		*/
		toJSON() {
			return this.toString();
		}
		/**
		* Apply a {@link Delta} on this shared YText type.
		*
		* @param {Array<any>} delta The changes to apply on this element.
		* @param {object}  opts
		* @param {boolean} [opts.sanitize] Sanitize input delta. Removes ending newlines if set to true.
		*
		*
		* @public
		*/
		applyDelta(delta, { sanitize = true } = {}) {
			if (this.doc !== null) transact(this.doc, (transaction) => {
				const currPos = new ItemTextListPosition(null, this._start, 0, /* @__PURE__ */ new Map());
				for (let i = 0; i < delta.length; i++) {
					const op = delta[i];
					if (op.insert !== void 0) {
						const ins = !sanitize && typeof op.insert === "string" && i === delta.length - 1 && currPos.right === null && op.insert.slice(-1) === "\n" ? op.insert.slice(0, -1) : op.insert;
						if (typeof ins !== "string" || ins.length > 0) insertText(transaction, this, currPos, ins, op.attributes || {});
					} else if (op.retain !== void 0) formatText(transaction, this, currPos, op.retain, op.attributes || {});
					else if (op.delete !== void 0) deleteText(transaction, currPos, op.delete);
				}
			});
			else
 /** @type {Array<function>} */ this._pending.push(() => this.applyDelta(delta));
		}
		/**
		* Returns the Delta representation of this YText type.
		*
		* @param {Snapshot} [snapshot]
		* @param {Snapshot} [prevSnapshot]
		* @param {function('removed' | 'added', ID):any} [computeYChange]
		* @return {any} The Delta representation of this type.
		*
		* @public
		*/
		toDelta(snapshot, prevSnapshot, computeYChange) {
			this.doc ?? warnPrematureAccess();
			/**
			* @type{Array<any>}
			*/
			const ops = [];
			const currentAttributes = /* @__PURE__ */ new Map();
			const doc = this.doc;
			let str = "";
			let n = this._start;
			function packStr() {
				if (str.length > 0) {
					/**
					* @type {Object<string,any>}
					*/
					const attributes = {};
					let addAttributes = false;
					currentAttributes.forEach((value, key) => {
						addAttributes = true;
						attributes[key] = value;
					});
					/**
					* @type {Object<string,any>}
					*/
					const op = { insert: str };
					if (addAttributes) op.attributes = attributes;
					ops.push(op);
					str = "";
				}
			}
			const computeDelta = () => {
				while (n !== null) {
					if (isVisible(n, snapshot) || prevSnapshot !== void 0 && isVisible(n, prevSnapshot)) switch (n.content.constructor) {
						case ContentString: {
							const cur = currentAttributes.get("ychange");
							if (snapshot !== void 0 && !isVisible(n, snapshot)) {
								if (cur === void 0 || cur.user !== n.id.client || cur.type !== "removed") {
									packStr();
									currentAttributes.set("ychange", computeYChange ? computeYChange("removed", n.id) : { type: "removed" });
								}
							} else if (prevSnapshot !== void 0 && !isVisible(n, prevSnapshot)) {
								if (cur === void 0 || cur.user !== n.id.client || cur.type !== "added") {
									packStr();
									currentAttributes.set("ychange", computeYChange ? computeYChange("added", n.id) : { type: "added" });
								}
							} else if (cur !== void 0) {
								packStr();
								currentAttributes.delete("ychange");
							}
							str += n.content.str;
							break;
						}
						case ContentType:
						case ContentEmbed: {
							packStr();
							/**
							* @type {Object<string,any>}
							*/
							const op = { insert: n.content.getContent()[0] };
							if (currentAttributes.size > 0) {
								const attrs = {};
								op.attributes = attrs;
								currentAttributes.forEach((value, key) => {
									attrs[key] = value;
								});
							}
							ops.push(op);
							break;
						}
						case ContentFormat:
							if (isVisible(n, snapshot)) {
								packStr();
								updateCurrentAttributes(currentAttributes, n.content);
							}
							break;
					}
					n = n.right;
				}
				packStr();
			};
			if (snapshot || prevSnapshot) transact(doc, (transaction) => {
				if (snapshot) splitSnapshotAffectedStructs(transaction, snapshot);
				if (prevSnapshot) splitSnapshotAffectedStructs(transaction, prevSnapshot);
				computeDelta();
			}, "cleanup");
			else computeDelta();
			return ops;
		}
		/**
		* Insert text at a given index.
		*
		* @param {number} index The index at which to start inserting.
		* @param {String} text The text to insert at the specified position.
		* @param {TextAttributes} [attributes] Optionally define some formatting
		*                                    information to apply on the inserted
		*                                    Text.
		* @public
		*/
		insert(index, text, attributes) {
			if (text.length <= 0) return;
			const y = this.doc;
			if (y !== null) transact(y, (transaction) => {
				const pos = findPosition(transaction, this, index, !attributes);
				if (!attributes) {
					attributes = {};
					pos.currentAttributes.forEach((v, k) => {
						attributes[k] = v;
					});
				}
				insertText(transaction, this, pos, text, attributes);
			});
			else
 /** @type {Array<function>} */ this._pending.push(() => this.insert(index, text, attributes));
		}
		/**
		* Inserts an embed at a index.
		*
		* @param {number} index The index to insert the embed at.
		* @param {Object | AbstractType<any>} embed The Object that represents the embed.
		* @param {TextAttributes} [attributes] Attribute information to apply on the
		*                                    embed
		*
		* @public
		*/
		insertEmbed(index, embed, attributes) {
			const y = this.doc;
			if (y !== null) transact(y, (transaction) => {
				const pos = findPosition(transaction, this, index, !attributes);
				insertText(transaction, this, pos, embed, attributes || {});
			});
			else
 /** @type {Array<function>} */ this._pending.push(() => this.insertEmbed(index, embed, attributes || {}));
		}
		/**
		* Deletes text starting from an index.
		*
		* @param {number} index Index at which to start deleting.
		* @param {number} length The number of characters to remove. Defaults to 1.
		*
		* @public
		*/
		delete(index, length) {
			if (length === 0) return;
			const y = this.doc;
			if (y !== null) transact(y, (transaction) => {
				deleteText(transaction, findPosition(transaction, this, index, true), length);
			});
			else
 /** @type {Array<function>} */ this._pending.push(() => this.delete(index, length));
		}
		/**
		* Assigns properties to a range of text.
		*
		* @param {number} index The position where to start formatting.
		* @param {number} length The amount of characters to assign properties to.
		* @param {TextAttributes} attributes Attribute information to apply on the
		*                                    text.
		*
		* @public
		*/
		format(index, length, attributes) {
			if (length === 0) return;
			const y = this.doc;
			if (y !== null) transact(y, (transaction) => {
				const pos = findPosition(transaction, this, index, false);
				if (pos.right === null) return;
				formatText(transaction, this, pos, length, attributes);
			});
			else
 /** @type {Array<function>} */ this._pending.push(() => this.format(index, length, attributes));
		}
		/**
		* Removes an attribute.
		*
		* @note Xml-Text nodes don't have attributes. You can use this feature to assign properties to complete text-blocks.
		*
		* @param {String} attributeName The attribute name that is to be removed.
		*
		* @public
		*/
		removeAttribute(attributeName) {
			if (this.doc !== null) transact(this.doc, (transaction) => {
				typeMapDelete(transaction, this, attributeName);
			});
			else
 /** @type {Array<function>} */ this._pending.push(() => this.removeAttribute(attributeName));
		}
		/**
		* Sets or updates an attribute.
		*
		* @note Xml-Text nodes don't have attributes. You can use this feature to assign properties to complete text-blocks.
		*
		* @param {String} attributeName The attribute name that is to be set.
		* @param {any} attributeValue The attribute value that is to be set.
		*
		* @public
		*/
		setAttribute(attributeName, attributeValue) {
			if (this.doc !== null) transact(this.doc, (transaction) => {
				typeMapSet(transaction, this, attributeName, attributeValue);
			});
			else
 /** @type {Array<function>} */ this._pending.push(() => this.setAttribute(attributeName, attributeValue));
		}
		/**
		* Returns an attribute value that belongs to the attribute name.
		*
		* @note Xml-Text nodes don't have attributes. You can use this feature to assign properties to complete text-blocks.
		*
		* @param {String} attributeName The attribute name that identifies the
		*                               queried value.
		* @return {any} The queried attribute value.
		*
		* @public
		*/
		getAttribute(attributeName) {
			return typeMapGet(this, attributeName);
		}
		/**
		* Returns all attribute name/value pairs in a JSON Object.
		*
		* @note Xml-Text nodes don't have attributes. You can use this feature to assign properties to complete text-blocks.
		*
		* @return {Object<string, any>} A JSON Object that describes the attributes.
		*
		* @public
		*/
		getAttributes() {
			return typeMapGetAll(this);
		}
		/**
		* @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
		*/
		_write(encoder) {
			encoder.writeTypeRef(YTextRefID);
		}
	};
	readYText = (_decoder) => new YText();
	YXmlTreeWalker = class {
		/**
		* @param {YXmlFragment | YXmlElement} root
		* @param {function(AbstractType<any>):boolean} [f]
		*/
		constructor(root, f = () => true) {
			this._filter = f;
			this._root = root;
			/**
			* @type {Item}
			*/
			this._currentNode = root._start;
			this._firstCall = true;
			root.doc ?? warnPrematureAccess();
		}
		[Symbol.iterator]() {
			return this;
		}
		/**
		* Get the next node.
		*
		* @return {IteratorResult<YXmlElement|YXmlText|YXmlHook>} The next node.
		*
		* @public
		*/
		next() {
			/**
			* @type {Item|null}
			*/
			let n = this._currentNode;
			let type = n && n.content && n.content.type;
			if (n !== null && (!this._firstCall || n.deleted || !this._filter(type))) do {
				type = n.content.type;
				if (!n.deleted && (type.constructor === YXmlElement || type.constructor === YXmlFragment) && type._start !== null) n = type._start;
				else while (n !== null) {
					/**
					* @type {Item | null}
					*/
					const nxt = n.next;
					if (nxt !== null) {
						n = nxt;
						break;
					} else if (n.parent === this._root) n = null;
					else n = n.parent._item;
				}
			} while (n !== null && (n.deleted || !this._filter(
				/** @type {ContentType} */
				n.content.type
			)));
			this._firstCall = false;
			if (n === null) return {
				value: void 0,
				done: true
			};
			this._currentNode = n;
			return {
				value: n.content.type,
				done: false
			};
		}
	};
	YXmlFragment = class YXmlFragment extends AbstractType {
		constructor() {
			super();
			/**
			* @type {Array<any>|null}
			*/
			this._prelimContent = [];
		}
		/**
		* @type {YXmlElement|YXmlText|null}
		*/
		get firstChild() {
			const first = this._first;
			return first ? first.content.getContent()[0] : null;
		}
		/**
		* Integrate this type into the Yjs instance.
		*
		* * Save this struct in the os
		* * This type is sent to other client
		* * Observer functions are fired
		*
		* @param {Doc} y The Yjs instance
		* @param {Item} item
		*/
		_integrate(y, item) {
			super._integrate(y, item);
			this.insert(0, this._prelimContent);
			this._prelimContent = null;
		}
		_copy() {
			return new YXmlFragment();
		}
		/**
		* Makes a copy of this data type that can be included somewhere else.
		*
		* Note that the content is only readable _after_ it has been included somewhere in the Ydoc.
		*
		* @return {YXmlFragment}
		*/
		clone() {
			const el = new YXmlFragment();
			el.insert(0, this.toArray().map((item) => item instanceof AbstractType ? item.clone() : item));
			return el;
		}
		get length() {
			this.doc ?? warnPrematureAccess();
			return this._prelimContent === null ? this._length : this._prelimContent.length;
		}
		/**
		* Create a subtree of childNodes.
		*
		* @example
		* const walker = elem.createTreeWalker(dom => dom.nodeName === 'div')
		* for (let node in walker) {
		*   // `node` is a div node
		*   nop(node)
		* }
		*
		* @param {function(AbstractType<any>):boolean} filter Function that is called on each child element and
		*                          returns a Boolean indicating whether the child
		*                          is to be included in the subtree.
		* @return {YXmlTreeWalker} A subtree and a position within it.
		*
		* @public
		*/
		createTreeWalker(filter) {
			return new YXmlTreeWalker(this, filter);
		}
		/**
		* Returns the first YXmlElement that matches the query.
		* Similar to DOM's {@link querySelector}.
		*
		* Query support:
		*   - tagname
		* TODO:
		*   - id
		*   - attribute
		*
		* @param {CSS_Selector} query The query on the children.
		* @return {YXmlElement|YXmlText|YXmlHook|null} The first element that matches the query or null.
		*
		* @public
		*/
		querySelector(query) {
			query = query.toUpperCase();
			const next = new YXmlTreeWalker(this, (element) => element.nodeName && element.nodeName.toUpperCase() === query).next();
			if (next.done) return null;
			else return next.value;
		}
		/**
		* Returns all YXmlElements that match the query.
		* Similar to Dom's {@link querySelectorAll}.
		*
		* @todo Does not yet support all queries. Currently only query by tagName.
		*
		* @param {CSS_Selector} query The query on the children
		* @return {Array<YXmlElement|YXmlText|YXmlHook|null>} The elements that match this query.
		*
		* @public
		*/
		querySelectorAll(query) {
			query = query.toUpperCase();
			return from(new YXmlTreeWalker(this, (element) => element.nodeName && element.nodeName.toUpperCase() === query));
		}
		/**
		* Creates YXmlEvent and calls observers.
		*
		* @param {Transaction} transaction
		* @param {Set<null|string>} parentSubs Keys changed on this type. `null` if list was modified.
		*/
		_callObserver(transaction, parentSubs) {
			callTypeObservers(this, transaction, new YXmlEvent(this, parentSubs, transaction));
		}
		/**
		* Get the string representation of all the children of this YXmlFragment.
		*
		* @return {string} The string representation of all children.
		*/
		toString() {
			return typeListMap(this, (xml) => xml.toString()).join("");
		}
		/**
		* @return {string}
		*/
		toJSON() {
			return this.toString();
		}
		/**
		* Creates a Dom Element that mirrors this YXmlElement.
		*
		* @param {Document} [_document=document] The document object (you must define
		*                                        this when calling this method in
		*                                        nodejs)
		* @param {Object<string, any>} [hooks={}] Optional property to customize how hooks
		*                                             are presented in the DOM
		* @param {any} [binding] You should not set this property. This is
		*                               used if DomBinding wants to create a
		*                               association to the created DOM type.
		* @return {Node} The {@link https://developer.mozilla.org/en-US/docs/Web/API/Element|Dom Element}
		*
		* @public
		*/
		toDOM(_document = document, hooks = {}, binding) {
			const fragment = _document.createDocumentFragment();
			if (binding !== void 0) binding._createAssociation(fragment, this);
			typeListForEach(this, (xmlType) => {
				fragment.insertBefore(xmlType.toDOM(_document, hooks, binding), null);
			});
			return fragment;
		}
		/**
		* Inserts new content at an index.
		*
		* @example
		*  // Insert character 'a' at position 0
		*  xml.insert(0, [new Y.XmlText('text')])
		*
		* @param {number} index The index to insert content at
		* @param {Array<YXmlElement|YXmlText>} content The array of content
		*/
		insert(index, content) {
			if (this.doc !== null) transact(this.doc, (transaction) => {
				typeListInsertGenerics(transaction, this, index, content);
			});
			else this._prelimContent.splice(index, 0, ...content);
		}
		/**
		* Inserts new content at an index.
		*
		* @example
		*  // Insert character 'a' at position 0
		*  xml.insert(0, [new Y.XmlText('text')])
		*
		* @param {null|Item|YXmlElement|YXmlText} ref The index to insert content at
		* @param {Array<YXmlElement|YXmlText>} content The array of content
		*/
		insertAfter(ref, content) {
			if (this.doc !== null) transact(this.doc, (transaction) => {
				const refItem = ref && ref instanceof AbstractType ? ref._item : ref;
				typeListInsertGenericsAfter(transaction, this, refItem, content);
			});
			else {
				const pc = this._prelimContent;
				const index = ref === null ? 0 : pc.findIndex((el) => el === ref) + 1;
				if (index === 0 && ref !== null) throw create$3("Reference item not found");
				pc.splice(index, 0, ...content);
			}
		}
		/**
		* Deletes elements starting from an index.
		*
		* @param {number} index Index at which to start deleting elements
		* @param {number} [length=1] The number of elements to remove. Defaults to 1.
		*/
		delete(index, length = 1) {
			if (this.doc !== null) transact(this.doc, (transaction) => {
				typeListDelete(transaction, this, index, length);
			});
			else this._prelimContent.splice(index, length);
		}
		/**
		* Transforms this YArray to a JavaScript Array.
		*
		* @return {Array<YXmlElement|YXmlText|YXmlHook>}
		*/
		toArray() {
			return typeListToArray(this);
		}
		/**
		* Appends content to this YArray.
		*
		* @param {Array<YXmlElement|YXmlText>} content Array of content to append.
		*/
		push(content) {
			this.insert(this.length, content);
		}
		/**
		* Prepends content to this YArray.
		*
		* @param {Array<YXmlElement|YXmlText>} content Array of content to prepend.
		*/
		unshift(content) {
			this.insert(0, content);
		}
		/**
		* Returns the i-th element from a YArray.
		*
		* @param {number} index The index of the element to return from the YArray
		* @return {YXmlElement|YXmlText}
		*/
		get(index) {
			return typeListGet(this, index);
		}
		/**
		* Returns a portion of this YXmlFragment into a JavaScript Array selected
		* from start to end (end not included).
		*
		* @param {number} [start]
		* @param {number} [end]
		* @return {Array<YXmlElement|YXmlText>}
		*/
		slice(start = 0, end = this.length) {
			return typeListSlice(this, start, end);
		}
		/**
		* Executes a provided function on once on every child element.
		*
		* @param {function(YXmlElement|YXmlText,number, typeof self):void} f A function to execute on every element of this YArray.
		*/
		forEach(f) {
			typeListForEach(this, f);
		}
		/**
		* Transform the properties of this type to binary and write it to an
		* BinaryEncoder.
		*
		* This is called when this Item is sent to a remote peer.
		*
		* @param {UpdateEncoderV1 | UpdateEncoderV2} encoder The encoder to write data to.
		*/
		_write(encoder) {
			encoder.writeTypeRef(YXmlFragmentRefID);
		}
	};
	readYXmlFragment = (_decoder) => new YXmlFragment();
	YXmlElement = class YXmlElement extends YXmlFragment {
		constructor(nodeName = "UNDEFINED") {
			super();
			this.nodeName = nodeName;
			/**
			* @type {Map<string, any>|null}
			*/
			this._prelimAttrs = /* @__PURE__ */ new Map();
		}
		/**
		* @type {YXmlElement|YXmlText|null}
		*/
		get nextSibling() {
			const n = this._item ? this._item.next : null;
			return n ? n.content.type : null;
		}
		/**
		* @type {YXmlElement|YXmlText|null}
		*/
		get prevSibling() {
			const n = this._item ? this._item.prev : null;
			return n ? n.content.type : null;
		}
		/**
		* Integrate this type into the Yjs instance.
		*
		* * Save this struct in the os
		* * This type is sent to other client
		* * Observer functions are fired
		*
		* @param {Doc} y The Yjs instance
		* @param {Item} item
		*/
		_integrate(y, item) {
			super._integrate(y, item);
			this._prelimAttrs.forEach((value, key) => {
				this.setAttribute(key, value);
			});
			this._prelimAttrs = null;
		}
		/**
		* Creates an Item with the same effect as this Item (without position effect)
		*
		* @return {YXmlElement}
		*/
		_copy() {
			return new YXmlElement(this.nodeName);
		}
		/**
		* Makes a copy of this data type that can be included somewhere else.
		*
		* Note that the content is only readable _after_ it has been included somewhere in the Ydoc.
		*
		* @return {YXmlElement<KV>}
		*/
		clone() {
			/**
			* @type {YXmlElement<KV>}
			*/
			const el = new YXmlElement(this.nodeName);
			const attrs = this.getAttributes();
			forEach(attrs, (value, key) => {
				el.setAttribute(key, value);
			});
			el.insert(0, this.toArray().map((v) => v instanceof AbstractType ? v.clone() : v));
			return el;
		}
		/**
		* Returns the XML serialization of this YXmlElement.
		* The attributes are ordered by attribute-name, so you can easily use this
		* method to compare YXmlElements
		*
		* @return {string} The string representation of this type.
		*
		* @public
		*/
		toString() {
			const attrs = this.getAttributes();
			const stringBuilder = [];
			const keys = [];
			for (const key in attrs) keys.push(key);
			keys.sort();
			const keysLen = keys.length;
			for (let i = 0; i < keysLen; i++) {
				const key = keys[i];
				stringBuilder.push(key + "=\"" + attrs[key] + "\"");
			}
			const nodeName = this.nodeName.toLocaleLowerCase();
			return `<${nodeName}${stringBuilder.length > 0 ? " " + stringBuilder.join(" ") : ""}>${super.toString()}</${nodeName}>`;
		}
		/**
		* Removes an attribute from this YXmlElement.
		*
		* @param {string} attributeName The attribute name that is to be removed.
		*
		* @public
		*/
		removeAttribute(attributeName) {
			if (this.doc !== null) transact(this.doc, (transaction) => {
				typeMapDelete(transaction, this, attributeName);
			});
			else
 /** @type {Map<string,any>} */ this._prelimAttrs.delete(attributeName);
		}
		/**
		* Sets or updates an attribute.
		*
		* @template {keyof KV & string} KEY
		*
		* @param {KEY} attributeName The attribute name that is to be set.
		* @param {KV[KEY]} attributeValue The attribute value that is to be set.
		*
		* @public
		*/
		setAttribute(attributeName, attributeValue) {
			if (this.doc !== null) transact(this.doc, (transaction) => {
				typeMapSet(transaction, this, attributeName, attributeValue);
			});
			else
 /** @type {Map<string, any>} */ this._prelimAttrs.set(attributeName, attributeValue);
		}
		/**
		* Returns an attribute value that belongs to the attribute name.
		*
		* @template {keyof KV & string} KEY
		*
		* @param {KEY} attributeName The attribute name that identifies the
		*                               queried value.
		* @return {KV[KEY]|undefined} The queried attribute value.
		*
		* @public
		*/
		getAttribute(attributeName) {
			return typeMapGet(this, attributeName);
		}
		/**
		* Returns whether an attribute exists
		*
		* @param {string} attributeName The attribute name to check for existence.
		* @return {boolean} whether the attribute exists.
		*
		* @public
		*/
		hasAttribute(attributeName) {
			return typeMapHas(this, attributeName);
		}
		/**
		* Returns all attribute name/value pairs in a JSON Object.
		*
		* @param {Snapshot} [snapshot]
		* @return {{ [Key in Extract<keyof KV,string>]?: KV[Key]}} A JSON Object that describes the attributes.
		*
		* @public
		*/
		getAttributes(snapshot) {
			return snapshot ? typeMapGetAllSnapshot(this, snapshot) : typeMapGetAll(this);
		}
		/**
		* Creates a Dom Element that mirrors this YXmlElement.
		*
		* @param {Document} [_document=document] The document object (you must define
		*                                        this when calling this method in
		*                                        nodejs)
		* @param {Object<string, any>} [hooks={}] Optional property to customize how hooks
		*                                             are presented in the DOM
		* @param {any} [binding] You should not set this property. This is
		*                               used if DomBinding wants to create a
		*                               association to the created DOM type.
		* @return {Node} The {@link https://developer.mozilla.org/en-US/docs/Web/API/Element|Dom Element}
		*
		* @public
		*/
		toDOM(_document = document, hooks = {}, binding) {
			const dom = _document.createElement(this.nodeName);
			const attrs = this.getAttributes();
			for (const key in attrs) {
				const value = attrs[key];
				if (typeof value === "string") dom.setAttribute(key, value);
			}
			typeListForEach(this, (yxml) => {
				dom.appendChild(yxml.toDOM(_document, hooks, binding));
			});
			if (binding !== void 0) binding._createAssociation(dom, this);
			return dom;
		}
		/**
		* Transform the properties of this type to binary and write it to an
		* BinaryEncoder.
		*
		* This is called when this Item is sent to a remote peer.
		*
		* @param {UpdateEncoderV1 | UpdateEncoderV2} encoder The encoder to write data to.
		*/
		_write(encoder) {
			encoder.writeTypeRef(YXmlElementRefID);
			encoder.writeKey(this.nodeName);
		}
	};
	readYXmlElement = (decoder) => new YXmlElement(decoder.readKey());
	YXmlEvent = class extends YEvent {
		/**
		* @param {YXmlElement|YXmlText|YXmlFragment} target The target on which the event is created.
		* @param {Set<string|null>} subs The set of changed attributes. `null` is included if the
		*                   child list changed.
		* @param {Transaction} transaction The transaction instance with which the
		*                                  change was created.
		*/
		constructor(target, subs, transaction) {
			super(target, transaction);
			/**
			* Whether the children changed.
			* @type {Boolean}
			* @private
			*/
			this.childListChanged = false;
			/**
			* Set of all changed attributes.
			* @type {Set<string>}
			*/
			this.attributesChanged = /* @__PURE__ */ new Set();
			subs.forEach((sub) => {
				if (sub === null) this.childListChanged = true;
				else this.attributesChanged.add(sub);
			});
		}
	};
	YXmlHook = class YXmlHook extends YMap {
		/**
		* @param {string} hookName nodeName of the Dom Node.
		*/
		constructor(hookName) {
			super();
			/**
			* @type {string}
			*/
			this.hookName = hookName;
		}
		/**
		* Creates an Item with the same effect as this Item (without position effect)
		*/
		_copy() {
			return new YXmlHook(this.hookName);
		}
		/**
		* Makes a copy of this data type that can be included somewhere else.
		*
		* Note that the content is only readable _after_ it has been included somewhere in the Ydoc.
		*
		* @return {YXmlHook}
		*/
		clone() {
			const el = new YXmlHook(this.hookName);
			this.forEach((value, key) => {
				el.set(key, value);
			});
			return el;
		}
		/**
		* Creates a Dom Element that mirrors this YXmlElement.
		*
		* @param {Document} [_document=document] The document object (you must define
		*                                        this when calling this method in
		*                                        nodejs)
		* @param {Object.<string, any>} [hooks] Optional property to customize how hooks
		*                                             are presented in the DOM
		* @param {any} [binding] You should not set this property. This is
		*                               used if DomBinding wants to create a
		*                               association to the created DOM type
		* @return {Element} The {@link https://developer.mozilla.org/en-US/docs/Web/API/Element|Dom Element}
		*
		* @public
		*/
		toDOM(_document = document, hooks = {}, binding) {
			const hook = hooks[this.hookName];
			let dom;
			if (hook !== void 0) dom = hook.createDom(this);
			else dom = document.createElement(this.hookName);
			dom.setAttribute("data-yjs-hook", this.hookName);
			if (binding !== void 0) binding._createAssociation(dom, this);
			return dom;
		}
		/**
		* Transform the properties of this type to binary and write it to an
		* BinaryEncoder.
		*
		* This is called when this Item is sent to a remote peer.
		*
		* @param {UpdateEncoderV1 | UpdateEncoderV2} encoder The encoder to write data to.
		*/
		_write(encoder) {
			encoder.writeTypeRef(YXmlHookRefID);
			encoder.writeKey(this.hookName);
		}
	};
	readYXmlHook = (decoder) => new YXmlHook(decoder.readKey());
	YXmlText = class YXmlText extends YText {
		/**
		* @type {YXmlElement|YXmlText|null}
		*/
		get nextSibling() {
			const n = this._item ? this._item.next : null;
			return n ? n.content.type : null;
		}
		/**
		* @type {YXmlElement|YXmlText|null}
		*/
		get prevSibling() {
			const n = this._item ? this._item.prev : null;
			return n ? n.content.type : null;
		}
		_copy() {
			return new YXmlText();
		}
		/**
		* Makes a copy of this data type that can be included somewhere else.
		*
		* Note that the content is only readable _after_ it has been included somewhere in the Ydoc.
		*
		* @return {YXmlText}
		*/
		clone() {
			const text = new YXmlText();
			text.applyDelta(this.toDelta());
			return text;
		}
		/**
		* Creates a Dom Element that mirrors this YXmlText.
		*
		* @param {Document} [_document=document] The document object (you must define
		*                                        this when calling this method in
		*                                        nodejs)
		* @param {Object<string, any>} [hooks] Optional property to customize how hooks
		*                                             are presented in the DOM
		* @param {any} [binding] You should not set this property. This is
		*                               used if DomBinding wants to create a
		*                               association to the created DOM type.
		* @return {Text} The {@link https://developer.mozilla.org/en-US/docs/Web/API/Element|Dom Element}
		*
		* @public
		*/
		toDOM(_document = document, hooks, binding) {
			const dom = _document.createTextNode(this.toString());
			if (binding !== void 0) binding._createAssociation(dom, this);
			return dom;
		}
		toString() {
			return this.toDelta().map((delta) => {
				const nestedNodes = [];
				for (const nodeName in delta.attributes) {
					const attrs = [];
					for (const key in delta.attributes[nodeName]) attrs.push({
						key,
						value: delta.attributes[nodeName][key]
					});
					attrs.sort((a, b) => a.key < b.key ? -1 : 1);
					nestedNodes.push({
						nodeName,
						attrs
					});
				}
				nestedNodes.sort((a, b) => a.nodeName < b.nodeName ? -1 : 1);
				let str = "";
				for (let i = 0; i < nestedNodes.length; i++) {
					const node = nestedNodes[i];
					str += `<${node.nodeName}`;
					for (let j = 0; j < node.attrs.length; j++) {
						const attr = node.attrs[j];
						str += ` ${attr.key}="${attr.value}"`;
					}
					str += ">";
				}
				str += delta.insert;
				for (let i = nestedNodes.length - 1; i >= 0; i--) str += `</${nestedNodes[i].nodeName}>`;
				return str;
			}).join("");
		}
		/**
		* @return {string}
		*/
		toJSON() {
			return this.toString();
		}
		/**
		* @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
		*/
		_write(encoder) {
			encoder.writeTypeRef(YXmlTextRefID);
		}
	};
	readYXmlText = (decoder) => new YXmlText();
	AbstractStruct = class {
		/**
		* @param {ID} id
		* @param {number} length
		*/
		constructor(id, length) {
			this.id = id;
			this.length = length;
		}
		/**
		* @type {boolean}
		*/
		get deleted() {
			throw methodUnimplemented();
		}
		/**
		* Merge this struct with the item to the right.
		* This method is already assuming that `this.id.clock + this.length === this.id.clock`.
		* Also this method does *not* remove right from StructStore!
		* @param {AbstractStruct} right
		* @return {boolean} whether this merged with right
		*/
		mergeWith(right) {
			return false;
		}
		/**
		* @param {UpdateEncoderV1 | UpdateEncoderV2} encoder The encoder to write data to.
		* @param {number} offset
		* @param {number} encodingRef
		*/
		write(encoder, offset, encodingRef) {
			throw methodUnimplemented();
		}
		/**
		* @param {Transaction} transaction
		* @param {number} offset
		*/
		integrate(transaction, offset) {
			throw methodUnimplemented();
		}
	};
	structGCRefNumber = 0;
	GC = class extends AbstractStruct {
		get deleted() {
			return true;
		}
		delete() {}
		/**
		* @param {GC} right
		* @return {boolean}
		*/
		mergeWith(right) {
			if (this.constructor !== right.constructor) return false;
			this.length += right.length;
			return true;
		}
		/**
		* @param {Transaction} transaction
		* @param {number} offset
		*/
		integrate(transaction, offset) {
			if (offset > 0) {
				this.id.clock += offset;
				this.length -= offset;
			}
			addStruct(transaction.doc.store, this);
		}
		/**
		* @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
		* @param {number} offset
		*/
		write(encoder, offset) {
			encoder.writeInfo(structGCRefNumber);
			encoder.writeLen(this.length - offset);
		}
		/**
		* @param {Transaction} transaction
		* @param {StructStore} store
		* @return {null | number}
		*/
		getMissing(transaction, store) {
			return null;
		}
	};
	ContentBinary = class ContentBinary {
		/**
		* @param {Uint8Array} content
		*/
		constructor(content) {
			this.content = content;
		}
		/**
		* @return {number}
		*/
		getLength() {
			return 1;
		}
		/**
		* @return {Array<any>}
		*/
		getContent() {
			return [this.content];
		}
		/**
		* @return {boolean}
		*/
		isCountable() {
			return true;
		}
		/**
		* @return {ContentBinary}
		*/
		copy() {
			return new ContentBinary(this.content);
		}
		/**
		* @param {number} offset
		* @return {ContentBinary}
		*/
		splice(offset) {
			throw methodUnimplemented();
		}
		/**
		* @param {ContentBinary} right
		* @return {boolean}
		*/
		mergeWith(right) {
			return false;
		}
		/**
		* @param {Transaction} transaction
		* @param {Item} item
		*/
		integrate(transaction, item) {}
		/**
		* @param {Transaction} transaction
		*/
		delete(transaction) {}
		/**
		* @param {StructStore} store
		*/
		gc(store) {}
		/**
		* @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
		* @param {number} offset
		*/
		write(encoder, offset) {
			encoder.writeBuf(this.content);
		}
		/**
		* @return {number}
		*/
		getRef() {
			return 3;
		}
	};
	readContentBinary = (decoder) => new ContentBinary(decoder.readBuf());
	ContentDeleted = class ContentDeleted {
		/**
		* @param {number} len
		*/
		constructor(len) {
			this.len = len;
		}
		/**
		* @return {number}
		*/
		getLength() {
			return this.len;
		}
		/**
		* @return {Array<any>}
		*/
		getContent() {
			return [];
		}
		/**
		* @return {boolean}
		*/
		isCountable() {
			return false;
		}
		/**
		* @return {ContentDeleted}
		*/
		copy() {
			return new ContentDeleted(this.len);
		}
		/**
		* @param {number} offset
		* @return {ContentDeleted}
		*/
		splice(offset) {
			const right = new ContentDeleted(this.len - offset);
			this.len = offset;
			return right;
		}
		/**
		* @param {ContentDeleted} right
		* @return {boolean}
		*/
		mergeWith(right) {
			this.len += right.len;
			return true;
		}
		/**
		* @param {Transaction} transaction
		* @param {Item} item
		*/
		integrate(transaction, item) {
			addToDeleteSet(transaction.deleteSet, item.id.client, item.id.clock, this.len);
			item.markDeleted();
		}
		/**
		* @param {Transaction} transaction
		*/
		delete(transaction) {}
		/**
		* @param {StructStore} store
		*/
		gc(store) {}
		/**
		* @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
		* @param {number} offset
		*/
		write(encoder, offset) {
			encoder.writeLen(this.len - offset);
		}
		/**
		* @return {number}
		*/
		getRef() {
			return 1;
		}
	};
	readContentDeleted = (decoder) => new ContentDeleted(decoder.readLen());
	createDocFromOpts = (guid, opts) => new Doc({
		guid,
		...opts,
		shouldLoad: opts.shouldLoad || opts.autoLoad || false
	});
	ContentDoc = class ContentDoc {
		/**
		* @param {Doc} doc
		*/
		constructor(doc) {
			if (doc._item) console.error("This document was already integrated as a sub-document. You should create a second instance instead with the same guid.");
			/**
			* @type {Doc}
			*/
			this.doc = doc;
			/**
			* @type {any}
			*/
			const opts = {};
			this.opts = opts;
			if (!doc.gc) opts.gc = false;
			if (doc.autoLoad) opts.autoLoad = true;
			if (doc.meta !== null) opts.meta = doc.meta;
		}
		/**
		* @return {number}
		*/
		getLength() {
			return 1;
		}
		/**
		* @return {Array<any>}
		*/
		getContent() {
			return [this.doc];
		}
		/**
		* @return {boolean}
		*/
		isCountable() {
			return true;
		}
		/**
		* @return {ContentDoc}
		*/
		copy() {
			return new ContentDoc(createDocFromOpts(this.doc.guid, this.opts));
		}
		/**
		* @param {number} offset
		* @return {ContentDoc}
		*/
		splice(offset) {
			throw methodUnimplemented();
		}
		/**
		* @param {ContentDoc} right
		* @return {boolean}
		*/
		mergeWith(right) {
			return false;
		}
		/**
		* @param {Transaction} transaction
		* @param {Item} item
		*/
		integrate(transaction, item) {
			this.doc._item = item;
			transaction.subdocsAdded.add(this.doc);
			if (this.doc.shouldLoad) transaction.subdocsLoaded.add(this.doc);
		}
		/**
		* @param {Transaction} transaction
		*/
		delete(transaction) {
			if (transaction.subdocsAdded.has(this.doc)) transaction.subdocsAdded.delete(this.doc);
			else transaction.subdocsRemoved.add(this.doc);
		}
		/**
		* @param {StructStore} store
		*/
		gc(store) {}
		/**
		* @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
		* @param {number} offset
		*/
		write(encoder, offset) {
			encoder.writeString(this.doc.guid);
			encoder.writeAny(this.opts);
		}
		/**
		* @return {number}
		*/
		getRef() {
			return 9;
		}
	};
	readContentDoc = (decoder) => new ContentDoc(createDocFromOpts(decoder.readString(), decoder.readAny()));
	ContentEmbed = class ContentEmbed {
		/**
		* @param {Object} embed
		*/
		constructor(embed) {
			this.embed = embed;
		}
		/**
		* @return {number}
		*/
		getLength() {
			return 1;
		}
		/**
		* @return {Array<any>}
		*/
		getContent() {
			return [this.embed];
		}
		/**
		* @return {boolean}
		*/
		isCountable() {
			return true;
		}
		/**
		* @return {ContentEmbed}
		*/
		copy() {
			return new ContentEmbed(this.embed);
		}
		/**
		* @param {number} offset
		* @return {ContentEmbed}
		*/
		splice(offset) {
			throw methodUnimplemented();
		}
		/**
		* @param {ContentEmbed} right
		* @return {boolean}
		*/
		mergeWith(right) {
			return false;
		}
		/**
		* @param {Transaction} transaction
		* @param {Item} item
		*/
		integrate(transaction, item) {}
		/**
		* @param {Transaction} transaction
		*/
		delete(transaction) {}
		/**
		* @param {StructStore} store
		*/
		gc(store) {}
		/**
		* @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
		* @param {number} offset
		*/
		write(encoder, offset) {
			encoder.writeJSON(this.embed);
		}
		/**
		* @return {number}
		*/
		getRef() {
			return 5;
		}
	};
	readContentEmbed = (decoder) => new ContentEmbed(decoder.readJSON());
	ContentFormat = class ContentFormat {
		/**
		* @param {string} key
		* @param {Object} value
		*/
		constructor(key, value) {
			this.key = key;
			this.value = value;
		}
		/**
		* @return {number}
		*/
		getLength() {
			return 1;
		}
		/**
		* @return {Array<any>}
		*/
		getContent() {
			return [];
		}
		/**
		* @return {boolean}
		*/
		isCountable() {
			return false;
		}
		/**
		* @return {ContentFormat}
		*/
		copy() {
			return new ContentFormat(this.key, this.value);
		}
		/**
		* @param {number} _offset
		* @return {ContentFormat}
		*/
		splice(_offset) {
			throw methodUnimplemented();
		}
		/**
		* @param {ContentFormat} _right
		* @return {boolean}
		*/
		mergeWith(_right) {
			return false;
		}
		/**
		* @param {Transaction} _transaction
		* @param {Item} item
		*/
		integrate(_transaction, item) {
			const p = item.parent;
			p._searchMarker = null;
			p._hasFormatting = true;
		}
		/**
		* @param {Transaction} transaction
		*/
		delete(transaction) {}
		/**
		* @param {StructStore} store
		*/
		gc(store) {}
		/**
		* @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
		* @param {number} offset
		*/
		write(encoder, offset) {
			encoder.writeKey(this.key);
			encoder.writeJSON(this.value);
		}
		/**
		* @return {number}
		*/
		getRef() {
			return 6;
		}
	};
	readContentFormat = (decoder) => new ContentFormat(decoder.readKey(), decoder.readJSON());
	ContentJSON = class ContentJSON {
		/**
		* @param {Array<any>} arr
		*/
		constructor(arr) {
			/**
			* @type {Array<any>}
			*/
			this.arr = arr;
		}
		/**
		* @return {number}
		*/
		getLength() {
			return this.arr.length;
		}
		/**
		* @return {Array<any>}
		*/
		getContent() {
			return this.arr;
		}
		/**
		* @return {boolean}
		*/
		isCountable() {
			return true;
		}
		/**
		* @return {ContentJSON}
		*/
		copy() {
			return new ContentJSON(this.arr);
		}
		/**
		* @param {number} offset
		* @return {ContentJSON}
		*/
		splice(offset) {
			const right = new ContentJSON(this.arr.slice(offset));
			this.arr = this.arr.slice(0, offset);
			return right;
		}
		/**
		* @param {ContentJSON} right
		* @return {boolean}
		*/
		mergeWith(right) {
			this.arr = this.arr.concat(right.arr);
			return true;
		}
		/**
		* @param {Transaction} transaction
		* @param {Item} item
		*/
		integrate(transaction, item) {}
		/**
		* @param {Transaction} transaction
		*/
		delete(transaction) {}
		/**
		* @param {StructStore} store
		*/
		gc(store) {}
		/**
		* @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
		* @param {number} offset
		*/
		write(encoder, offset) {
			const len = this.arr.length;
			encoder.writeLen(len - offset);
			for (let i = offset; i < len; i++) {
				const c = this.arr[i];
				encoder.writeString(c === void 0 ? "undefined" : JSON.stringify(c));
			}
		}
		/**
		* @return {number}
		*/
		getRef() {
			return 2;
		}
	};
	readContentJSON = (decoder) => {
		const len = decoder.readLen();
		const cs = [];
		for (let i = 0; i < len; i++) {
			const c = decoder.readString();
			if (c === "undefined") cs.push(void 0);
			else cs.push(JSON.parse(c));
		}
		return new ContentJSON(cs);
	};
	isDevMode = getVariable("node_env") === "development";
	ContentAny = class ContentAny {
		/**
		* @param {Array<any>} arr
		*/
		constructor(arr) {
			/**
			* @type {Array<any>}
			*/
			this.arr = arr;
			isDevMode && deepFreeze(arr);
		}
		/**
		* @return {number}
		*/
		getLength() {
			return this.arr.length;
		}
		/**
		* @return {Array<any>}
		*/
		getContent() {
			return this.arr;
		}
		/**
		* @return {boolean}
		*/
		isCountable() {
			return true;
		}
		/**
		* @return {ContentAny}
		*/
		copy() {
			return new ContentAny(this.arr);
		}
		/**
		* @param {number} offset
		* @return {ContentAny}
		*/
		splice(offset) {
			const right = new ContentAny(this.arr.slice(offset));
			this.arr = this.arr.slice(0, offset);
			return right;
		}
		/**
		* @param {ContentAny} right
		* @return {boolean}
		*/
		mergeWith(right) {
			this.arr = this.arr.concat(right.arr);
			return true;
		}
		/**
		* @param {Transaction} transaction
		* @param {Item} item
		*/
		integrate(transaction, item) {}
		/**
		* @param {Transaction} transaction
		*/
		delete(transaction) {}
		/**
		* @param {StructStore} store
		*/
		gc(store) {}
		/**
		* @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
		* @param {number} offset
		*/
		write(encoder, offset) {
			const len = this.arr.length;
			encoder.writeLen(len - offset);
			for (let i = offset; i < len; i++) {
				const c = this.arr[i];
				encoder.writeAny(c);
			}
		}
		/**
		* @return {number}
		*/
		getRef() {
			return 8;
		}
	};
	readContentAny = (decoder) => {
		const len = decoder.readLen();
		const cs = [];
		for (let i = 0; i < len; i++) cs.push(decoder.readAny());
		return new ContentAny(cs);
	};
	ContentString = class ContentString {
		/**
		* @param {string} str
		*/
		constructor(str) {
			/**
			* @type {string}
			*/
			this.str = str;
		}
		/**
		* @return {number}
		*/
		getLength() {
			return this.str.length;
		}
		/**
		* @return {Array<any>}
		*/
		getContent() {
			return this.str.split("");
		}
		/**
		* @return {boolean}
		*/
		isCountable() {
			return true;
		}
		/**
		* @return {ContentString}
		*/
		copy() {
			return new ContentString(this.str);
		}
		/**
		* @param {number} offset
		* @return {ContentString}
		*/
		splice(offset) {
			const right = new ContentString(this.str.slice(offset));
			this.str = this.str.slice(0, offset);
			const firstCharCode = this.str.charCodeAt(offset - 1);
			if (firstCharCode >= 55296 && firstCharCode <= 56319) {
				this.str = this.str.slice(0, offset - 1) + "�";
				right.str = "�" + right.str.slice(1);
			}
			return right;
		}
		/**
		* @param {ContentString} right
		* @return {boolean}
		*/
		mergeWith(right) {
			this.str += right.str;
			return true;
		}
		/**
		* @param {Transaction} transaction
		* @param {Item} item
		*/
		integrate(transaction, item) {}
		/**
		* @param {Transaction} transaction
		*/
		delete(transaction) {}
		/**
		* @param {StructStore} store
		*/
		gc(store) {}
		/**
		* @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
		* @param {number} offset
		*/
		write(encoder, offset) {
			encoder.writeString(offset === 0 ? this.str : this.str.slice(offset));
		}
		/**
		* @return {number}
		*/
		getRef() {
			return 4;
		}
	};
	readContentString = (decoder) => new ContentString(decoder.readString());
	typeRefs = [
		readYArray,
		readYMap,
		readYText,
		readYXmlElement,
		readYXmlFragment,
		readYXmlHook,
		readYXmlText
	];
	YArrayRefID = 0;
	YMapRefID = 1;
	YTextRefID = 2;
	YXmlElementRefID = 3;
	YXmlFragmentRefID = 4;
	YXmlHookRefID = 5;
	YXmlTextRefID = 6;
	ContentType = class ContentType {
		/**
		* @param {AbstractType<any>} type
		*/
		constructor(type) {
			/**
			* @type {AbstractType<any>}
			*/
			this.type = type;
		}
		/**
		* @return {number}
		*/
		getLength() {
			return 1;
		}
		/**
		* @return {Array<any>}
		*/
		getContent() {
			return [this.type];
		}
		/**
		* @return {boolean}
		*/
		isCountable() {
			return true;
		}
		/**
		* @return {ContentType}
		*/
		copy() {
			return new ContentType(this.type._copy());
		}
		/**
		* @param {number} offset
		* @return {ContentType}
		*/
		splice(offset) {
			throw methodUnimplemented();
		}
		/**
		* @param {ContentType} right
		* @return {boolean}
		*/
		mergeWith(right) {
			return false;
		}
		/**
		* @param {Transaction} transaction
		* @param {Item} item
		*/
		integrate(transaction, item) {
			this.type._integrate(transaction.doc, item);
		}
		/**
		* @param {Transaction} transaction
		*/
		delete(transaction) {
			let item = this.type._start;
			while (item !== null) {
				if (!item.deleted) item.delete(transaction);
				else if (item.id.clock < (transaction.beforeState.get(item.id.client) || 0)) transaction._mergeStructs.push(item);
				item = item.right;
			}
			this.type._map.forEach((item) => {
				if (!item.deleted) item.delete(transaction);
				else if (item.id.clock < (transaction.beforeState.get(item.id.client) || 0)) transaction._mergeStructs.push(item);
			});
			transaction.changed.delete(this.type);
		}
		/**
		* @param {StructStore} store
		*/
		gc(store) {
			let item = this.type._start;
			while (item !== null) {
				item.gc(store, true);
				item = item.right;
			}
			this.type._start = null;
			this.type._map.forEach(
				/** @param {Item | null} item */
				(item) => {
					while (item !== null) {
						item.gc(store, true);
						item = item.left;
					}
				}
			);
			this.type._map = /* @__PURE__ */ new Map();
		}
		/**
		* @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
		* @param {number} offset
		*/
		write(encoder, offset) {
			this.type._write(encoder);
		}
		/**
		* @return {number}
		*/
		getRef() {
			return 7;
		}
	};
	readContentType = (decoder) => new ContentType(typeRefs[decoder.readTypeRef()](decoder));
	followRedone = (store, id) => {
		/**
		* @type {ID|null}
		*/
		let nextID = id;
		let diff = 0;
		let item;
		do {
			if (diff > 0) nextID = createID(nextID.client, nextID.clock + diff);
			item = getItem(store, nextID);
			diff = nextID.clock - item.id.clock;
			nextID = item.redone;
		} while (nextID !== null && item instanceof Item);
		return {
			item,
			diff
		};
	};
	keepItem = (item, keep) => {
		while (item !== null && item.keep !== keep) {
			item.keep = keep;
			item = item.parent._item;
		}
	};
	splitItem = (transaction, leftItem, diff) => {
		const { client, clock } = leftItem.id;
		const rightItem = new Item(createID(client, clock + diff), leftItem, createID(client, clock + diff - 1), leftItem.right, leftItem.rightOrigin, leftItem.parent, leftItem.parentSub, leftItem.content.splice(diff));
		if (leftItem.deleted) rightItem.markDeleted();
		if (leftItem.keep) rightItem.keep = true;
		if (leftItem.redone !== null) rightItem.redone = createID(leftItem.redone.client, leftItem.redone.clock + diff);
		leftItem.right = rightItem;
		if (rightItem.right !== null) rightItem.right.left = rightItem;
		transaction._mergeStructs.push(rightItem);
		if (rightItem.parentSub !== null && rightItem.right === null)
 /** @type {AbstractType<any>} */ rightItem.parent._map.set(rightItem.parentSub, rightItem);
		leftItem.length = diff;
		return rightItem;
	};
	isDeletedByUndoStack = (stack, id) => some(
		stack,
		/** @param {StackItem} s */
		(s) => isDeleted(s.deletions, id)
	);
	redoItem = (transaction, item, redoitems, itemsToDelete, ignoreRemoteMapChanges, um) => {
		const doc = transaction.doc;
		const store = doc.store;
		const ownClientID = doc.clientID;
		const redone = item.redone;
		if (redone !== null) return getItemCleanStart(transaction, redone);
		let parentItem = item.parent._item;
		/**
		* @type {Item|null}
		*/
		let left = null;
		/**
		* @type {Item|null}
		*/
		let right;
		if (parentItem !== null && parentItem.deleted === true) {
			if (parentItem.redone === null && (!redoitems.has(parentItem) || redoItem(transaction, parentItem, redoitems, itemsToDelete, ignoreRemoteMapChanges, um) === null)) return null;
			while (parentItem.redone !== null) parentItem = getItemCleanStart(transaction, parentItem.redone);
		}
		const parentType = parentItem === null ? item.parent : parentItem.content.type;
		if (item.parentSub === null) {
			left = item.left;
			right = item;
			while (left !== null) {
				/**
				* @type {Item|null}
				*/
				let leftTrace = left;
				while (leftTrace !== null && leftTrace.parent._item !== parentItem) leftTrace = leftTrace.redone === null ? null : getItemCleanStart(transaction, leftTrace.redone);
				if (leftTrace !== null && leftTrace.parent._item === parentItem) {
					left = leftTrace;
					break;
				}
				left = left.left;
			}
			while (right !== null) {
				/**
				* @type {Item|null}
				*/
				let rightTrace = right;
				while (rightTrace !== null && rightTrace.parent._item !== parentItem) rightTrace = rightTrace.redone === null ? null : getItemCleanStart(transaction, rightTrace.redone);
				if (rightTrace !== null && rightTrace.parent._item === parentItem) {
					right = rightTrace;
					break;
				}
				right = right.right;
			}
		} else {
			right = null;
			if (item.right && !ignoreRemoteMapChanges) {
				left = item;
				while (left !== null && left.right !== null && (left.right.redone || isDeleted(itemsToDelete, left.right.id) || isDeletedByUndoStack(um.undoStack, left.right.id) || isDeletedByUndoStack(um.redoStack, left.right.id))) {
					left = left.right;
					while (left.redone) left = getItemCleanStart(transaction, left.redone);
				}
				if (left && left.right !== null) return null;
			} else left = parentType._map.get(item.parentSub) || null;
		}
		const nextId = createID(ownClientID, getState(store, ownClientID));
		const redoneItem = new Item(nextId, left, left && left.lastId, right, right && right.id, parentType, item.parentSub, item.content.copy());
		item.redone = nextId;
		keepItem(redoneItem, true);
		redoneItem.integrate(transaction, 0);
		return redoneItem;
	};
	Item = class Item extends AbstractStruct {
		/**
		* @param {ID} id
		* @param {Item | null} left
		* @param {ID | null} origin
		* @param {Item | null} right
		* @param {ID | null} rightOrigin
		* @param {AbstractType<any>|ID|null} parent Is a type if integrated, is null if it is possible to copy parent from left or right, is ID before integration to search for it.
		* @param {string | null} parentSub
		* @param {AbstractContent} content
		*/
		constructor(id, left, origin, right, rightOrigin, parent, parentSub, content) {
			super(id, content.getLength());
			/**
			* The item that was originally to the left of this item.
			* @type {ID | null}
			*/
			this.origin = origin;
			/**
			* The item that is currently to the left of this item.
			* @type {Item | null}
			*/
			this.left = left;
			/**
			* The item that is currently to the right of this item.
			* @type {Item | null}
			*/
			this.right = right;
			/**
			* The item that was originally to the right of this item.
			* @type {ID | null}
			*/
			this.rightOrigin = rightOrigin;
			/**
			* @type {AbstractType<any>|ID|null}
			*/
			this.parent = parent;
			/**
			* If the parent refers to this item with some kind of key (e.g. YMap, the
			* key is specified here. The key is then used to refer to the list in which
			* to insert this item. If `parentSub = null` type._start is the list in
			* which to insert to. Otherwise it is `parent._map`.
			* @type {String | null}
			*/
			this.parentSub = parentSub;
			/**
			* If this type's effect is redone this type refers to the type that undid
			* this operation.
			* @type {ID | null}
			*/
			this.redone = null;
			/**
			* @type {AbstractContent}
			*/
			this.content = content;
			/**
			* bit1: keep
			* bit2: countable
			* bit3: deleted
			* bit4: mark - mark node as fast-search-marker
			* @type {number} byte
			*/
			this.info = this.content.isCountable() ? 2 : 0;
		}
		/**
		* This is used to mark the item as an indexed fast-search marker
		*
		* @type {boolean}
		*/
		set marker(isMarked) {
			if ((this.info & 8) > 0 !== isMarked) this.info ^= 8;
		}
		get marker() {
			return (this.info & 8) > 0;
		}
		/**
		* If true, do not garbage collect this Item.
		*/
		get keep() {
			return (this.info & 1) > 0;
		}
		set keep(doKeep) {
			if (this.keep !== doKeep) this.info ^= 1;
		}
		get countable() {
			return (this.info & 2) > 0;
		}
		/**
		* Whether this item was deleted or not.
		* @type {Boolean}
		*/
		get deleted() {
			return (this.info & 4) > 0;
		}
		set deleted(doDelete) {
			if (this.deleted !== doDelete) this.info ^= 4;
		}
		markDeleted() {
			this.info |= 4;
		}
		/**
		* Return the creator clientID of the missing op or define missing items and return null.
		*
		* @param {Transaction} transaction
		* @param {StructStore} store
		* @return {null | number}
		*/
		getMissing(transaction, store) {
			if (this.origin && this.origin.client !== this.id.client && this.origin.clock >= getState(store, this.origin.client)) return this.origin.client;
			if (this.rightOrigin && this.rightOrigin.client !== this.id.client && this.rightOrigin.clock >= getState(store, this.rightOrigin.client)) return this.rightOrigin.client;
			if (this.parent && this.parent.constructor === ID && this.id.client !== this.parent.client && this.parent.clock >= getState(store, this.parent.client)) return this.parent.client;
			if (this.origin) {
				this.left = getItemCleanEnd(transaction, store, this.origin);
				this.origin = this.left.lastId;
			}
			if (this.rightOrigin) {
				this.right = getItemCleanStart(transaction, this.rightOrigin);
				this.rightOrigin = this.right.id;
			}
			if (this.left && this.left.constructor === GC || this.right && this.right.constructor === GC) this.parent = null;
			else if (!this.parent) {
				if (this.left && this.left.constructor === Item) {
					this.parent = this.left.parent;
					this.parentSub = this.left.parentSub;
				} else if (this.right && this.right.constructor === Item) {
					this.parent = this.right.parent;
					this.parentSub = this.right.parentSub;
				}
			} else if (this.parent.constructor === ID) {
				const parentItem = getItem(store, this.parent);
				if (parentItem.constructor === GC) this.parent = null;
				else this.parent = parentItem.content.type;
			}
			return null;
		}
		/**
		* @param {Transaction} transaction
		* @param {number} offset
		*/
		integrate(transaction, offset) {
			if (offset > 0) {
				this.id.clock += offset;
				this.left = getItemCleanEnd(transaction, transaction.doc.store, createID(this.id.client, this.id.clock - 1));
				this.origin = this.left.lastId;
				this.content = this.content.splice(offset);
				this.length -= offset;
			}
			if (this.parent) {
				if (!this.left && (!this.right || this.right.left !== null) || this.left && this.left.right !== this.right) {
					/**
					* @type {Item|null}
					*/
					let left = this.left;
					/**
					* @type {Item|null}
					*/
					let o;
					if (left !== null) o = left.right;
					else if (this.parentSub !== null) {
						o = this.parent._map.get(this.parentSub) || null;
						while (o !== null && o.left !== null) o = o.left;
					} else o = this.parent._start;
					/**
					* @type {Set<Item>}
					*/
					const conflictingItems = /* @__PURE__ */ new Set();
					/**
					* @type {Set<Item>}
					*/
					const itemsBeforeOrigin = /* @__PURE__ */ new Set();
					while (o !== null && o !== this.right) {
						itemsBeforeOrigin.add(o);
						conflictingItems.add(o);
						if (compareIDs(this.origin, o.origin)) {
							if (o.id.client < this.id.client) {
								left = o;
								conflictingItems.clear();
							} else if (compareIDs(this.rightOrigin, o.rightOrigin)) break;
						} else if (o.origin !== null && itemsBeforeOrigin.has(getItem(transaction.doc.store, o.origin))) {
							if (!conflictingItems.has(getItem(transaction.doc.store, o.origin))) {
								left = o;
								conflictingItems.clear();
							}
						} else break;
						o = o.right;
					}
					this.left = left;
				}
				if (this.left !== null) {
					this.right = this.left.right;
					this.left.right = this;
				} else {
					let r;
					if (this.parentSub !== null) {
						r = this.parent._map.get(this.parentSub) || null;
						while (r !== null && r.left !== null) r = r.left;
					} else {
						r = this.parent._start;
						/** @type {AbstractType<any>} */ this.parent._start = this;
					}
					this.right = r;
				}
				if (this.right !== null) this.right.left = this;
				else if (this.parentSub !== null) {
					/** @type {AbstractType<any>} */ this.parent._map.set(this.parentSub, this);
					if (this.left !== null) this.left.delete(transaction);
				}
				if (this.parentSub === null && this.countable && !this.deleted)
 /** @type {AbstractType<any>} */ this.parent._length += this.length;
				addStruct(transaction.doc.store, this);
				this.content.integrate(transaction, this);
				addChangedTypeToTransaction(transaction, this.parent, this.parentSub);
				if (this.parent._item !== null && this.parent._item.deleted || this.parentSub !== null && this.right !== null) this.delete(transaction);
			} else new GC(this.id, this.length).integrate(transaction, 0);
		}
		/**
		* Returns the next non-deleted item
		*/
		get next() {
			let n = this.right;
			while (n !== null && n.deleted) n = n.right;
			return n;
		}
		/**
		* Returns the previous non-deleted item
		*/
		get prev() {
			let n = this.left;
			while (n !== null && n.deleted) n = n.left;
			return n;
		}
		/**
		* Computes the last content address of this Item.
		*/
		get lastId() {
			return this.length === 1 ? this.id : createID(this.id.client, this.id.clock + this.length - 1);
		}
		/**
		* Try to merge two items
		*
		* @param {Item} right
		* @return {boolean}
		*/
		mergeWith(right) {
			if (this.constructor === right.constructor && compareIDs(right.origin, this.lastId) && this.right === right && compareIDs(this.rightOrigin, right.rightOrigin) && this.id.client === right.id.client && this.id.clock + this.length === right.id.clock && this.deleted === right.deleted && this.redone === null && right.redone === null && this.content.constructor === right.content.constructor && this.content.mergeWith(right.content)) {
				const searchMarker = this.parent._searchMarker;
				if (searchMarker) searchMarker.forEach((marker) => {
					if (marker.p === right) {
						marker.p = this;
						if (!this.deleted && this.countable) marker.index -= this.length;
					}
				});
				if (right.keep) this.keep = true;
				this.right = right.right;
				if (this.right !== null) this.right.left = this;
				this.length += right.length;
				return true;
			}
			return false;
		}
		/**
		* Mark this Item as deleted.
		*
		* @param {Transaction} transaction
		*/
		delete(transaction) {
			if (!this.deleted) {
				const parent = this.parent;
				if (this.countable && this.parentSub === null) parent._length -= this.length;
				this.markDeleted();
				addToDeleteSet(transaction.deleteSet, this.id.client, this.id.clock, this.length);
				addChangedTypeToTransaction(transaction, parent, this.parentSub);
				this.content.delete(transaction);
			}
		}
		/**
		* @param {StructStore} store
		* @param {boolean} parentGCd
		*/
		gc(store, parentGCd) {
			if (!this.deleted) throw unexpectedCase();
			this.content.gc(store);
			if (parentGCd) replaceStruct(store, this, new GC(this.id, this.length));
			else this.content = new ContentDeleted(this.length);
		}
		/**
		* Transform the properties of this type to binary and write it to an
		* BinaryEncoder.
		*
		* This is called when this Item is sent to a remote peer.
		*
		* @param {UpdateEncoderV1 | UpdateEncoderV2} encoder The encoder to write data to.
		* @param {number} offset
		*/
		write(encoder, offset) {
			const origin = offset > 0 ? createID(this.id.client, this.id.clock + offset - 1) : this.origin;
			const rightOrigin = this.rightOrigin;
			const parentSub = this.parentSub;
			const info = this.content.getRef() & 31 | (origin === null ? 0 : 128) | (rightOrigin === null ? 0 : 64) | (parentSub === null ? 0 : 32);
			encoder.writeInfo(info);
			if (origin !== null) encoder.writeLeftID(origin);
			if (rightOrigin !== null) encoder.writeRightID(rightOrigin);
			if (origin === null && rightOrigin === null) {
				const parent = this.parent;
				if (parent._item !== void 0) {
					const parentItem = parent._item;
					if (parentItem === null) {
						const ykey = findRootTypeKey(parent);
						encoder.writeParentInfo(true);
						encoder.writeString(ykey);
					} else {
						encoder.writeParentInfo(false);
						encoder.writeLeftID(parentItem.id);
					}
				} else if (parent.constructor === String) {
					encoder.writeParentInfo(true);
					encoder.writeString(parent);
				} else if (parent.constructor === ID) {
					encoder.writeParentInfo(false);
					encoder.writeLeftID(parent);
				} else unexpectedCase();
				if (parentSub !== null) encoder.writeString(parentSub);
			}
			this.content.write(encoder, offset);
		}
	};
	readItemContent = (decoder, info) => contentRefs[info & 31](decoder);
	contentRefs = [
		() => {
			unexpectedCase();
		},
		readContentDeleted,
		readContentJSON,
		readContentBinary,
		readContentString,
		readContentEmbed,
		readContentFormat,
		readContentType,
		readContentAny,
		readContentDoc,
		() => {
			unexpectedCase();
		}
	];
	structSkipRefNumber = 10;
	Skip = class extends AbstractStruct {
		get deleted() {
			return true;
		}
		delete() {}
		/**
		* @param {Skip} right
		* @return {boolean}
		*/
		mergeWith(right) {
			if (this.constructor !== right.constructor) return false;
			this.length += right.length;
			return true;
		}
		/**
		* @param {Transaction} transaction
		* @param {number} offset
		*/
		integrate(transaction, offset) {
			unexpectedCase();
		}
		/**
		* @param {UpdateEncoderV1 | UpdateEncoderV2} encoder
		* @param {number} offset
		*/
		write(encoder, offset) {
			encoder.writeInfo(structSkipRefNumber);
			writeVarUint(encoder.restEncoder, this.length - offset);
		}
		/**
		* @param {Transaction} transaction
		* @param {StructStore} store
		* @return {null | number}
		*/
		getMissing(transaction, store) {
			return null;
		}
	};
	glo = typeof globalThis !== "undefined" ? globalThis : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : {};
	importIdentifier = "__ $YJS$ __";
	if (glo[importIdentifier] === true)
 /**
	* Dear reader of this message. Please take this seriously.
	*
	* If you see this message, make sure that you only import one version of Yjs. In many cases,
	* your package manager installs two versions of Yjs that are used by different packages within your project.
	* Another reason for this message is that some parts of your project use the commonjs version of Yjs
	* and others use the EcmaScript version of Yjs.
	*
	* This often leads to issues that are hard to debug. We often need to perform constructor checks,
	* e.g. `struct instanceof GC`. If you imported different versions of Yjs, it is impossible for us to
	* do the constructor checks anymore - which might break the CRDT algorithm.
	*
	* https://github.com/yjs/yjs/issues/438
	*/
	console.error("Yjs was already imported. This breaks constructor checks and will lead to issues! - https://github.com/yjs/yjs/issues/438");
	glo[importIdentifier] = true;
}));

//#endregion
//#region dist/ORIGINALS/assets/ex-BJvWc99s.js
var App;
var init_app_ex = __esmMin((() => {
	App = class extends ex.Unit {
		browser = chrome;
		utils = new ex.Utils(this);
		libs = new ex.Libs(this);
		env = new gl.Env(this);
		bus = new gl.Bus(this);
		idb = new ex.Idb(this);
		peer = new exOs.Peer(this);
		projects = new ex.Projects(this);
		async init() {
			if (this.$.env.is.dev) self.$epos = this;
			await this.bus.initPageToken();
			await this.projects.init();
		}
	};
}));
var Idb;
var init_idb_ex = __esmMin((() => {
	Idb = class extends ex.Unit {
		sw = this.use("sw");
		get = this.sw.get;
		has = this.sw.has;
		set = this.sw.set;
		keys = this.sw.keys;
		delete = this.sw.delete;
		deleteStore = this.sw.deleteStore;
		deleteDatabase = this.sw.deleteDatabase;
		listStores = this.sw.listStores;
		listDatabases = this.sw.listDatabases;
	};
}));
/**
* @license React
* react.development.js
*
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*/
var require_react_development = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	(function() {
		function defineDeprecationWarning(methodName, info) {
			Object.defineProperty(Component.prototype, methodName, { get: function() {
				console.warn("%s(...) is deprecated in plain JavaScript React classes. %s", info[0], info[1]);
			} });
		}
		function getIteratorFn(maybeIterable) {
			if (null === maybeIterable || "object" !== typeof maybeIterable) return null;
			maybeIterable = MAYBE_ITERATOR_SYMBOL && maybeIterable[MAYBE_ITERATOR_SYMBOL] || maybeIterable["@@iterator"];
			return "function" === typeof maybeIterable ? maybeIterable : null;
		}
		function warnNoop(publicInstance, callerName) {
			publicInstance = (publicInstance = publicInstance.constructor) && (publicInstance.displayName || publicInstance.name) || "ReactClass";
			var warningKey = publicInstance + "." + callerName;
			didWarnStateUpdateForUnmountedComponent[warningKey] || (console.error("Can't call %s on a component that is not yet mounted. This is a no-op, but it might indicate a bug in your application. Instead, assign to `this.state` directly or define a `state = {};` class property with the desired state in the %s component.", callerName, publicInstance), didWarnStateUpdateForUnmountedComponent[warningKey] = !0);
		}
		function Component(props, context, updater) {
			this.props = props;
			this.context = context;
			this.refs = emptyObject;
			this.updater = updater || ReactNoopUpdateQueue;
		}
		function ComponentDummy() {}
		function PureComponent(props, context, updater) {
			this.props = props;
			this.context = context;
			this.refs = emptyObject;
			this.updater = updater || ReactNoopUpdateQueue;
		}
		function noop() {}
		function testStringCoercion(value) {
			return "" + value;
		}
		function checkKeyStringCoercion(value) {
			try {
				testStringCoercion(value);
				var JSCompiler_inline_result = !1;
			} catch (e) {
				JSCompiler_inline_result = !0;
			}
			if (JSCompiler_inline_result) {
				JSCompiler_inline_result = console;
				var JSCompiler_temp_const = JSCompiler_inline_result.error;
				var JSCompiler_inline_result$jscomp$0 = "function" === typeof Symbol && Symbol.toStringTag && value[Symbol.toStringTag] || value.constructor.name || "Object";
				JSCompiler_temp_const.call(JSCompiler_inline_result, "The provided key is an unsupported type %s. This value must be coerced to a string before using it here.", JSCompiler_inline_result$jscomp$0);
				return testStringCoercion(value);
			}
		}
		function getComponentNameFromType(type) {
			if (null == type) return null;
			if ("function" === typeof type) return type.$$typeof === REACT_CLIENT_REFERENCE ? null : type.displayName || type.name || null;
			if ("string" === typeof type) return type;
			switch (type) {
				case REACT_FRAGMENT_TYPE: return "Fragment";
				case REACT_PROFILER_TYPE: return "Profiler";
				case REACT_STRICT_MODE_TYPE: return "StrictMode";
				case REACT_SUSPENSE_TYPE: return "Suspense";
				case REACT_SUSPENSE_LIST_TYPE: return "SuspenseList";
				case REACT_ACTIVITY_TYPE: return "Activity";
			}
			if ("object" === typeof type) switch ("number" === typeof type.tag && console.error("Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."), type.$$typeof) {
				case REACT_PORTAL_TYPE: return "Portal";
				case REACT_CONTEXT_TYPE: return type.displayName || "Context";
				case REACT_CONSUMER_TYPE: return (type._context.displayName || "Context") + ".Consumer";
				case REACT_FORWARD_REF_TYPE:
					var innerType = type.render;
					type = type.displayName;
					type || (type = innerType.displayName || innerType.name || "", type = "" !== type ? "ForwardRef(" + type + ")" : "ForwardRef");
					return type;
				case REACT_MEMO_TYPE: return innerType = type.displayName || null, null !== innerType ? innerType : getComponentNameFromType(type.type) || "Memo";
				case REACT_LAZY_TYPE:
					innerType = type._payload;
					type = type._init;
					try {
						return getComponentNameFromType(type(innerType));
					} catch (x) {}
			}
			return null;
		}
		function getTaskName(type) {
			if (type === REACT_FRAGMENT_TYPE) return "<>";
			if ("object" === typeof type && null !== type && type.$$typeof === REACT_LAZY_TYPE) return "<...>";
			try {
				var name = getComponentNameFromType(type);
				return name ? "<" + name + ">" : "<...>";
			} catch (x) {
				return "<...>";
			}
		}
		function getOwner() {
			var dispatcher = ReactSharedInternals.A;
			return null === dispatcher ? null : dispatcher.getOwner();
		}
		function UnknownOwner() {
			return Error("react-stack-top-frame");
		}
		function hasValidKey(config) {
			if (hasOwnProperty.call(config, "key")) {
				var getter = Object.getOwnPropertyDescriptor(config, "key").get;
				if (getter && getter.isReactWarning) return !1;
			}
			return void 0 !== config.key;
		}
		function defineKeyPropWarningGetter(props, displayName) {
			function warnAboutAccessingKey() {
				specialPropKeyWarningShown || (specialPropKeyWarningShown = !0, console.error("%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://react.dev/link/special-props)", displayName));
			}
			warnAboutAccessingKey.isReactWarning = !0;
			Object.defineProperty(props, "key", {
				get: warnAboutAccessingKey,
				configurable: !0
			});
		}
		function elementRefGetterWithDeprecationWarning() {
			var componentName = getComponentNameFromType(this.type);
			didWarnAboutElementRef[componentName] || (didWarnAboutElementRef[componentName] = !0, console.error("Accessing element.ref was removed in React 19. ref is now a regular prop. It will be removed from the JSX Element type in a future release."));
			componentName = this.props.ref;
			return void 0 !== componentName ? componentName : null;
		}
		function ReactElement(type, key, props, owner, debugStack, debugTask) {
			var refProp = props.ref;
			type = {
				$$typeof: REACT_ELEMENT_TYPE,
				type,
				key,
				props,
				_owner: owner
			};
			null !== (void 0 !== refProp ? refProp : null) ? Object.defineProperty(type, "ref", {
				enumerable: !1,
				get: elementRefGetterWithDeprecationWarning
			}) : Object.defineProperty(type, "ref", {
				enumerable: !1,
				value: null
			});
			type._store = {};
			Object.defineProperty(type._store, "validated", {
				configurable: !1,
				enumerable: !1,
				writable: !0,
				value: 0
			});
			Object.defineProperty(type, "_debugInfo", {
				configurable: !1,
				enumerable: !1,
				writable: !0,
				value: null
			});
			Object.defineProperty(type, "_debugStack", {
				configurable: !1,
				enumerable: !1,
				writable: !0,
				value: debugStack
			});
			Object.defineProperty(type, "_debugTask", {
				configurable: !1,
				enumerable: !1,
				writable: !0,
				value: debugTask
			});
			Object.freeze && (Object.freeze(type.props), Object.freeze(type));
			return type;
		}
		function cloneAndReplaceKey(oldElement, newKey) {
			newKey = ReactElement(oldElement.type, newKey, oldElement.props, oldElement._owner, oldElement._debugStack, oldElement._debugTask);
			oldElement._store && (newKey._store.validated = oldElement._store.validated);
			return newKey;
		}
		function validateChildKeys(node) {
			isValidElement(node) ? node._store && (node._store.validated = 1) : "object" === typeof node && null !== node && node.$$typeof === REACT_LAZY_TYPE && ("fulfilled" === node._payload.status ? isValidElement(node._payload.value) && node._payload.value._store && (node._payload.value._store.validated = 1) : node._store && (node._store.validated = 1));
		}
		function isValidElement(object) {
			return "object" === typeof object && null !== object && object.$$typeof === REACT_ELEMENT_TYPE;
		}
		function escape(key) {
			var escaperLookup = {
				"=": "=0",
				":": "=2"
			};
			return "$" + key.replace(/[=:]/g, function(match) {
				return escaperLookup[match];
			});
		}
		function getElementKey(element, index) {
			return "object" === typeof element && null !== element && null != element.key ? (checkKeyStringCoercion(element.key), escape("" + element.key)) : index.toString(36);
		}
		function resolveThenable(thenable) {
			switch (thenable.status) {
				case "fulfilled": return thenable.value;
				case "rejected": throw thenable.reason;
				default: switch ("string" === typeof thenable.status ? thenable.then(noop, noop) : (thenable.status = "pending", thenable.then(function(fulfilledValue) {
					"pending" === thenable.status && (thenable.status = "fulfilled", thenable.value = fulfilledValue);
				}, function(error) {
					"pending" === thenable.status && (thenable.status = "rejected", thenable.reason = error);
				})), thenable.status) {
					case "fulfilled": return thenable.value;
					case "rejected": throw thenable.reason;
				}
			}
			throw thenable;
		}
		function mapIntoArray(children, array, escapedPrefix, nameSoFar, callback) {
			var type = typeof children;
			if ("undefined" === type || "boolean" === type) children = null;
			var invokeCallback = !1;
			if (null === children) invokeCallback = !0;
			else switch (type) {
				case "bigint":
				case "string":
				case "number":
					invokeCallback = !0;
					break;
				case "object": switch (children.$$typeof) {
					case REACT_ELEMENT_TYPE:
					case REACT_PORTAL_TYPE:
						invokeCallback = !0;
						break;
					case REACT_LAZY_TYPE: return invokeCallback = children._init, mapIntoArray(invokeCallback(children._payload), array, escapedPrefix, nameSoFar, callback);
				}
			}
			if (invokeCallback) {
				invokeCallback = children;
				callback = callback(invokeCallback);
				var childKey = "" === nameSoFar ? "." + getElementKey(invokeCallback, 0) : nameSoFar;
				isArrayImpl(callback) ? (escapedPrefix = "", null != childKey && (escapedPrefix = childKey.replace(userProvidedKeyEscapeRegex, "$&/") + "/"), mapIntoArray(callback, array, escapedPrefix, "", function(c) {
					return c;
				})) : null != callback && (isValidElement(callback) && (null != callback.key && (invokeCallback && invokeCallback.key === callback.key || checkKeyStringCoercion(callback.key)), escapedPrefix = cloneAndReplaceKey(callback, escapedPrefix + (null == callback.key || invokeCallback && invokeCallback.key === callback.key ? "" : ("" + callback.key).replace(userProvidedKeyEscapeRegex, "$&/") + "/") + childKey), "" !== nameSoFar && null != invokeCallback && isValidElement(invokeCallback) && null == invokeCallback.key && invokeCallback._store && !invokeCallback._store.validated && (escapedPrefix._store.validated = 2), callback = escapedPrefix), array.push(callback));
				return 1;
			}
			invokeCallback = 0;
			childKey = "" === nameSoFar ? "." : nameSoFar + ":";
			if (isArrayImpl(children)) for (var i = 0; i < children.length; i++) nameSoFar = children[i], type = childKey + getElementKey(nameSoFar, i), invokeCallback += mapIntoArray(nameSoFar, array, escapedPrefix, type, callback);
			else if (i = getIteratorFn(children), "function" === typeof i) for (i === children.entries && (didWarnAboutMaps || console.warn("Using Maps as children is not supported. Use an array of keyed ReactElements instead."), didWarnAboutMaps = !0), children = i.call(children), i = 0; !(nameSoFar = children.next()).done;) nameSoFar = nameSoFar.value, type = childKey + getElementKey(nameSoFar, i++), invokeCallback += mapIntoArray(nameSoFar, array, escapedPrefix, type, callback);
			else if ("object" === type) {
				if ("function" === typeof children.then) return mapIntoArray(resolveThenable(children), array, escapedPrefix, nameSoFar, callback);
				array = String(children);
				throw Error("Objects are not valid as a React child (found: " + ("[object Object]" === array ? "object with keys {" + Object.keys(children).join(", ") + "}" : array) + "). If you meant to render a collection of children, use an array instead.");
			}
			return invokeCallback;
		}
		function mapChildren(children, func, context) {
			if (null == children) return children;
			var result = [];
			var count = 0;
			mapIntoArray(children, result, "", "", function(child) {
				return func.call(context, child, count++);
			});
			return result;
		}
		function lazyInitializer(payload) {
			if (-1 === payload._status) {
				var ioInfo = payload._ioInfo;
				null != ioInfo && (ioInfo.start = ioInfo.end = performance.now());
				ioInfo = payload._result;
				var thenable = ioInfo();
				thenable.then(function(moduleObject) {
					if (0 === payload._status || -1 === payload._status) {
						payload._status = 1;
						payload._result = moduleObject;
						var _ioInfo = payload._ioInfo;
						null != _ioInfo && (_ioInfo.end = performance.now());
						void 0 === thenable.status && (thenable.status = "fulfilled", thenable.value = moduleObject);
					}
				}, function(error) {
					if (0 === payload._status || -1 === payload._status) {
						payload._status = 2;
						payload._result = error;
						var _ioInfo2 = payload._ioInfo;
						null != _ioInfo2 && (_ioInfo2.end = performance.now());
						void 0 === thenable.status && (thenable.status = "rejected", thenable.reason = error);
					}
				});
				ioInfo = payload._ioInfo;
				if (null != ioInfo) {
					ioInfo.value = thenable;
					var displayName = thenable.displayName;
					"string" === typeof displayName && (ioInfo.name = displayName);
				}
				-1 === payload._status && (payload._status = 0, payload._result = thenable);
			}
			if (1 === payload._status) return ioInfo = payload._result, void 0 === ioInfo && console.error("lazy: Expected the result of a dynamic import() call. Instead received: %s\n\nYour code should look like: \n  const MyComponent = lazy(() => import('./MyComponent'))\n\nDid you accidentally put curly braces around the import?", ioInfo), "default" in ioInfo || console.error("lazy: Expected the result of a dynamic import() call. Instead received: %s\n\nYour code should look like: \n  const MyComponent = lazy(() => import('./MyComponent'))", ioInfo), ioInfo.default;
			throw payload._result;
		}
		function resolveDispatcher() {
			var dispatcher = ReactSharedInternals.H;
			null === dispatcher && console.error("Invalid hook call. Hooks can only be called inside of the body of a function component. This could happen for one of the following reasons:\n1. You might have mismatching versions of React and the renderer (such as React DOM)\n2. You might be breaking the Rules of Hooks\n3. You might have more than one copy of React in the same app\nSee https://react.dev/link/invalid-hook-call for tips about how to debug and fix this problem.");
			return dispatcher;
		}
		function releaseAsyncTransition() {
			ReactSharedInternals.asyncTransitions--;
		}
		function enqueueTask(task) {
			if (null === enqueueTaskImpl) try {
				var requireString = ("require" + Math.random()).slice(0, 7);
				enqueueTaskImpl = (module && module[requireString]).call(module, "timers").setImmediate;
			} catch (_err) {
				enqueueTaskImpl = function(callback) {
					!1 === didWarnAboutMessageChannel && (didWarnAboutMessageChannel = !0, "undefined" === typeof MessageChannel && console.error("This browser does not have a MessageChannel implementation, so enqueuing tasks via await act(async () => ...) will fail. Please file an issue at https://github.com/facebook/react/issues if you encounter this warning."));
					var channel = new MessageChannel();
					channel.port1.onmessage = callback;
					channel.port2.postMessage(void 0);
				};
			}
			return enqueueTaskImpl(task);
		}
		function aggregateErrors(errors) {
			return 1 < errors.length && "function" === typeof AggregateError ? new AggregateError(errors) : errors[0];
		}
		function popActScope(prevActQueue, prevActScopeDepth) {
			prevActScopeDepth !== actScopeDepth - 1 && console.error("You seem to have overlapping act() calls, this is not supported. Be sure to await previous act() calls before making a new one. ");
			actScopeDepth = prevActScopeDepth;
		}
		function recursivelyFlushAsyncActWork(returnValue, resolve, reject) {
			var queue = ReactSharedInternals.actQueue;
			if (null !== queue) if (0 !== queue.length) try {
				flushActQueue(queue);
				enqueueTask(function() {
					return recursivelyFlushAsyncActWork(returnValue, resolve, reject);
				});
				return;
			} catch (error) {
				ReactSharedInternals.thrownErrors.push(error);
			}
			else ReactSharedInternals.actQueue = null;
			0 < ReactSharedInternals.thrownErrors.length ? (queue = aggregateErrors(ReactSharedInternals.thrownErrors), ReactSharedInternals.thrownErrors.length = 0, reject(queue)) : resolve(returnValue);
		}
		function flushActQueue(queue) {
			if (!isFlushing) {
				isFlushing = !0;
				var i = 0;
				try {
					for (; i < queue.length; i++) {
						var callback = queue[i];
						do {
							ReactSharedInternals.didUsePromise = !1;
							var continuation = callback(!1);
							if (null !== continuation) {
								if (ReactSharedInternals.didUsePromise) {
									queue[i] = callback;
									queue.splice(0, i);
									return;
								}
								callback = continuation;
							} else break;
						} while (1);
					}
					queue.length = 0;
				} catch (error) {
					queue.splice(0, i + 1), ReactSharedInternals.thrownErrors.push(error);
				} finally {
					isFlushing = !1;
				}
			}
		}
		"undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(Error());
		var REACT_ELEMENT_TYPE = Symbol.for("react.transitional.element");
		var REACT_PORTAL_TYPE = Symbol.for("react.portal");
		var REACT_FRAGMENT_TYPE = Symbol.for("react.fragment");
		var REACT_STRICT_MODE_TYPE = Symbol.for("react.strict_mode");
		var REACT_PROFILER_TYPE = Symbol.for("react.profiler");
		var REACT_CONSUMER_TYPE = Symbol.for("react.consumer");
		var REACT_CONTEXT_TYPE = Symbol.for("react.context");
		var REACT_FORWARD_REF_TYPE = Symbol.for("react.forward_ref");
		var REACT_SUSPENSE_TYPE = Symbol.for("react.suspense");
		var REACT_SUSPENSE_LIST_TYPE = Symbol.for("react.suspense_list");
		var REACT_MEMO_TYPE = Symbol.for("react.memo");
		var REACT_LAZY_TYPE = Symbol.for("react.lazy");
		var REACT_ACTIVITY_TYPE = Symbol.for("react.activity");
		var MAYBE_ITERATOR_SYMBOL = Symbol.iterator;
		var didWarnStateUpdateForUnmountedComponent = {};
		var ReactNoopUpdateQueue = {
			isMounted: function() {
				return !1;
			},
			enqueueForceUpdate: function(publicInstance) {
				warnNoop(publicInstance, "forceUpdate");
			},
			enqueueReplaceState: function(publicInstance) {
				warnNoop(publicInstance, "replaceState");
			},
			enqueueSetState: function(publicInstance) {
				warnNoop(publicInstance, "setState");
			}
		};
		var assign = Object.assign;
		var emptyObject = {};
		Object.freeze(emptyObject);
		Component.prototype.isReactComponent = {};
		Component.prototype.setState = function(partialState, callback) {
			if ("object" !== typeof partialState && "function" !== typeof partialState && null != partialState) throw Error("takes an object of state variables to update or a function which returns an object of state variables.");
			this.updater.enqueueSetState(this, partialState, callback, "setState");
		};
		Component.prototype.forceUpdate = function(callback) {
			this.updater.enqueueForceUpdate(this, callback, "forceUpdate");
		};
		var deprecatedAPIs = {
			isMounted: ["isMounted", "Instead, make sure to clean up subscriptions and pending requests in componentWillUnmount to prevent memory leaks."],
			replaceState: ["replaceState", "Refactor your code to use setState instead (see https://github.com/facebook/react/issues/3236)."]
		};
		for (fnName in deprecatedAPIs) deprecatedAPIs.hasOwnProperty(fnName) && defineDeprecationWarning(fnName, deprecatedAPIs[fnName]);
		ComponentDummy.prototype = Component.prototype;
		deprecatedAPIs = PureComponent.prototype = new ComponentDummy();
		deprecatedAPIs.constructor = PureComponent;
		assign(deprecatedAPIs, Component.prototype);
		deprecatedAPIs.isPureReactComponent = !0;
		var isArrayImpl = Array.isArray;
		var REACT_CLIENT_REFERENCE = Symbol.for("react.client.reference");
		var ReactSharedInternals = {
			H: null,
			A: null,
			T: null,
			S: null,
			actQueue: null,
			asyncTransitions: 0,
			isBatchingLegacy: !1,
			didScheduleLegacyUpdate: !1,
			didUsePromise: !1,
			thrownErrors: [],
			getCurrentStack: null,
			recentlyCreatedOwnerStacks: 0
		};
		var hasOwnProperty = Object.prototype.hasOwnProperty;
		var createTask = console.createTask ? console.createTask : function() {
			return null;
		};
		deprecatedAPIs = { react_stack_bottom_frame: function(callStackForError) {
			return callStackForError();
		} };
		var specialPropKeyWarningShown;
		var didWarnAboutOldJSXRuntime;
		var didWarnAboutElementRef = {};
		var unknownOwnerDebugStack = deprecatedAPIs.react_stack_bottom_frame.bind(deprecatedAPIs, UnknownOwner)();
		var unknownOwnerDebugTask = createTask(getTaskName(UnknownOwner));
		var didWarnAboutMaps = !1;
		var userProvidedKeyEscapeRegex = /\/+/g;
		var reportGlobalError = "function" === typeof reportError ? reportError : function(error) {
			if ("object" === typeof window && "function" === typeof window.ErrorEvent) {
				var event = new window.ErrorEvent("error", {
					bubbles: !0,
					cancelable: !0,
					message: "object" === typeof error && null !== error && "string" === typeof error.message ? String(error.message) : String(error),
					error
				});
				if (!window.dispatchEvent(event)) return;
			} else if ("object" === typeof process && "function" === typeof process.emit) {
				process.emit("uncaughtException", error);
				return;
			}
			console.error(error);
		};
		var didWarnAboutMessageChannel = !1;
		var enqueueTaskImpl = null;
		var actScopeDepth = 0;
		var didWarnNoAwaitAct = !1;
		var isFlushing = !1;
		var queueSeveralMicrotasks = "function" === typeof queueMicrotask ? function(callback) {
			queueMicrotask(function() {
				return queueMicrotask(callback);
			});
		} : enqueueTask;
		deprecatedAPIs = Object.freeze({
			__proto__: null,
			c: function(size) {
				return resolveDispatcher().useMemoCache(size);
			}
		});
		var fnName = {
			map: mapChildren,
			forEach: function(children, forEachFunc, forEachContext) {
				mapChildren(children, function() {
					forEachFunc.apply(this, arguments);
				}, forEachContext);
			},
			count: function(children) {
				var n = 0;
				mapChildren(children, function() {
					n++;
				});
				return n;
			},
			toArray: function(children) {
				return mapChildren(children, function(child) {
					return child;
				}) || [];
			},
			only: function(children) {
				if (!isValidElement(children)) throw Error("React.Children.only expected to receive a single React element child.");
				return children;
			}
		};
		exports.Activity = REACT_ACTIVITY_TYPE;
		exports.Children = fnName;
		exports.Component = Component;
		exports.Fragment = REACT_FRAGMENT_TYPE;
		exports.Profiler = REACT_PROFILER_TYPE;
		exports.PureComponent = PureComponent;
		exports.StrictMode = REACT_STRICT_MODE_TYPE;
		exports.Suspense = REACT_SUSPENSE_TYPE;
		exports.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = ReactSharedInternals;
		exports.__COMPILER_RUNTIME = deprecatedAPIs;
		exports.act = function(callback) {
			var prevActQueue = ReactSharedInternals.actQueue;
			var prevActScopeDepth = actScopeDepth;
			actScopeDepth++;
			var queue = ReactSharedInternals.actQueue = null !== prevActQueue ? prevActQueue : [];
			var didAwaitActCall = !1;
			try {
				var result = callback();
			} catch (error) {
				ReactSharedInternals.thrownErrors.push(error);
			}
			if (0 < ReactSharedInternals.thrownErrors.length) throw popActScope(prevActQueue, prevActScopeDepth), callback = aggregateErrors(ReactSharedInternals.thrownErrors), ReactSharedInternals.thrownErrors.length = 0, callback;
			if (null !== result && "object" === typeof result && "function" === typeof result.then) {
				var thenable = result;
				queueSeveralMicrotasks(function() {
					didAwaitActCall || didWarnNoAwaitAct || (didWarnNoAwaitAct = !0, console.error("You called act(async () => ...) without await. This could lead to unexpected testing behaviour, interleaving multiple act calls and mixing their scopes. You should - await act(async () => ...);"));
				});
				return { then: function(resolve, reject) {
					didAwaitActCall = !0;
					thenable.then(function(returnValue) {
						popActScope(prevActQueue, prevActScopeDepth);
						if (0 === prevActScopeDepth) {
							try {
								flushActQueue(queue), enqueueTask(function() {
									return recursivelyFlushAsyncActWork(returnValue, resolve, reject);
								});
							} catch (error$0) {
								ReactSharedInternals.thrownErrors.push(error$0);
							}
							if (0 < ReactSharedInternals.thrownErrors.length) {
								var _thrownError = aggregateErrors(ReactSharedInternals.thrownErrors);
								ReactSharedInternals.thrownErrors.length = 0;
								reject(_thrownError);
							}
						} else resolve(returnValue);
					}, function(error) {
						popActScope(prevActQueue, prevActScopeDepth);
						0 < ReactSharedInternals.thrownErrors.length ? (error = aggregateErrors(ReactSharedInternals.thrownErrors), ReactSharedInternals.thrownErrors.length = 0, reject(error)) : reject(error);
					});
				} };
			}
			var returnValue$jscomp$0 = result;
			popActScope(prevActQueue, prevActScopeDepth);
			0 === prevActScopeDepth && (flushActQueue(queue), 0 !== queue.length && queueSeveralMicrotasks(function() {
				didAwaitActCall || didWarnNoAwaitAct || (didWarnNoAwaitAct = !0, console.error("A component suspended inside an `act` scope, but the `act` call was not awaited. When testing React components that depend on asynchronous data, you must await the result:\n\nawait act(() => ...)"));
			}), ReactSharedInternals.actQueue = null);
			if (0 < ReactSharedInternals.thrownErrors.length) throw callback = aggregateErrors(ReactSharedInternals.thrownErrors), ReactSharedInternals.thrownErrors.length = 0, callback;
			return { then: function(resolve, reject) {
				didAwaitActCall = !0;
				0 === prevActScopeDepth ? (ReactSharedInternals.actQueue = queue, enqueueTask(function() {
					return recursivelyFlushAsyncActWork(returnValue$jscomp$0, resolve, reject);
				})) : resolve(returnValue$jscomp$0);
			} };
		};
		exports.cache = function(fn) {
			return function() {
				return fn.apply(null, arguments);
			};
		};
		exports.cacheSignal = function() {
			return null;
		};
		exports.captureOwnerStack = function() {
			var getCurrentStack = ReactSharedInternals.getCurrentStack;
			return null === getCurrentStack ? null : getCurrentStack();
		};
		exports.cloneElement = function(element, config, children) {
			if (null === element || void 0 === element) throw Error("The argument must be a React element, but you passed " + element + ".");
			var props = assign({}, element.props);
			var key = element.key;
			var owner = element._owner;
			if (null != config) {
				var JSCompiler_inline_result;
				a: {
					if (hasOwnProperty.call(config, "ref") && (JSCompiler_inline_result = Object.getOwnPropertyDescriptor(config, "ref").get) && JSCompiler_inline_result.isReactWarning) {
						JSCompiler_inline_result = !1;
						break a;
					}
					JSCompiler_inline_result = void 0 !== config.ref;
				}
				JSCompiler_inline_result && (owner = getOwner());
				hasValidKey(config) && (checkKeyStringCoercion(config.key), key = "" + config.key);
				for (propName in config) !hasOwnProperty.call(config, propName) || "key" === propName || "__self" === propName || "__source" === propName || "ref" === propName && void 0 === config.ref || (props[propName] = config[propName]);
			}
			var propName = arguments.length - 2;
			if (1 === propName) props.children = children;
			else if (1 < propName) {
				JSCompiler_inline_result = Array(propName);
				for (var i = 0; i < propName; i++) JSCompiler_inline_result[i] = arguments[i + 2];
				props.children = JSCompiler_inline_result;
			}
			props = ReactElement(element.type, key, props, owner, element._debugStack, element._debugTask);
			for (key = 2; key < arguments.length; key++) validateChildKeys(arguments[key]);
			return props;
		};
		exports.createContext = function(defaultValue) {
			defaultValue = {
				$$typeof: REACT_CONTEXT_TYPE,
				_currentValue: defaultValue,
				_currentValue2: defaultValue,
				_threadCount: 0,
				Provider: null,
				Consumer: null
			};
			defaultValue.Provider = defaultValue;
			defaultValue.Consumer = {
				$$typeof: REACT_CONSUMER_TYPE,
				_context: defaultValue
			};
			defaultValue._currentRenderer = null;
			defaultValue._currentRenderer2 = null;
			return defaultValue;
		};
		exports.createElement = function(type, config, children) {
			for (var i = 2; i < arguments.length; i++) validateChildKeys(arguments[i]);
			i = {};
			var key = null;
			if (null != config) for (propName in didWarnAboutOldJSXRuntime || !("__self" in config) || "key" in config || (didWarnAboutOldJSXRuntime = !0, console.warn("Your app (or one of its dependencies) is using an outdated JSX transform. Update to the modern JSX transform for faster performance: https://react.dev/link/new-jsx-transform")), hasValidKey(config) && (checkKeyStringCoercion(config.key), key = "" + config.key), config) hasOwnProperty.call(config, propName) && "key" !== propName && "__self" !== propName && "__source" !== propName && (i[propName] = config[propName]);
			var childrenLength = arguments.length - 2;
			if (1 === childrenLength) i.children = children;
			else if (1 < childrenLength) {
				for (var childArray = Array(childrenLength), _i = 0; _i < childrenLength; _i++) childArray[_i] = arguments[_i + 2];
				Object.freeze && Object.freeze(childArray);
				i.children = childArray;
			}
			if (type && type.defaultProps) for (propName in childrenLength = type.defaultProps, childrenLength) void 0 === i[propName] && (i[propName] = childrenLength[propName]);
			key && defineKeyPropWarningGetter(i, "function" === typeof type ? type.displayName || type.name || "Unknown" : type);
			var propName = 1e4 > ReactSharedInternals.recentlyCreatedOwnerStacks++;
			return ReactElement(type, key, i, getOwner(), propName ? Error("react-stack-top-frame") : unknownOwnerDebugStack, propName ? createTask(getTaskName(type)) : unknownOwnerDebugTask);
		};
		exports.createRef = function() {
			var refObject = { current: null };
			Object.seal(refObject);
			return refObject;
		};
		exports.forwardRef = function(render) {
			null != render && render.$$typeof === REACT_MEMO_TYPE ? console.error("forwardRef requires a render function but received a `memo` component. Instead of forwardRef(memo(...)), use memo(forwardRef(...)).") : "function" !== typeof render ? console.error("forwardRef requires a render function but was given %s.", null === render ? "null" : typeof render) : 0 !== render.length && 2 !== render.length && console.error("forwardRef render functions accept exactly two parameters: props and ref. %s", 1 === render.length ? "Did you forget to use the ref parameter?" : "Any additional parameter will be undefined.");
			null != render && null != render.defaultProps && console.error("forwardRef render functions do not support defaultProps. Did you accidentally pass a React component?");
			var elementType = {
				$$typeof: REACT_FORWARD_REF_TYPE,
				render
			};
			var ownName;
			Object.defineProperty(elementType, "displayName", {
				enumerable: !1,
				configurable: !0,
				get: function() {
					return ownName;
				},
				set: function(name) {
					ownName = name;
					render.name || render.displayName || (Object.defineProperty(render, "name", { value: name }), render.displayName = name);
				}
			});
			return elementType;
		};
		exports.isValidElement = isValidElement;
		exports.lazy = function(ctor) {
			ctor = {
				_status: -1,
				_result: ctor
			};
			var lazyType = {
				$$typeof: REACT_LAZY_TYPE,
				_payload: ctor,
				_init: lazyInitializer
			};
			var ioInfo = {
				name: "lazy",
				start: -1,
				end: -1,
				value: null,
				owner: null,
				debugStack: Error("react-stack-top-frame"),
				debugTask: console.createTask ? console.createTask("lazy()") : null
			};
			ctor._ioInfo = ioInfo;
			lazyType._debugInfo = [{ awaited: ioInfo }];
			return lazyType;
		};
		exports.memo = function(type, compare) {
			type ?? console.error("memo: The first argument must be a component. Instead received: %s", null === type ? "null" : typeof type);
			compare = {
				$$typeof: REACT_MEMO_TYPE,
				type,
				compare: void 0 === compare ? null : compare
			};
			var ownName;
			Object.defineProperty(compare, "displayName", {
				enumerable: !1,
				configurable: !0,
				get: function() {
					return ownName;
				},
				set: function(name) {
					ownName = name;
					type.name || type.displayName || (Object.defineProperty(type, "name", { value: name }), type.displayName = name);
				}
			});
			return compare;
		};
		exports.startTransition = function(scope) {
			var prevTransition = ReactSharedInternals.T;
			var currentTransition = {};
			currentTransition._updatedFibers = /* @__PURE__ */ new Set();
			ReactSharedInternals.T = currentTransition;
			try {
				var returnValue = scope();
				var onStartTransitionFinish = ReactSharedInternals.S;
				null !== onStartTransitionFinish && onStartTransitionFinish(currentTransition, returnValue);
				"object" === typeof returnValue && null !== returnValue && "function" === typeof returnValue.then && (ReactSharedInternals.asyncTransitions++, returnValue.then(releaseAsyncTransition, releaseAsyncTransition), returnValue.then(noop, reportGlobalError));
			} catch (error) {
				reportGlobalError(error);
			} finally {
				null === prevTransition && currentTransition._updatedFibers && (scope = currentTransition._updatedFibers.size, currentTransition._updatedFibers.clear(), 10 < scope && console.warn("Detected a large number of updates inside startTransition. If this is due to a subscription please re-write it to use React provided hooks. Otherwise concurrent mode guarantees are off the table.")), null !== prevTransition && null !== currentTransition.types && (null !== prevTransition.types && prevTransition.types !== currentTransition.types && console.error("We expected inner Transitions to have transferred the outer types set and that you cannot add to the outer Transition while inside the inner.This is a bug in React."), prevTransition.types = currentTransition.types), ReactSharedInternals.T = prevTransition;
			}
		};
		exports.unstable_useCacheRefresh = function() {
			return resolveDispatcher().useCacheRefresh();
		};
		exports.use = function(usable) {
			return resolveDispatcher().use(usable);
		};
		exports.useActionState = function(action, initialState, permalink) {
			return resolveDispatcher().useActionState(action, initialState, permalink);
		};
		exports.useCallback = function(callback, deps) {
			return resolveDispatcher().useCallback(callback, deps);
		};
		exports.useContext = function(Context) {
			var dispatcher = resolveDispatcher();
			Context.$$typeof === REACT_CONSUMER_TYPE && console.error("Calling useContext(Context.Consumer) is not supported and will cause bugs. Did you mean to call useContext(Context) instead?");
			return dispatcher.useContext(Context);
		};
		exports.useDebugValue = function(value, formatterFn) {
			return resolveDispatcher().useDebugValue(value, formatterFn);
		};
		exports.useDeferredValue = function(value, initialValue) {
			return resolveDispatcher().useDeferredValue(value, initialValue);
		};
		exports.useEffect = function(create, deps) {
			create ?? console.warn("React Hook useEffect requires an effect callback. Did you forget to pass a callback to the hook?");
			return resolveDispatcher().useEffect(create, deps);
		};
		exports.useEffectEvent = function(callback) {
			return resolveDispatcher().useEffectEvent(callback);
		};
		exports.useId = function() {
			return resolveDispatcher().useId();
		};
		exports.useImperativeHandle = function(ref, create, deps) {
			return resolveDispatcher().useImperativeHandle(ref, create, deps);
		};
		exports.useInsertionEffect = function(create, deps) {
			create ?? console.warn("React Hook useInsertionEffect requires an effect callback. Did you forget to pass a callback to the hook?");
			return resolveDispatcher().useInsertionEffect(create, deps);
		};
		exports.useLayoutEffect = function(create, deps) {
			create ?? console.warn("React Hook useLayoutEffect requires an effect callback. Did you forget to pass a callback to the hook?");
			return resolveDispatcher().useLayoutEffect(create, deps);
		};
		exports.useMemo = function(create, deps) {
			return resolveDispatcher().useMemo(create, deps);
		};
		exports.useOptimistic = function(passthrough, reducer) {
			return resolveDispatcher().useOptimistic(passthrough, reducer);
		};
		exports.useReducer = function(reducer, initialArg, init) {
			return resolveDispatcher().useReducer(reducer, initialArg, init);
		};
		exports.useRef = function(initialValue) {
			return resolveDispatcher().useRef(initialValue);
		};
		exports.useState = function(initialState) {
			return resolveDispatcher().useState(initialState);
		};
		exports.useSyncExternalStore = function(subscribe, getSnapshot, getServerSnapshot) {
			return resolveDispatcher().useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
		};
		exports.useTransition = function() {
			return resolveDispatcher().useTransition();
		};
		exports.version = "19.2.4";
		"undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(Error());
	})();
}));
var require_react = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = require_react_development();
}));
var import_react$5;
var init_assertEnvironment = __esmMin((() => {
	init_mobx_esm();
	import_react$5 = /* @__PURE__ */ __toESM(require_react());
	if (!import_react$5.useState) throw new Error("mobx-react-lite requires React with Hooks support");
	if (!makeObservable) throw new Error("mobx-react-lite@3 requires mobx at least version 6 to be available");
}));
/**
* @license React
* react-dom.development.js
*
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*/
var require_react_dom_development = /* @__PURE__ */ __commonJSMin(((exports) => {
	(function() {
		function noop() {}
		function testStringCoercion(value) {
			return "" + value;
		}
		function createPortal$1(children, containerInfo, implementation) {
			var key = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : null;
			try {
				testStringCoercion(key);
				var JSCompiler_inline_result = !1;
			} catch (e) {
				JSCompiler_inline_result = !0;
			}
			JSCompiler_inline_result && (console.error("The provided key is an unsupported type %s. This value must be coerced to a string before using it here.", "function" === typeof Symbol && Symbol.toStringTag && key[Symbol.toStringTag] || key.constructor.name || "Object"), testStringCoercion(key));
			return {
				$$typeof: REACT_PORTAL_TYPE,
				key: null == key ? null : "" + key,
				children,
				containerInfo,
				implementation
			};
		}
		function getCrossOriginStringAs(as, input) {
			if ("font" === as) return "";
			if ("string" === typeof input) return "use-credentials" === input ? input : "";
		}
		function getValueDescriptorExpectingObjectForWarning(thing) {
			return null === thing ? "`null`" : void 0 === thing ? "`undefined`" : "" === thing ? "an empty string" : "something with type \"" + typeof thing + "\"";
		}
		function getValueDescriptorExpectingEnumForWarning(thing) {
			return null === thing ? "`null`" : void 0 === thing ? "`undefined`" : "" === thing ? "an empty string" : "string" === typeof thing ? JSON.stringify(thing) : "number" === typeof thing ? "`" + thing + "`" : "something with type \"" + typeof thing + "\"";
		}
		function resolveDispatcher() {
			var dispatcher = ReactSharedInternals.H;
			null === dispatcher && console.error("Invalid hook call. Hooks can only be called inside of the body of a function component. This could happen for one of the following reasons:\n1. You might have mismatching versions of React and the renderer (such as React DOM)\n2. You might be breaking the Rules of Hooks\n3. You might have more than one copy of React in the same app\nSee https://react.dev/link/invalid-hook-call for tips about how to debug and fix this problem.");
			return dispatcher;
		}
		"undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(Error());
		var React = require_react();
		var Internals = {
			d: {
				f: noop,
				r: function() {
					throw Error("Invalid form element. requestFormReset must be passed a form that was rendered by React.");
				},
				D: noop,
				C: noop,
				L: noop,
				m: noop,
				X: noop,
				S: noop,
				M: noop
			},
			p: 0,
			findDOMNode: null
		};
		var REACT_PORTAL_TYPE = Symbol.for("react.portal");
		var ReactSharedInternals = React.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;
		"function" === typeof Map && null != Map.prototype && "function" === typeof Map.prototype.forEach && "function" === typeof Set && null != Set.prototype && "function" === typeof Set.prototype.clear && "function" === typeof Set.prototype.forEach || console.error("React depends on Map and Set built-in types. Make sure that you load a polyfill in older browsers. https://reactjs.org/link/react-polyfills");
		exports.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = Internals;
		exports.createPortal = function(children, container) {
			var key = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : null;
			if (!container || 1 !== container.nodeType && 9 !== container.nodeType && 11 !== container.nodeType) throw Error("Target container is not a DOM element.");
			return createPortal$1(children, container, null, key);
		};
		exports.flushSync = function(fn) {
			var previousTransition = ReactSharedInternals.T;
			var previousUpdatePriority = Internals.p;
			try {
				if (ReactSharedInternals.T = null, Internals.p = 2, fn) return fn();
			} finally {
				ReactSharedInternals.T = previousTransition, Internals.p = previousUpdatePriority, Internals.d.f() && console.error("flushSync was called from inside a lifecycle method. React cannot flush when React is already rendering. Consider moving this call to a scheduler task or micro task.");
			}
		};
		exports.preconnect = function(href, options) {
			"string" === typeof href && href ? null != options && "object" !== typeof options ? console.error("ReactDOM.preconnect(): Expected the `options` argument (second) to be an object but encountered %s instead. The only supported option at this time is `crossOrigin` which accepts a string.", getValueDescriptorExpectingEnumForWarning(options)) : null != options && "string" !== typeof options.crossOrigin && console.error("ReactDOM.preconnect(): Expected the `crossOrigin` option (second argument) to be a string but encountered %s instead. Try removing this option or passing a string value instead.", getValueDescriptorExpectingObjectForWarning(options.crossOrigin)) : console.error("ReactDOM.preconnect(): Expected the `href` argument (first) to be a non-empty string but encountered %s instead.", getValueDescriptorExpectingObjectForWarning(href));
			"string" === typeof href && (options ? (options = options.crossOrigin, options = "string" === typeof options ? "use-credentials" === options ? options : "" : void 0) : options = null, Internals.d.C(href, options));
		};
		exports.prefetchDNS = function(href) {
			if ("string" !== typeof href || !href) console.error("ReactDOM.prefetchDNS(): Expected the `href` argument (first) to be a non-empty string but encountered %s instead.", getValueDescriptorExpectingObjectForWarning(href));
			else if (1 < arguments.length) {
				var options = arguments[1];
				"object" === typeof options && options.hasOwnProperty("crossOrigin") ? console.error("ReactDOM.prefetchDNS(): Expected only one argument, `href`, but encountered %s as a second argument instead. This argument is reserved for future options and is currently disallowed. It looks like the you are attempting to set a crossOrigin property for this DNS lookup hint. Browsers do not perform DNS queries using CORS and setting this attribute on the resource hint has no effect. Try calling ReactDOM.prefetchDNS() with just a single string argument, `href`.", getValueDescriptorExpectingEnumForWarning(options)) : console.error("ReactDOM.prefetchDNS(): Expected only one argument, `href`, but encountered %s as a second argument instead. This argument is reserved for future options and is currently disallowed. Try calling ReactDOM.prefetchDNS() with just a single string argument, `href`.", getValueDescriptorExpectingEnumForWarning(options));
			}
			"string" === typeof href && Internals.d.D(href);
		};
		exports.preinit = function(href, options) {
			"string" === typeof href && href ? null == options || "object" !== typeof options ? console.error("ReactDOM.preinit(): Expected the `options` argument (second) to be an object with an `as` property describing the type of resource to be preinitialized but encountered %s instead.", getValueDescriptorExpectingEnumForWarning(options)) : "style" !== options.as && "script" !== options.as && console.error("ReactDOM.preinit(): Expected the `as` property in the `options` argument (second) to contain a valid value describing the type of resource to be preinitialized but encountered %s instead. Valid values for `as` are \"style\" and \"script\".", getValueDescriptorExpectingEnumForWarning(options.as)) : console.error("ReactDOM.preinit(): Expected the `href` argument (first) to be a non-empty string but encountered %s instead.", getValueDescriptorExpectingObjectForWarning(href));
			if ("string" === typeof href && options && "string" === typeof options.as) {
				var as = options.as;
				var crossOrigin = getCrossOriginStringAs(as, options.crossOrigin);
				var integrity = "string" === typeof options.integrity ? options.integrity : void 0;
				var fetchPriority = "string" === typeof options.fetchPriority ? options.fetchPriority : void 0;
				"style" === as ? Internals.d.S(href, "string" === typeof options.precedence ? options.precedence : void 0, {
					crossOrigin,
					integrity,
					fetchPriority
				}) : "script" === as && Internals.d.X(href, {
					crossOrigin,
					integrity,
					fetchPriority,
					nonce: "string" === typeof options.nonce ? options.nonce : void 0
				});
			}
		};
		exports.preinitModule = function(href, options) {
			var encountered = "";
			"string" === typeof href && href || (encountered += " The `href` argument encountered was " + getValueDescriptorExpectingObjectForWarning(href) + ".");
			void 0 !== options && "object" !== typeof options ? encountered += " The `options` argument encountered was " + getValueDescriptorExpectingObjectForWarning(options) + "." : options && "as" in options && "script" !== options.as && (encountered += " The `as` option encountered was " + getValueDescriptorExpectingEnumForWarning(options.as) + ".");
			if (encountered) console.error("ReactDOM.preinitModule(): Expected up to two arguments, a non-empty `href` string and, optionally, an `options` object with a valid `as` property.%s", encountered);
			else switch (encountered = options && "string" === typeof options.as ? options.as : "script", encountered) {
				case "script": break;
				default: encountered = getValueDescriptorExpectingEnumForWarning(encountered), console.error("ReactDOM.preinitModule(): Currently the only supported \"as\" type for this function is \"script\" but received \"%s\" instead. This warning was generated for `href` \"%s\". In the future other module types will be supported, aligning with the import-attributes proposal. Learn more here: (https://github.com/tc39/proposal-import-attributes)", encountered, href);
			}
			if ("string" === typeof href) if ("object" === typeof options && null !== options) {
				if (null == options.as || "script" === options.as) encountered = getCrossOriginStringAs(options.as, options.crossOrigin), Internals.d.M(href, {
					crossOrigin: encountered,
					integrity: "string" === typeof options.integrity ? options.integrity : void 0,
					nonce: "string" === typeof options.nonce ? options.nonce : void 0
				});
			} else options ?? Internals.d.M(href);
		};
		exports.preload = function(href, options) {
			var encountered = "";
			"string" === typeof href && href || (encountered += " The `href` argument encountered was " + getValueDescriptorExpectingObjectForWarning(href) + ".");
			null == options || "object" !== typeof options ? encountered += " The `options` argument encountered was " + getValueDescriptorExpectingObjectForWarning(options) + "." : "string" === typeof options.as && options.as || (encountered += " The `as` option encountered was " + getValueDescriptorExpectingObjectForWarning(options.as) + ".");
			encountered && console.error("ReactDOM.preload(): Expected two arguments, a non-empty `href` string and an `options` object with an `as` property valid for a `<link rel=\"preload\" as=\"...\" />` tag.%s", encountered);
			if ("string" === typeof href && "object" === typeof options && null !== options && "string" === typeof options.as) {
				encountered = options.as;
				var crossOrigin = getCrossOriginStringAs(encountered, options.crossOrigin);
				Internals.d.L(href, encountered, {
					crossOrigin,
					integrity: "string" === typeof options.integrity ? options.integrity : void 0,
					nonce: "string" === typeof options.nonce ? options.nonce : void 0,
					type: "string" === typeof options.type ? options.type : void 0,
					fetchPriority: "string" === typeof options.fetchPriority ? options.fetchPriority : void 0,
					referrerPolicy: "string" === typeof options.referrerPolicy ? options.referrerPolicy : void 0,
					imageSrcSet: "string" === typeof options.imageSrcSet ? options.imageSrcSet : void 0,
					imageSizes: "string" === typeof options.imageSizes ? options.imageSizes : void 0,
					media: "string" === typeof options.media ? options.media : void 0
				});
			}
		};
		exports.preloadModule = function(href, options) {
			var encountered = "";
			"string" === typeof href && href || (encountered += " The `href` argument encountered was " + getValueDescriptorExpectingObjectForWarning(href) + ".");
			void 0 !== options && "object" !== typeof options ? encountered += " The `options` argument encountered was " + getValueDescriptorExpectingObjectForWarning(options) + "." : options && "as" in options && "string" !== typeof options.as && (encountered += " The `as` option encountered was " + getValueDescriptorExpectingObjectForWarning(options.as) + ".");
			encountered && console.error("ReactDOM.preloadModule(): Expected two arguments, a non-empty `href` string and, optionally, an `options` object with an `as` property valid for a `<link rel=\"modulepreload\" as=\"...\" />` tag.%s", encountered);
			"string" === typeof href && (options ? (encountered = getCrossOriginStringAs(options.as, options.crossOrigin), Internals.d.m(href, {
				as: "string" === typeof options.as && "script" !== options.as ? options.as : void 0,
				crossOrigin: encountered,
				integrity: "string" === typeof options.integrity ? options.integrity : void 0
			})) : Internals.d.m(href));
		};
		exports.requestFormReset = function(form) {
			Internals.d.r(form);
		};
		exports.unstable_batchedUpdates = function(fn, a) {
			return fn(a);
		};
		exports.useFormState = function(action, initialState, permalink) {
			return resolveDispatcher().useFormState(action, initialState, permalink);
		};
		exports.useFormStatus = function() {
			return resolveDispatcher().useHostTransitionStatus();
		};
		exports.version = "19.2.4";
		"undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(Error());
	})();
}));
var require_react_dom = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = require_react_dom_development();
}));
var import_react_dom;
var init_reactBatchedUpdates = __esmMin((() => {
	import_react_dom = require_react_dom();
}));
function defaultNoopBatch(callback) {
	callback();
}
function observerBatching(reactionScheduler) {
	if (!reactionScheduler) {
		reactionScheduler = defaultNoopBatch;
		console.warn("[MobX] Failed to get unstable_batched updates from react-dom / react-native");
	}
	configure({ reactionScheduler });
}
var init_observerBatching = __esmMin((() => {
	init_mobx_esm();
}));
var init_utils = __esmMin((() => {}));
function printDebugValue(v) {
	return getDependencyTree(v);
}
var init_printDebugValue = __esmMin((() => {
	init_mobx_esm();
}));
function isUsingStaticRendering() {
	return globalIsUsingStaticRendering;
}
var globalIsUsingStaticRendering;
var init_staticRendering = __esmMin((() => {
	globalIsUsingStaticRendering = false;
}));
var REGISTRY_FINALIZE_AFTER;
var REGISTRY_SWEEP_INTERVAL;
var TimerBasedFinalizationRegistry;
var UniversalFinalizationRegistry;
var init_UniversalFinalizationRegistry = __esmMin((() => {
	REGISTRY_FINALIZE_AFTER = 1e4;
	REGISTRY_SWEEP_INTERVAL = 1e4;
	TimerBasedFinalizationRegistry = function() {
		function TimerBasedFinalizationRegistry(finalize) {
			var _this = this;
			Object.defineProperty(this, "finalize", {
				enumerable: true,
				configurable: true,
				writable: true,
				value: finalize
			});
			Object.defineProperty(this, "registrations", {
				enumerable: true,
				configurable: true,
				writable: true,
				value: /* @__PURE__ */ new Map()
			});
			Object.defineProperty(this, "sweepTimeout", {
				enumerable: true,
				configurable: true,
				writable: true,
				value: void 0
			});
			Object.defineProperty(this, "sweep", {
				enumerable: true,
				configurable: true,
				writable: true,
				value: function(maxAge) {
					if (maxAge === void 0) maxAge = REGISTRY_FINALIZE_AFTER;
					clearTimeout(_this.sweepTimeout);
					_this.sweepTimeout = void 0;
					var now = Date.now();
					_this.registrations.forEach(function(registration, token) {
						if (now - registration.registeredAt >= maxAge) {
							_this.finalize(registration.value);
							_this.registrations.delete(token);
						}
					});
					if (_this.registrations.size > 0) _this.scheduleSweep();
				}
			});
			Object.defineProperty(this, "finalizeAllImmediately", {
				enumerable: true,
				configurable: true,
				writable: true,
				value: function() {
					_this.sweep(0);
				}
			});
		}
		Object.defineProperty(TimerBasedFinalizationRegistry.prototype, "register", {
			enumerable: false,
			configurable: true,
			writable: true,
			value: function(target, value, token) {
				this.registrations.set(token, {
					value,
					registeredAt: Date.now()
				});
				this.scheduleSweep();
			}
		});
		Object.defineProperty(TimerBasedFinalizationRegistry.prototype, "unregister", {
			enumerable: false,
			configurable: true,
			writable: true,
			value: function(token) {
				this.registrations.delete(token);
			}
		});
		Object.defineProperty(TimerBasedFinalizationRegistry.prototype, "scheduleSweep", {
			enumerable: false,
			configurable: true,
			writable: true,
			value: function() {
				if (this.sweepTimeout === void 0) this.sweepTimeout = setTimeout(this.sweep, REGISTRY_SWEEP_INTERVAL);
			}
		});
		return TimerBasedFinalizationRegistry;
	}();
	UniversalFinalizationRegistry = typeof FinalizationRegistry !== "undefined" ? FinalizationRegistry : TimerBasedFinalizationRegistry;
}));
var observerFinalizationRegistry;
var init_observerFinalizationRegistry = __esmMin((() => {
	init_UniversalFinalizationRegistry();
	observerFinalizationRegistry = new UniversalFinalizationRegistry(function(adm) {
		var _a;
		(_a = adm.reaction) === null || _a === void 0 || _a.dispose();
		adm.reaction = null;
	});
}));
/**
* @license React
* use-sync-external-store-shim.development.js
*
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*/
var require_use_sync_external_store_shim_development = /* @__PURE__ */ __commonJSMin(((exports) => {
	(function() {
		function is(x, y) {
			return x === y && (0 !== x || 1 / x === 1 / y) || x !== x && y !== y;
		}
		function useSyncExternalStore$2(subscribe, getSnapshot) {
			didWarnOld18Alpha || void 0 === React.startTransition || (didWarnOld18Alpha = !0, console.error("You are using an outdated, pre-release alpha of React 18 that does not support useSyncExternalStore. The use-sync-external-store shim will not work correctly. Upgrade to a newer pre-release."));
			var value = getSnapshot();
			if (!didWarnUncachedGetSnapshot) {
				var cachedValue = getSnapshot();
				objectIs(value, cachedValue) || (console.error("The result of getSnapshot should be cached to avoid an infinite loop"), didWarnUncachedGetSnapshot = !0);
			}
			cachedValue = useState({ inst: {
				value,
				getSnapshot
			} });
			var inst = cachedValue[0].inst;
			var forceUpdate = cachedValue[1];
			useLayoutEffect(function() {
				inst.value = value;
				inst.getSnapshot = getSnapshot;
				checkIfSnapshotChanged(inst) && forceUpdate({ inst });
			}, [
				subscribe,
				value,
				getSnapshot
			]);
			useEffect(function() {
				checkIfSnapshotChanged(inst) && forceUpdate({ inst });
				return subscribe(function() {
					checkIfSnapshotChanged(inst) && forceUpdate({ inst });
				});
			}, [subscribe]);
			useDebugValue(value);
			return value;
		}
		function checkIfSnapshotChanged(inst) {
			var latestGetSnapshot = inst.getSnapshot;
			inst = inst.value;
			try {
				var nextValue = latestGetSnapshot();
				return !objectIs(inst, nextValue);
			} catch (error) {
				return !0;
			}
		}
		function useSyncExternalStore$1(subscribe, getSnapshot) {
			return getSnapshot();
		}
		"undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(Error());
		var React = require_react();
		var objectIs = "function" === typeof Object.is ? Object.is : is;
		var useState = React.useState;
		var useEffect = React.useEffect;
		var useLayoutEffect = React.useLayoutEffect;
		var useDebugValue = React.useDebugValue;
		var didWarnOld18Alpha = !1;
		var didWarnUncachedGetSnapshot = !1;
		var shim = "undefined" === typeof window || "undefined" === typeof window.document || "undefined" === typeof window.document.createElement ? useSyncExternalStore$1 : useSyncExternalStore$2;
		exports.useSyncExternalStore = void 0 !== React.useSyncExternalStore ? React.useSyncExternalStore : shim;
		"undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(Error());
	})();
}));
var require_shim = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = require_use_sync_external_store_shim_development();
}));
function createReaction(adm) {
	adm.reaction = new Reaction("observer".concat(adm.name), function() {
		var _a;
		adm.stateVersion = Symbol();
		(_a = adm.onStoreChange) === null || _a === void 0 || _a.call(adm);
	});
}
function useObserver$1(render, baseComponentName) {
	if (baseComponentName === void 0) baseComponentName = "observed";
	if (isUsingStaticRendering()) return render();
	var admRef = import_react$4.useRef(null);
	if (!admRef.current) {
		var adm_1 = {
			reaction: null,
			onStoreChange: null,
			stateVersion: Symbol(),
			name: baseComponentName,
			subscribe: function(onStoreChange) {
				observerFinalizationRegistry.unregister(adm_1);
				adm_1.onStoreChange = onStoreChange;
				if (!adm_1.reaction) {
					createReaction(adm_1);
					adm_1.stateVersion = Symbol();
				}
				return function() {
					var _a;
					adm_1.onStoreChange = null;
					(_a = adm_1.reaction) === null || _a === void 0 || _a.dispose();
					adm_1.reaction = null;
				};
			},
			getSnapshot: function() {
				return adm_1.stateVersion;
			}
		};
		admRef.current = adm_1;
	}
	var adm = admRef.current;
	if (!adm.reaction) {
		createReaction(adm);
		observerFinalizationRegistry.register(admRef, adm, adm);
	}
	import_react$4.useDebugValue(adm.reaction, printDebugValue);
	(0, import_shim.useSyncExternalStore)(adm.subscribe, adm.getSnapshot, adm.getSnapshot);
	var renderResult;
	var exception;
	adm.reaction.track(function() {
		try {
			renderResult = render();
		} catch (e) {
			exception = e;
		}
	});
	if (exception) throw exception;
	return renderResult;
}
var import_react$4;
var import_shim;
var init_useObserver = __esmMin((() => {
	init_mobx_esm();
	import_react$4 = /* @__PURE__ */ __toESM(require_react());
	init_printDebugValue();
	init_staticRendering();
	init_observerFinalizationRegistry();
	import_shim = require_shim();
	__name(useObserver$1, "useObserver");
}));
var import_react$3;
var _a$1;
var hasSymbol;
var init_observer = __esmMin((() => {
	import_react$3 = /* @__PURE__ */ __toESM(require_react());
	init_staticRendering();
	init_useObserver();
	hasSymbol = typeof Symbol === "function" && Symbol.for;
	(_a$1 = Object.getOwnPropertyDescriptor(function() {}, "name")) === null || _a$1 === void 0 || _a$1.configurable;
	hasSymbol || typeof import_react$3.forwardRef === "function" && (0, import_react$3.forwardRef)(function(props) {
		return null;
	})["$$typeof"];
	hasSymbol || typeof import_react$3.memo === "function" && (0, import_react$3.memo)(function(props) {
		return null;
	})["$$typeof"];
}));
function ObserverComponent(_a) {
	var children = _a.children;
	var render = _a.render;
	if (children && render) console.error("MobX Observer: Do not use children and render in the same time in `Observer`");
	var component = children || render;
	if (typeof component !== "function") return null;
	return useObserver$1(component);
}
function ObserverPropsCheck(props, key, componentName, location, propFullName) {
	var extraKey = key === "children" ? "render" : "children";
	var hasProp = typeof props[key] === "function";
	var hasExtraProp = typeof props[extraKey] === "function";
	if (hasProp && hasExtraProp) return /* @__PURE__ */ new Error("MobX Observer: Do not use children and render in the same time in`" + componentName);
	if (hasProp || hasExtraProp) return null;
	return /* @__PURE__ */ new Error("Invalid prop `" + propFullName + "` of type `" + typeof props[key] + "` supplied to `" + componentName + "`, expected `function`.");
}
var init_ObserverComponent = __esmMin((() => {
	init_useObserver();
	ObserverComponent.propTypes = {
		children: ObserverPropsCheck,
		render: ObserverPropsCheck
	};
	ObserverComponent.displayName = "Observer";
}));
var init_useLocalObservable = __esmMin((() => {
	init_mobx_esm();
	require_react();
}));
var init_useAsObservableSource = __esmMin((() => {
	init_utils();
	init_mobx_esm();
	require_react();
}));
var init_useLocalStore = __esmMin((() => {
	init_mobx_esm();
	require_react();
	init_utils();
	init_useAsObservableSource();
}));
__esmMin((() => {
	init_assertEnvironment();
	init_reactBatchedUpdates();
	init_observerBatching();
	init_utils();
	init_useObserver();
	init_staticRendering();
	init_observerFinalizationRegistry();
	init_observer();
	init_ObserverComponent();
	init_useLocalObservable();
	init_useLocalStore();
	init_useAsObservableSource();
	observerBatching(import_react_dom.unstable_batchedUpdates);
	observerFinalizationRegistry["finalizeAllImmediately"];
}));
var mobxReactLite;
var react;
var reactDom;
var reactDomClient;
var reactJsxRuntime;
var Libs;
var init_libs_ex = __esmMin((() => {
	init_mobx_esm();
	init_yjs();
	mobxReactLite = null;
	react = null;
	reactDom = null;
	reactDomClient = null;
	reactJsxRuntime = null;
	Libs = class extends ex.Unit {
		mobx = mobx_esm_exports;
		mobxReactLite = mobxReactLite;
		react = react;
		reactDom = reactDom;
		reactDomClient = reactDomClient;
		reactJsxRuntime = reactJsxRuntime;
		yjs = yjs_exports;
		constructor(parent) {
			super(parent);
			configure({ enforceActions: "never" });
		}
	};
}));
var _cbId_;
var ProjectBrowser;
var init_project_browser_ex = __esmMin((() => {
	_cbId_ = Symbol("id");
	ProjectBrowser = class extends ex.Unit {
		$project = this.closest(ex.Project);
		#api = {};
		callbacks = {};
		static _cbId_ = _cbId_;
		sw = this.use("sw", this.$project.id);
		get api() {
			if (!this.#api) throw this.never();
			return this.#api;
		}
		async init() {
			this.expose(this.$project.id);
			await this.resetApi();
		}
		createMethod(path) {
			return this.callMethod.bind(this, path);
		}
		createEvent(path) {
			return {
				addListener: this.addListener.bind(this, path),
				hasListener: this.hasListener.bind(this, path),
				hasListeners: this.hasListeners.bind(this, path),
				removeListener: this.removeListener.bind(this, path),
				dispatch: this.callMethod.bind(this, `${path}.dispatch`)
			};
		}
		async callMethod(path, ...args) {
			return await this.sw.callMethod(path, ...args);
		}
		addListener(path, cb) {
			if (!cb) return;
			cb[_cbId_] ??= this.$.utils.generateId();
			const listenerId = this.buildListenerId(path, cb);
			if (this.callbacks[listenerId]) return;
			this.callbacks[listenerId] = cb;
			this.sw.addListener(path, this.$.peer.id, listenerId);
		}
		hasListener(path, cb) {
			if (!cb || !cb[_cbId_]) return false;
			return this.buildListenerId(path, cb) in this.callbacks;
		}
		hasListeners(path) {
			return Object.keys(this.callbacks).some((id) => id.startsWith(`${path}[`));
		}
		removeListener(path, cb) {
			if (!cb || !cb[_cbId_]) return;
			const listenerId = this.buildListenerId(path, cb);
			if (!(listenerId in this.callbacks)) return;
			delete this.callbacks[listenerId];
			this.sw.removeListener(listenerId);
		}
		async executeListenerCallback(listenerId, ...args) {
			const cb = this.callbacks[listenerId];
			if (!cb) return;
			return await cb(...args);
		}
		buildListenerId(path, cb) {
			return `${path}[${cb[_cbId_]}]`;
		}
		async resetApi() {
			const manifest = await this.callMethod("runtime.getManifest");
			if (!this.$.utils.is.object(manifest)) throw this.never();
			const tree = await this.sw.getApiTree();
			const permissions = await this.sw.getPermissions();
			const hasPermission = (permission) => permissions.includes(permission);
			const api = {
				action: {
					disable: this.createMethod("action.disable"),
					enable: this.createMethod("action.enable"),
					getBadgeBackgroundColor: this.createMethod("action.getBadgeBackgroundColor"),
					getBadgeText: this.createMethod("action.getBadgeText"),
					getBadgeTextColor: this.createMethod("action.getBadgeTextColor"),
					getPopup: this.createMethod("action.getPopup"),
					getTitle: this.createMethod("action.getTitle"),
					getUserSettings: this.createMethod("action.getUserSettings"),
					isEnabled: this.createMethod("action.isEnabled"),
					setBadgeBackgroundColor: this.createMethod("action.setBadgeBackgroundColor"),
					setBadgeText: this.createMethod("action.setBadgeText"),
					setBadgeTextColor: this.createMethod("action.setBadgeTextColor"),
					setIcon: this.createMethod("action.setIcon"),
					setPopup: this.createMethod("action.setPopup"),
					setTitle: this.createMethod("action.setTitle"),
					onClicked: this.createEvent("action.onClicked"),
					onUserSettingsChanged: this.createEvent("action.onUserSettingsChanged")
				},
				alarms: {
					clear: this.createMethod("alarms.clear"),
					clearAll: this.createMethod("alarms.clearAll"),
					create: this.createMethod("alarms.create"),
					get: this.createMethod("alarms.get"),
					getAll: this.createMethod("alarms.getAll"),
					onAlarm: this.createEvent("alarms.onAlarm")
				},
				...hasPermission("browsingData") && { browsingData: {
					remove: this.createMethod("browsingData.remove"),
					removeAppcache: this.createMethod("browsingData.removeAppcache"),
					removeCache: this.createMethod("browsingData.removeCache"),
					removeCacheStorage: this.createMethod("browsingData.removeCacheStorage"),
					removeCookies: this.createMethod("browsingData.removeCookies"),
					removeDownloads: this.createMethod("browsingData.removeDownloads"),
					removeFileSystems: this.createMethod("browsingData.removeFileSystems"),
					removeFormData: this.createMethod("browsingData.removeFormData"),
					removeHistory: this.createMethod("browsingData.removeHistory"),
					removeIndexedDB: this.createMethod("browsingData.removeIndexedDB"),
					removeLocalStorage: this.createMethod("browsingData.removeLocalStorage"),
					removeServiceWorkers: this.createMethod("browsingData.removeServiceWorkers"),
					removeWebSQL: this.createMethod("browsingData.removeWebSQL"),
					settings: this.createMethod("browsingData.settings")
				} },
				...hasPermission("contextMenus") && { contextMenus: {
					create: this.createMethod("contextMenus.create"),
					remove: this.createMethod("contextMenus.remove"),
					removeAll: this.createMethod("contextMenus.removeAll"),
					update: this.createMethod("contextMenus.update"),
					onClicked: this.createEvent("contextMenus.onClicked"),
					ContextType: tree.contextMenus.ContextType,
					ItemType: tree.contextMenus.ItemType,
					ACTION_MENU_TOP_LEVEL_LIMIT: tree.contextMenus.ACTION_MENU_TOP_LEVEL_LIMIT
				} },
				...hasPermission("cookies") && { cookies: {
					get: this.createMethod("cookies.get"),
					getAll: this.createMethod("cookies.getAll"),
					getAllCookieStores: this.createMethod("cookies.getAllCookieStores"),
					getPartitionKey: this.createMethod("cookies.getPartitionKey"),
					remove: this.createMethod("cookies.remove"),
					set: this.createMethod("cookies.set"),
					onChanged: this.createEvent("cookies.onChanged"),
					OnChangedCause: tree.cookies.OnChangedCause,
					SameSiteStatus: tree.cookies.SameSiteStatus
				} },
				...hasPermission("declarativeNetRequest") && { declarativeNetRequest: {
					getDynamicRules: this.createMethod("declarativeNetRequest.getDynamicRules"),
					getSessionRules: this.createMethod("declarativeNetRequest.getSessionRules"),
					isRegexSupported: this.createMethod("declarativeNetRequest.isRegexSupported"),
					updateDynamicRules: this.createMethod("declarativeNetRequest.updateDynamicRules"),
					updateSessionRules: this.createMethod("declarativeNetRequest.updateSessionRules"),
					DomainType: tree.declarativeNetRequest.DomainType,
					HeaderOperation: tree.declarativeNetRequest.HeaderOperation,
					RequestMethod: tree.declarativeNetRequest.RequestMethod,
					ResourceType: tree.declarativeNetRequest.ResourceType,
					RuleActionType: tree.declarativeNetRequest.RuleActionType,
					RuleConditionKeys: tree.declarativeNetRequest.RuleConditionKeys,
					UnsupportedRegexReason: tree.declarativeNetRequest.UnsupportedRegexReason,
					DYNAMIC_RULESET_ID: tree.declarativeNetRequest.DYNAMIC_RULESET_ID,
					GETMATCHEDRULES_QUOTA_INTERVAL: tree.declarativeNetRequest.GETMATCHEDRULES_QUOTA_INTERVAL,
					GUARANTEED_MINIMUM_STATIC_RULES: tree.declarativeNetRequest.GUARANTEED_MINIMUM_STATIC_RULES,
					MAX_GETMATCHEDRULES_CALLS_PER_INTERVAL: tree.declarativeNetRequest.MAX_GETMATCHEDRULES_CALLS_PER_INTERVAL,
					MAX_NUMBER_OF_DYNAMIC_AND_SESSION_RULES: tree.declarativeNetRequest.MAX_NUMBER_OF_DYNAMIC_AND_SESSION_RULES,
					MAX_NUMBER_OF_DYNAMIC_RULES: tree.declarativeNetRequest.MAX_NUMBER_OF_DYNAMIC_RULES,
					MAX_NUMBER_OF_ENABLED_STATIC_RULESETS: tree.declarativeNetRequest.MAX_NUMBER_OF_ENABLED_STATIC_RULESETS,
					MAX_NUMBER_OF_REGEX_RULES: tree.declarativeNetRequest.MAX_NUMBER_OF_REGEX_RULES,
					MAX_NUMBER_OF_SESSION_RULES: tree.declarativeNetRequest.MAX_NUMBER_OF_SESSION_RULES,
					MAX_NUMBER_OF_STATIC_RULESETS: tree.declarativeNetRequest.MAX_NUMBER_OF_STATIC_RULESETS,
					MAX_NUMBER_OF_UNSAFE_DYNAMIC_RULES: tree.declarativeNetRequest.MAX_NUMBER_OF_UNSAFE_DYNAMIC_RULES,
					MAX_NUMBER_OF_UNSAFE_SESSION_RULES: tree.declarativeNetRequest.MAX_NUMBER_OF_UNSAFE_SESSION_RULES,
					SESSION_RULESET_ID: tree.declarativeNetRequest.SESSION_RULESET_ID
				} },
				...hasPermission("downloads") && { downloads: {
					acceptDanger: this.createMethod("downloads.acceptDanger"),
					cancel: this.createMethod("downloads.cancel"),
					download: this.createMethod("downloads.download"),
					erase: this.createMethod("downloads.erase"),
					getFileIcon: this.createMethod("downloads.getFileIcon"),
					pause: this.createMethod("downloads.pause"),
					removeFile: this.createMethod("downloads.removeFile"),
					resume: this.createMethod("downloads.resume"),
					search: this.createMethod("downloads.search"),
					show: this.createMethod("downloads.show"),
					showDefaultFolder: this.createMethod("downloads.showDefaultFolder"),
					setUiOptions: async (options) => {
						if (hasPermission("downloads.ui")) return await this.callMethod("downloads.setUiOptions", options);
						throw new Error("downloads.setUiOptions requires the \"downloads.ui\" permission");
					},
					onChanged: this.createEvent("downloads.onChanged"),
					onCreated: this.createEvent("downloads.onCreated"),
					onDeterminingFilename: this.createEvent("downloads.onDeterminingFilename"),
					onErased: this.createEvent("downloads.onErased"),
					DangerType: tree.downloads.DangerType,
					FilenameConflictAction: tree.downloads.FilenameConflictAction,
					HttpMethod: tree.downloads.HttpMethod,
					InterruptReason: tree.downloads.InterruptReason,
					State: tree.downloads.State
				} },
				extension: {
					isAllowedFileSchemeAccess: this.createMethod("extension.isAllowedFileSchemeAccess"),
					isAllowedIncognitoAccess: this.createMethod("extension.isAllowedIncognitoAccess"),
					setUpdateUrlData: this.createMethod("extension.setUpdateUrlData"),
					inIncognitoContext: tree.extension.inIncognitoContext,
					ViewType: tree.extension.ViewType
				},
				i18n: {
					detectLanguage: this.createMethod("i18n.detectLanguage"),
					getAcceptLanguages: this.createMethod("i18n.getAcceptLanguages"),
					getUILanguage: this.createMethod("i18n.getUILanguage")
				},
				management: {
					getPermissionWarningsByManifest: this.createMethod("management.getPermissionWarningsByManifest"),
					getSelf: this.createMethod("management.getSelf"),
					uninstallSelf: this.createMethod("management.uninstallSelf"),
					ExtensionDisabledReason: tree.management.ExtensionDisabledReason,
					ExtensionInstallType: tree.management.ExtensionInstallType,
					ExtensionType: tree.management.ExtensionType,
					LaunchType: tree.management.LaunchType
				},
				...hasPermission("notifications") && { notifications: {
					clear: this.createMethod("notifications.clear"),
					create: this.createMethod("notifications.create"),
					getAll: this.createMethod("notifications.getAll"),
					update: this.createMethod("notifications.update"),
					onButtonClicked: this.createEvent("notifications.onButtonClicked"),
					onClicked: this.createEvent("notifications.onClicked"),
					onClosed: this.createEvent("notifications.onClosed"),
					PermissionLevel: tree.notifications.PermissionLevel,
					TemplateType: tree.notifications.TemplateType
				} },
				permissions: {
					contains: this.createMethod("permissions.contains"),
					getAll: this.createMethod("permissions.getAll"),
					remove: this.createMethod("permissions.remove"),
					request: async (...args) => {
						const reqId = this.$.utils.generateId();
						const name = `ProjectBrowser.requestPermissions[${reqId}]`;
						this.$.bus.once(name, (...args) => this.$.bus.send("App.requestPermissions", ...args));
						setTimeout(() => this.$.bus.off(name), this.$.utils.time("15s"));
						return await this.callMethod("permissions.request", reqId, ...args);
					}
				},
				runtime: {
					getContexts: this.createMethod("runtime.getContexts"),
					getManifest: () => manifest,
					getPlatformInfo: this.createMethod("runtime.getPlatformInfo"),
					getURL: (path) => `chrome-extension://${tree.runtime.id}/${path}`,
					getVersion: () => manifest.version,
					reload: this.createMethod("runtime.reload"),
					requestUpdateCheck: this.createMethod("runtime.requestUpdateCheck"),
					setUninstallURL: this.createMethod("runtime.setUninstallURL"),
					onUpdateAvailable: this.createEvent("runtime.onUpdateAvailable"),
					ContextType: tree.runtime.ContextType,
					id: tree.runtime.id,
					PlatformArch: tree.runtime.PlatformArch,
					PlatformNaclArch: tree.runtime.PlatformNaclArch,
					PlatformOs: tree.runtime.PlatformOs,
					RequestUpdateCheckStatus: tree.runtime.RequestUpdateCheckStatus
				},
				...hasPermission("sidePanel") && { sidePanel: {
					getLayout: this.createMethod("sidePanel.getLayout"),
					getOptions: this.createMethod("sidePanel.getOptions"),
					getPanelBehavior: this.createMethod("sidePanel.getPanelBehavior"),
					onClosed: this.createEvent("sidePanel.onClosed"),
					onOpened: this.createEvent("sidePanel.onOpened"),
					Side: tree.sidePanel.Side
				} },
				...hasPermission("storage") && { storage: {
					local: {
						get: this.createMethod("storage.local.get"),
						getKeys: this.createMethod("storage.local.getKeys"),
						set: this.createMethod("storage.local.set"),
						remove: this.createMethod("storage.local.remove"),
						clear: this.createMethod("storage.local.clear"),
						getBytesInUse: this.createMethod("storage.local.getBytesInUse"),
						onChanged: this.createEvent("storage.local.onChanged"),
						QUOTA_BYTES: tree.storage.local.QUOTA_BYTES
					},
					session: {
						clear: this.createMethod("storage.session.clear"),
						get: this.createMethod("storage.session.get"),
						getBytesInUse: this.createMethod("storage.session.getBytesInUse"),
						getKeys: this.createMethod("storage.session.getKeys"),
						remove: this.createMethod("storage.session.remove"),
						set: this.createMethod("storage.session.set"),
						onChanged: this.createEvent("storage.session.onChanged"),
						QUOTA_BYTES: tree.storage.session.QUOTA_BYTES
					},
					sync: {
						clear: this.createMethod("storage.sync.clear"),
						get: this.createMethod("storage.sync.get"),
						getBytesInUse: this.createMethod("storage.sync.getBytesInUse"),
						getKeys: this.createMethod("storage.sync.getKeys"),
						remove: this.createMethod("storage.sync.remove"),
						set: this.createMethod("storage.sync.set"),
						onChanged: this.createEvent("storage.sync.onChanged"),
						QUOTA_BYTES: tree.storage.sync.QUOTA_BYTES,
						QUOTA_BYTES_PER_ITEM: tree.storage.sync.QUOTA_BYTES_PER_ITEM,
						MAX_ITEMS: tree.storage.sync.MAX_ITEMS,
						MAX_WRITE_OPERATIONS_PER_HOUR: tree.storage.sync.MAX_WRITE_OPERATIONS_PER_HOUR,
						MAX_WRITE_OPERATIONS_PER_MINUTE: tree.storage.sync.MAX_WRITE_OPERATIONS_PER_MINUTE
					},
					onChanged: this.createEvent("storage.onChanged"),
					AccessLevel: tree.storage.AccessLevel
				} },
				tabs: {
					captureVisibleTab: this.createMethod("tabs.captureVisibleTab"),
					create: this.createMethod("tabs.create"),
					detectLanguage: this.createMethod("tabs.detectLanguage"),
					discard: this.createMethod("tabs.discard"),
					duplicate: this.createMethod("tabs.duplicate"),
					get: this.createMethod("tabs.get"),
					getZoom: this.createMethod("tabs.getZoom"),
					getZoomSettings: this.createMethod("tabs.getZoomSettings"),
					goBack: this.createMethod("tabs.goBack"),
					goForward: this.createMethod("tabs.goForward"),
					group: this.createMethod("tabs.group"),
					highlight: this.createMethod("tabs.highlight"),
					move: this.createMethod("tabs.move"),
					query: this.createMethod("tabs.query"),
					reload: this.createMethod("tabs.reload"),
					remove: this.createMethod("tabs.remove"),
					setZoom: this.createMethod("tabs.setZoom"),
					setZoomSettings: this.createMethod("tabs.setZoomSettings"),
					ungroup: this.createMethod("tabs.ungroup"),
					update: this.createMethod("tabs.update"),
					onActivated: this.createEvent("tabs.onActivated"),
					onAttached: this.createEvent("tabs.onAttached"),
					onCreated: this.createEvent("tabs.onCreated"),
					onDetached: this.createEvent("tabs.onDetached"),
					onHighlighted: this.createEvent("tabs.onHighlighted"),
					onMoved: this.createEvent("tabs.onMoved"),
					onRemoved: this.createEvent("tabs.onRemoved"),
					onReplaced: this.createEvent("tabs.onReplaced"),
					onUpdated: this.createEvent("tabs.onUpdated"),
					onZoomChange: this.createEvent("tabs.onZoomChange"),
					MutedInfoReason: tree.tabs.MutedInfoReason,
					TabStatus: tree.tabs.TabStatus,
					WindowType: tree.tabs.WindowType,
					ZoomSettingsMode: tree.tabs.ZoomSettingsMode,
					ZoomSettingsScope: tree.tabs.ZoomSettingsScope,
					MAX_CAPTURE_VISIBLE_TAB_CALLS_PER_SECOND: tree.tabs.MAX_CAPTURE_VISIBLE_TAB_CALLS_PER_SECOND,
					SPLIT_VIEW_ID_NONE: tree.tabs.SPLIT_VIEW_ID_NONE,
					TAB_ID_NONE: tree.tabs.TAB_ID_NONE,
					TAB_INDEX_NONE: tree.tabs.TAB_INDEX_NONE
				},
				...hasPermission("webNavigation") && { webNavigation: {
					getAllFrames: this.createMethod("webNavigation.getAllFrames"),
					getFrame: this.createMethod("webNavigation.getFrame"),
					onBeforeNavigate: this.createEvent("webNavigation.onBeforeNavigate"),
					onCommitted: this.createEvent("webNavigation.onCommitted"),
					onCompleted: this.createEvent("webNavigation.onCompleted"),
					onCreatedNavigationTarget: this.createEvent("webNavigation.onCreatedNavigationTarget"),
					onDOMContentLoaded: this.createEvent("webNavigation.onDOMContentLoaded"),
					onErrorOccurred: this.createEvent("webNavigation.onErrorOccurred"),
					onHistoryStateUpdated: this.createEvent("webNavigation.onHistoryStateUpdated"),
					onReferenceFragmentUpdated: this.createEvent("webNavigation.onReferenceFragmentUpdated"),
					onTabReplaced: this.createEvent("webNavigation.onTabReplaced"),
					TransitionQualifier: tree.webNavigation.TransitionQualifier,
					TransitionType: tree.webNavigation.TransitionType
				} },
				windows: {
					create: this.createMethod("windows.create"),
					get: this.createMethod("windows.get"),
					getAll: this.createMethod("windows.getAll"),
					getCurrent: this.createMethod("windows.getCurrent"),
					getLastFocused: this.createMethod("windows.getLastFocused"),
					remove: this.createMethod("windows.remove"),
					update: this.createMethod("windows.update"),
					onBoundsChanged: this.createEvent("windows.onBoundsChanged"),
					onCreated: this.createEvent("windows.onCreated"),
					onFocusChanged: this.createEvent("windows.onFocusChanged"),
					onRemoved: this.createEvent("windows.onRemoved"),
					CreateType: tree.windows.CreateType,
					WINDOW_ID_CURRENT: tree.windows.WINDOW_ID_CURRENT,
					WINDOW_ID_NONE: tree.windows.WINDOW_ID_NONE,
					WindowState: tree.windows.WindowState,
					WindowType: tree.windows.WindowType
				}
			};
			Object.keys(this.#api).forEach((key) => delete this.#api[key]);
			Object.assign(this.#api, api);
		}
	};
}));
var ProjectEposAssets;
var init_project_epos_assets_ex = __esmMin((() => {
	ProjectEposAssets = class extends ex.Unit {
		$epos = this.closest(ex.ProjectEpos);
		$project = this.closest(ex.Project);
		files = {};
		paths = [];
		async init() {
			this.paths = await this.$.idb.keys(this.$project.id, ":assets");
		}
		async load(path) {
			if (this.$.utils.is.undefined(path)) {
				await Promise.all(this.paths.map((path) => this.load(path)));
				return;
			}
			const normalizedPath = this.normalizePath(path, this.load);
			if (this.files[normalizedPath]) return;
			const blob = await this.get(normalizedPath);
			if (!blob) return;
			this.files[normalizedPath] = {
				url: URL.createObjectURL(blob),
				blob
			};
		}
		unload(path) {
			if (this.$.utils.is.undefined(path)) {
				Object.keys(this.files).forEach((path) => this.unload(path));
				return;
			}
			const normalizedPath = this.normalizePath(path, this.unload);
			if (!this.files[normalizedPath]) return;
			URL.revokeObjectURL(this.files[normalizedPath].url);
			delete this.files[normalizedPath];
		}
		url(path) {
			const normalizedPath = this.normalizePath(path, this.url);
			if (!this.files[normalizedPath]) {
				const message = `Asset not loaded: '${path}'`;
				const tip = `Call epos.assets.load('${path}') first, or use epos.assets.load() to load all assets`;
				throw this.$epos.error(`${message}. ${tip}.`, this.url);
			}
			return this.files[normalizedPath].url;
		}
		async get(path) {
			const normalizedPath = this.normalizePath(path, this.get);
			if (this.files[normalizedPath]) return this.files[normalizedPath].blob;
			return await this.$.idb.get(this.$project.id, ":assets", normalizedPath);
		}
		list(filter = {}) {
			return this.paths.map((path) => ({
				path,
				loaded: path in this.files
			})).filter((file) => {
				if (this.$.utils.is.undefined(filter.loaded)) return true;
				return filter.loaded === file.loaded;
			});
		}
		/**
		* normalizePath('a/c') -> 'a/c'
		* normalizePath('a/c/') -> 'a/c'
		* normalizePath('/a/c/') -> 'a/c'
		* normalizePath('./a/c') -> 'a/c'
		* normalizePath('a/./c') -> 'a/c'
		*/
		normalizePath(path, caller) {
			const normalizedPath = path.split("/").filter((part) => part !== "" && part !== ".").join("/");
			if (!this.paths.includes(normalizedPath)) {
				const message = `Asset not found: '${path}'`;
				throw this.$epos.error(`${message}. Make sure it is listed in epos.json 'assets' field.`, caller);
			}
			return normalizedPath;
		}
	};
}));
var ProjectEposDom;
var init_project_epos_dom_ex = __esmMin((() => {
	ProjectEposDom = class extends ex.Unit {
		$project = this.closest(ex.Project);
		root;
		view;
		shadowRoot;
		shadowView;
		constructor(parent) {
			super(parent);
			const { root, view, shadowRoot, shadowView } = this.init();
			this.root = root;
			this.view = view;
			this.shadowRoot = shadowRoot;
			this.shadowView = shadowView;
		}
		init() {
			const eposElement = document.querySelector("epos");
			if (!eposElement) throw this.never();
			const root = document.createElement("div");
			root.setAttribute("data-project-name", this.$project.spec.name);
			root.setAttribute("data-project-id", this.$project.id);
			root.setAttribute("data-epos", "");
			eposElement.append(root);
			const view = document.createElement("div");
			view.setAttribute("data-view", "");
			root.append(view);
			const shadow = document.createElement("div");
			shadow.setAttribute("data-shadow", "");
			const shadowRoot = shadow.attachShadow({ mode: "open" });
			const shadowView = document.createElement("div");
			shadowView.setAttribute("data-shadow-view", "");
			shadowRoot.append(shadowView);
			root.append(shadow);
			if (this.$project.shadowCss) {
				const sheet = new CSSStyleSheet();
				sheet.replaceSync(this.$project.shadowCss);
				const propertyRules = [...sheet.cssRules].filter((rule) => rule.cssText.startsWith("@property"));
				if (propertyRules.length > 0) {
					const propertyRulesCss = propertyRules.map((rule) => rule.cssText).join("\n");
					const blob = new Blob([propertyRulesCss], { type: "text/css" });
					const link = document.createElement("link");
					link.rel = "stylesheet";
					link.href = URL.createObjectURL(blob);
					link.setAttribute("data-hoisted-property-rules", "");
					link.setAttribute("data-epos", "");
					root.prepend(link);
				}
				const blob = new Blob([this.$project.shadowCss], { type: "text/css" });
				const link = document.createElement("link");
				link.rel = "stylesheet";
				link.href = URL.createObjectURL(blob);
				link.setAttribute("data-epos", "");
				shadowRoot.append(link);
			}
			return {
				root,
				view,
				shadowRoot,
				shadowView
			};
		}
	};
}));
var ProjectEposEnv;
var init_project_epos_env_ex = __esmMin((() => {
	ProjectEposEnv = class extends ex.Unit {
		$project = this.closest(ex.Project);
		$projects = this.closest(ex.Projects);
		tabId = this.$projects.tabInfo.tabId;
		windowId = this.$projects.tabInfo.windowId;
		isPopup = this.$.env.is.exExtension && this.$.env.extParams.locus === "popup";
		isSidePanel = this.$.env.is.exExtension && this.$.env.extParams.locus === "sidePanel";
		isBackground = this.$.env.is.exExtension && this.$.env.extParams.locus === "background";
		project = {
			id: this.$project.id,
			spec: this.$project.spec,
			manifest: this.$project.manifest,
			enabled: this.$project.enabled,
			debug: this.$project.debug,
			pageUrl: this.$.env.url.view({
				locus: "page",
				id: this.$project.id
			})
		};
	};
}));
var ProjectEposFrames;
var init_project_epos_frames_ex = __esmMin((() => {
	ProjectEposFrames = class extends ex.Unit {
		$project = this.closest(ex.Project);
		async create(url, attrs = {}) {
			const id = await this.$project.os.createFrame(url, attrs);
			if (!id) throw this.never();
			return id;
		}
		async remove(id) {
			await this.$project.os.removeFrame(id);
		}
		async has(id) {
			return (await this.list()).some((frame) => frame.id === id);
		}
		async list() {
			const frames = await this.$project.os.getFrames();
			if (!frames) throw this.never();
			return frames.map((frame) => ({
				id: frame.id,
				name: frame.name,
				url: frame.url
			}));
		}
	};
}));
var ProjectEposGeneral;
var init_project_epos_general_ex = __esmMin((() => {
	ProjectEposGeneral = class extends ex.Unit {
		$project = this.closest(ex.Project);
		fetch = this.$.utils.link(this.$project.fetcher, "fetch");
		browser = this.$project.browser.api;
		component(Component) {
			return this.$.libs.mobxReactLite.observer(Component);
		}
		render(children, container) {
			container ??= this.getReactRoot();
			this.$.libs.reactDomClient.createRoot(container).render(this.$.libs.reactJsxRuntime.jsx(this.$.libs.react.StrictMode, { children }));
		}
		getReactRoot() {
			if (this.$project.shadowCss) return this.$project.epos.dom.shadowView;
			return this.$project.epos.dom.view;
		}
	};
}));
var ProjectEposLibs;
var init_project_epos_libs_ex = __esmMin((() => {
	ProjectEposLibs = class extends ex.Unit {
		mobx = this.$.libs.mobx;
		mobxReactLite = this.$.libs.mobxReactLite;
		react = this.$.libs.react;
		reactDom = this.$.libs.reactDom;
		reactDomClient = this.$.libs.reactDomClient;
		reactJsxRuntime = this.$.libs.reactJsxRuntime;
		yjs = this.$.libs.yjs;
	};
}));
var ProjectEposProjects;
var init_project_epos_projects_ex = __esmMin((() => {
	ProjectEposProjects = class extends ex.Unit {
		$projects = this.closest(ex.Projects);
		changeHandlers = [];
		constructor(parent) {
			super(parent);
			this.$projects.bus.on("changes", () => this.changeHandlers.forEach((fn) => fn()));
		}
		async get(id, query) {
			const project = await this.$projects.sw.get(id, query);
			if (!project) throw this.never();
			return project;
		}
		async has(id) {
			const has = await this.$projects.sw.has(id);
			if (!this.$.utils.is.boolean(has)) throw this.never();
			return has;
		}
		async list(query) {
			const projects = await this.$projects.sw.all(query);
			if (!projects) throw this.never();
			return projects;
		}
		watch(handler) {
			this.changeHandlers.push(handler);
		}
		async fetch(url) {
			const bundle = await this.$projects.sw.fetch(url);
			if (!bundle) throw this.never();
			return bundle;
		}
		async create(params) {
			const id = await this.$projects.sw.create({
				spec: params.spec,
				sources: params.sources,
				assets: params.assets,
				debug: params.debug,
				enabled: params.enabled
			});
			if (!id) throw this.never();
			return id;
		}
		async update(id, updates) {
			await this.$projects.sw.update(id, {
				spec: updates.spec,
				sources: updates.sources,
				assets: updates.assets,
				debug: updates.debug,
				enabled: updates.enabled
			});
		}
		async remove(id) {
			await this.$projects.sw.remove(id);
		}
		async export(id) {
			const files = await this.$projects.sw.export(id);
			if (!files) throw this.never();
			return files;
		}
	};
}));
var DEFAULT_NAME$1;
var ProjectEposState;
var init_project_epos_state_ex = __esmMin((() => {
	DEFAULT_NAME$1 = ":default";
	ProjectEposState = class extends ex.Unit {
		$project = this.closest(ex.Project);
		static DEFAULT_NAME = DEFAULT_NAME$1;
		PARENT = exSw.ProjectState._parent_;
		ATTACH = exSw.ProjectState._attach_;
		DETACH = exSw.ProjectState._detach_;
		reaction = this.$.libs.mobx.reaction;
		async connect(...args) {
			const [name, initial, versioner] = this.$.utils.is.string(args[0]) ? [
				args[0],
				args[1],
				args[2]
			] : [
				DEFAULT_NAME$1,
				args[0],
				args[1]
			];
			this.validateName(name);
			return await this.$project.states.connect(name, initial, versioner);
		}
		async disconnect(name = DEFAULT_NAME$1) {
			this.validateName(name);
			await this.$project.states.disconnect(name);
		}
		transaction(fn) {
			this.$project.states.transaction(fn);
		}
		local(initial) {
			return this.$project.states.local(initial);
		}
		async list(filter = {}) {
			return (await this.$.idb.keys(this.$project.id, ":state")).map((name) => ({
				name: name === ":default" ? null : name,
				connected: this.$project.states.isConnected(name)
			})).filter((state) => {
				if (this.$.utils.is.undefined(filter.connected)) return true;
				return filter.connected === state.connected;
			});
		}
		async remove(name = DEFAULT_NAME$1) {
			this.validateName(name);
			await this.$project.states.remove(name);
		}
		register(models) {
			this.$project.states.register(models);
		}
		validateName(name) {
			if (name.startsWith(":") && name !== ":default") throw new Error(`State name cannot start with ':'`);
		}
	};
}));
var DEFAULT_NAME;
var ProjectEposStorage;
var init_project_epos_storage_ex = __esmMin((() => {
	DEFAULT_NAME = ":storage";
	ProjectEposStorage = class extends ex.Unit {
		$project = this.closest(ex.Project);
		static DEFAULT_NAME = DEFAULT_NAME;
		async get(...args) {
			const [name, key] = args.length === 1 ? [DEFAULT_NAME, args[0]] : [args[0], args[1]];
			this.validateName(name);
			return await this.$.idb.get(this.$project.id, name, key);
		}
		async set(...args) {
			const [name, key, value] = args.length === 2 ? [
				DEFAULT_NAME,
				args[0],
				args[1]
			] : [
				args[0],
				args[1],
				args[2]
			];
			this.validateName(name);
			await this.$.idb.set(this.$project.id, name, key, value);
		}
		async has(...args) {
			const [name, key] = args.length === 1 ? [DEFAULT_NAME, args[0]] : [args[0], args[1]];
			this.validateName(name);
			return await this.$.idb.has(this.$project.id, name, key);
		}
		async delete(...args) {
			const [name, key] = args.length === 1 ? [DEFAULT_NAME, args[0]] : [args[0], args[1]];
			this.validateName(name);
			await this.$.idb.delete(this.$project.id, name, key);
		}
		async keys(name = DEFAULT_NAME) {
			this.validateName(name);
			return await this.$.idb.keys(this.$project.id, name);
		}
		async clear(name = DEFAULT_NAME) {
			this.validateName(name);
			return await this.$.idb.deleteStore(this.$project.id, name);
		}
		remove() {
			throw new Error(`Use delete() to remove individual keys or clear() to remove the entire storage.`);
		}
		for(name = DEFAULT_NAME) {
			this.validateName(name);
			return {
				get: (key) => this.get(name, key),
				set: (key, value) => this.set(name, key, value),
				has: (key) => this.has(name, key),
				delete: (key) => this.delete(name, key),
				keys: () => this.keys(name),
				clear: () => this.clear(name),
				remove: () => this.remove()
			};
		}
		async list() {
			const storageNames = (await this.$.idb.listStores(this.$project.id)).filter((name) => !name.startsWith(":") || name === ":storage");
			return await Promise.all(storageNames.map(async (name) => ({ name: name === ":storage" ? null : name })));
		}
		validateName(name) {
			if (name.startsWith(":") && name !== ":storage") throw new Error(`Storage name cannot start with ':'`);
		}
	};
}));
var ProjectEpos;
var init_project_epos_ex = __esmMin((() => {
	ProjectEpos = class extends ex.Unit {
		#api = null;
		$project = this.closest(ex.Project);
		bus = this.$.bus.for(`ProjectEpos[${this.$project.id}]`);
		general = new ex.ProjectEposGeneral(this);
		env = new ex.ProjectEposEnv(this);
		dom = new ex.ProjectEposDom(this);
		state = new ex.ProjectEposState(this);
		storage = new ex.ProjectEposStorage(this);
		assets = new ex.ProjectEposAssets(this);
		frames = new ex.ProjectEposFrames(this);
		libs = new ex.ProjectEposLibs(this);
		projects = new ex.ProjectEposProjects(this);
		async init() {
			await this.assets.init();
			this.#api = this.createEposApi();
		}
		get api() {
			if (!this.#api) throw this.never();
			return this.#api;
		}
		error(message, caller) {
			const error = new Error(message);
			Error.captureStackTrace(error, caller);
			return error;
		}
		createEposApi() {
			const epos = {
				fetch: this.$.utils.link(this.general, "fetch"),
				browser: this.general.browser,
				component: this.$.utils.link(this.general, "component"),
				render: this.$.utils.link(this.general, "render"),
				env: {
					tabId: this.env.tabId,
					windowId: this.env.windowId,
					isPopup: this.env.isPopup,
					isSidePanel: this.env.isSidePanel,
					isBackground: this.env.isBackground,
					project: this.env.project
				},
				dom: {
					root: this.dom.root,
					view: this.dom.view,
					shadowRoot: this.dom.shadowRoot,
					shadowView: this.dom.shadowView
				},
				bus: {
					on: this.$.utils.link(this.bus, "on"),
					off: this.$.utils.link(this.bus, "off"),
					once: this.$.utils.link(this.bus, "once"),
					send: this.$.utils.link(this.bus, "send"),
					emit: this.$.utils.link(this.bus, "emit"),
					setSignal: this.$.utils.link(this.bus, "setSignal"),
					waitSignal: this.$.utils.link(this.bus, "waitSignal"),
					register: this.$.utils.link(this.bus, "register"),
					unregister: this.$.utils.link(this.bus, "unregister"),
					use: this.$.utils.link(this.bus, "use"),
					for: (id) => this.$.bus.for(`ProjectEpos[${this.$project.id}][${id}]`)
				},
				state: {
					connect: this.$.utils.link(this.state, "connect"),
					disconnect: this.$.utils.link(this.state, "disconnect"),
					transaction: this.$.utils.link(this.state, "transaction"),
					reaction: this.$.utils.link(this.state, "reaction"),
					local: this.$.utils.link(this.state, "local"),
					list: this.$.utils.link(this.state, "list"),
					remove: this.$.utils.link(this.state, "remove"),
					register: this.$.utils.link(this.state, "register"),
					PARENT: this.state.PARENT,
					ATTACH: this.state.ATTACH,
					DETACH: this.state.DETACH
				},
				storage: {
					get: this.$.utils.link(this.storage, "get"),
					set: this.$.utils.link(this.storage, "set"),
					has: this.$.utils.link(this.storage, "has"),
					delete: this.$.utils.link(this.storage, "delete"),
					keys: this.$.utils.link(this.storage, "keys"),
					list: this.$.utils.link(this.storage, "list"),
					clear: this.$.utils.link(this.storage, "clear"),
					for: this.$.utils.link(this.storage, "for"),
					remove: this.$.utils.link(this.storage, "remove")
				},
				assets: {
					url: this.$.utils.link(this.assets, "url"),
					get: this.$.utils.link(this.assets, "get"),
					list: this.$.utils.link(this.assets, "list"),
					load: this.$.utils.link(this.assets, "load"),
					unload: this.$.utils.link(this.assets, "unload")
				},
				frames: {
					create: this.$.utils.link(this.frames, "create"),
					remove: this.$.utils.link(this.frames, "remove"),
					has: this.$.utils.link(this.frames, "has"),
					list: this.$.utils.link(this.frames, "list")
				},
				...this.$project.spec.options.allowProjectsApi && { projects: {
					has: this.$.utils.link(this.projects, "has"),
					get: this.$.utils.link(this.projects, "get"),
					list: this.$.utils.link(this.projects, "list"),
					create: this.$.utils.link(this.projects, "create"),
					update: this.$.utils.link(this.projects, "update"),
					remove: this.$.utils.link(this.projects, "remove"),
					export: this.$.utils.link(this.projects, "export"),
					watch: this.$.utils.link(this.projects, "watch"),
					fetch: this.$.utils.link(this.projects, "fetch")
				} },
				libs: {
					mobx: this.libs.mobx,
					mobxReactLite: this.libs.mobxReactLite,
					react: this.libs.react,
					reactDom: this.libs.reactDom,
					reactDomClient: this.libs.reactDomClient,
					reactJsxRuntime: this.libs.reactJsxRuntime,
					yjs: this.libs.yjs
				}
			};
			class Epos {}
			Reflect.setPrototypeOf(epos, Epos.prototype);
			return epos;
		}
	};
}));
var ProjectFetcher;
var init_project_fetcher_ex = __esmMin((() => {
	ProjectFetcher = class extends ex.Unit {
		sw = this.use("sw");
		$project = this.closest(ex.Project);
		async fetch(url, init) {
			const href = new URL(String(url), location.href).href;
			if (!await this.$project.browser.api.permissions.contains({ origins: [href] })) throw new Error(`No permission to access ${href}`);
			const res = await this.sw.fetch(href, init);
			if (this.$.utils.is.error(res)) throw res;
			return {
				ok: res.ok,
				url: res.url,
				type: res.type,
				status: res.status,
				statusText: res.statusText,
				redirected: res.redirected,
				headers: new Headers(res.headers),
				text: async () => {
					const result = await this.sw.readAsText(res.id);
					if (this.$.utils.is.error(result)) throw result;
					return result;
				},
				json: async () => {
					const result = await this.sw.readAsJson(res.id);
					if (this.$.utils.is.error(result)) throw result;
					return result;
				},
				blob: async () => {
					const result = await this.sw.readAsBlob(res.id);
					if (this.$.utils.is.error(result)) throw result;
					return result;
				}
			};
		}
	};
}));
var Project;
var init_project_ex = __esmMin((() => {
	Project = class extends ex.Unit {
		id;
		debug;
		enabled;
		spec;
		manifest;
		shadowCss;
		fn = null;
		browser;
		fetcher;
		states;
		epos;
		os;
		constructor(parent, def) {
			super(parent);
			this.id = def.id;
			this.debug = def.debug;
			this.enabled = def.enabled;
			this.spec = def.spec;
			this.manifest = def.manifest;
			this.shadowCss = def.shadowCss;
			this.fn = def.fn;
			this.os = this.use("os", this.id);
			this.browser = new ex.ProjectBrowser(this);
			this.fetcher = new ex.ProjectFetcher(this);
			this.states = new exSw.ProjectStates(this, { allowMissingModels: this.spec.options.allowMissingModels });
			this.epos = new ex.ProjectEpos(this);
		}
		async init() {
			await this.browser.init();
			await this.epos.init();
			if (this.spec.options.preloadAssets) await this.epos.api.assets.load();
			if (!this.fn) throw this.never();
			this.fn.call(null, this.epos.api);
			this.fn = null;
		}
	};
}));
var Projects;
var init_projects_ex = __esmMin((() => {
	Projects = class extends ex.Unit {
		dict = {};
		tabInfo = this.getTabInfo();
		watcher = new exOsVw.ProjectsWatcher(this, this.onWatcherData.bind(this));
		sw = this.use("sw");
		bus = this.$.bus.for("Projects");
		get list() {
			return Object.values(this.dict);
		}
		async init() {
			await this.watcher.init();
			if (this.$.env.is.exExtension) {
				this.createEposElement();
				await this.injectProjects();
			}
			await this.startProjects();
		}
		onWatcherData(data) {
			if (data.reloadedProjectIds.length === 0) return;
			if (!new URL(location.href).searchParams.has("autoreload")) return;
			location.reload();
		}
		createEposElement() {
			self.__eposElement = document.createElement("epos");
			document.documentElement.prepend(self.__eposElement);
		}
		async injectProjects() {
			const liteJs = await this.sw.getLiteJs(location.href);
			if (liteJs) await this.injectJs(liteJs);
			const css = await this.sw.getCss(location.href);
			if (css) this.injectCss(css);
			const js = await this.sw.getJs(location.href);
			if (js) await this.injectJs(js);
		}
		async startProjects() {
			const projectDefs = self.__eposProjectDefs ?? [];
			delete self.__eposIsTop;
			delete self.__eposTabId;
			delete self.__eposWindowId;
			delete self.__eposElement;
			delete self.__eposProjectDefs;
			delete self.__eposBusPageToken;
			delete self.__eposOriginalGlobals;
			for (const projectDef of projectDefs) {
				const project = new ex.Project(this, projectDef);
				this.dict[project.id] = project;
				await project.init();
			}
		}
		getTabInfo() {
			if (this.$.env.is.exExtension) return {
				tabId: Number(this.$.env.extParams.tabId ?? -1),
				windowId: Number(this.$.env.extParams.windowId ?? -1)
			};
			if (this.$.env.is.exTop) {
				const tabId = self.__eposTabId;
				const windowId = self.__eposWindowId;
				if (!tabId || !windowId) throw this.never();
				return {
					tabId,
					windowId
				};
			}
			return {
				tabId: -1,
				windowId: -1
			};
		}
		async injectJs(js) {
			if (!self.__eposElement) throw this.never();
			const ready$ = Promise.withResolvers();
			const blob = new Blob([js], { type: "application/javascript" });
			const script = document.createElement("script");
			script.src = URL.createObjectURL(blob);
			script.setAttribute("data-epos", "");
			script.onload = () => ready$.resolve(true);
			self.__eposElement.prepend(script);
			await ready$.promise;
		}
		injectCss(css) {
			if (!self.__eposElement) throw this.never();
			const blob = new Blob([css], { type: "text/css" });
			const link = document.createElement("link");
			link.rel = "stylesheet";
			link.href = URL.createObjectURL(blob);
			link.setAttribute("data-epos", "");
			self.__eposElement.prepend(link);
		}
	};
}));
var Utils;
var init_utils_ex = __esmMin((() => {
	init_utils$1();
	init_utils_generate_id();
	init_utils_time();
	Utils = class extends ex.Unit {
		enqueue = enqueue;
		generateId = generateId;
		get = get$1;
		getPrototypes = getPrototypes;
		is = is;
		link = link;
		Queue = Queue;
		safe = safe;
		time = time;
	};
}));
var init_layer_ex = __esmMin((() => {
	init_app_ex();
	init_idb_ex();
	init_libs_ex();
	init_project_browser_ex();
	init_project_epos_assets_ex();
	init_project_epos_dom_ex();
	init_project_epos_env_ex();
	init_project_epos_frames_ex();
	init_project_epos_general_ex();
	init_project_epos_libs_ex();
	init_project_epos_projects_ex();
	init_project_epos_state_ex();
	init_project_epos_storage_ex();
	init_project_epos_ex();
	init_project_fetcher_ex();
	init_project_ex();
	init_projects_ex();
	init_utils_ex();
	Object.assign(ex, {
		App,
		Idb,
		Libs,
		ProjectBrowser,
		ProjectEposAssets,
		ProjectEposDom,
		ProjectEposEnv,
		ProjectEposFrames,
		ProjectEposGeneral,
		ProjectEposLibs,
		ProjectEposProjects,
		ProjectEposState,
		ProjectEposStorage,
		ProjectEpos,
		ProjectFetcher,
		Project,
		Projects,
		Utils
	});
}));
var init_index_ex = __esmMin((() => {
	init_layer_gl();
	init_layer_ex_os_vw();
	init_layer_ex_os();
	init_layer_ex_sw();
	init_layer_ex();
}));
var init_ex = __esmMin((async () => {
	init_core();
	init_index_ex();
	await new ex.App().init();
}));

//#endregion
//#region dist/ORIGINALS/exd-mini.js
await init_ex();

//#endregion
})()